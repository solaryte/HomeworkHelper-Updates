@echo off
cd /d "%~dp0"
set "HOMEWORK_HELPER_LOCAL_MODEL=qwen3-vl:8b"
py -3.14 HomeworkHelper.py
pause
