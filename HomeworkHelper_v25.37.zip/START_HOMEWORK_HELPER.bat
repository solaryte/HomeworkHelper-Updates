@echo off
setlocal
title Homework Helper
cd /d "%~dp0"

set "PYEXE="
where py >nul 2>&1
if not errorlevel 1 (
    py -3.14 -c "import sys" >nul 2>&1
    if not errorlevel 1 set "PYEXE=py -3.14"
)

if not defined PYEXE (
    where python >nul 2>&1
    if not errorlevel 1 set "PYEXE=python"
)

if not defined PYEXE (
    echo.
    echo Homework Helper could not find Python.
    echo Install Python 3.14, then run this file again.
    echo.
    pause
    exit /b 1
)

%PYEXE% -c "import tkinter" >nul 2>&1
if errorlevel 1 (
    echo.
    echo Python was found, but Tkinter is unavailable.
    echo Reinstall Python with Tcl/Tk support enabled.
    echo.
    pause
    exit /b 1
)

%PYEXE% -c "import playwright" >nul 2>&1
if errorlevel 1 (
    echo.
    echo Installing the required Playwright package once...
    %PYEXE% -m pip install -r requirements.txt
    if errorlevel 1 (
        echo.
        echo Setup failed. The error above explains what went wrong.
        pause
        exit /b 1
    )
)

if not exist ".browser_ready" (
    echo Preparing the Homework Helper browser for first use...
    %PYEXE% -m playwright install chromium
    if errorlevel 1 (
        echo.
        echo Chromium setup failed.
        pause
        exit /b 1
    )
    echo ready>".browser_ready"
)

echo Starting Homework Helper...
%PYEXE% HomeworkHelper.py
if errorlevel 1 (
    echo.
    echo Homework Helper stopped because of the error shown above.
    echo Please send me a screenshot of this window if it happens again.
    pause
)
endlocal
