@echo off
cd /d "%~dp0"
title Homework Helper - Repair Browser
echo Installing Playwright Chromium for the current Windows user...
py -3.14 -m pip install --upgrade playwright
if errorlevel 1 goto fail
set "PLAYWRIGHT_BROWSERS_PATH=%LOCALAPPDATA%\HomeworkHelper\Browsers"
if not exist "%PLAYWRIGHT_BROWSERS_PATH%" mkdir "%PLAYWRIGHT_BROWSERS_PATH%"
py -3.14 -m playwright install chromium
if errorlevel 1 goto fail
echo.
echo Chromium installation finished. Close and reopen Homework Helper.
pause
exit /b 0
:fail
echo Browser repair failed. Please send a screenshot of this window.
pause
exit /b 1
