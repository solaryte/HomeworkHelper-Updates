@echo off
setlocal
cd /d "%~dp0"
title Homework Helper v25.37 - Windows App Builder
where py >nul 2>nul || (echo Python launcher is required to build. & pause & exit /b 1)
py -3.14 -m pip install --upgrade pyinstaller playwright
if errorlevel 1 goto fail
set "PLAYWRIGHT_BROWSERS_PATH=%LOCALAPPDATA%\HomeworkHelper\Browsers"
if not exist "%PLAYWRIGHT_BROWSERS_PATH%" mkdir "%PLAYWRIGHT_BROWSERS_PATH%"
py -3.14 -m playwright install chromium
if errorlevel 1 goto fail
py -3.14 -m PyInstaller --noconfirm --clean --onefile --console --name "Homework Helper Engine" --collect-all playwright --hidden-import playwright.sync_api --hidden-import playwright._impl._driver sparx_engine.py
if errorlevel 1 goto fail
py -3.14 -m PyInstaller --noconfirm --clean --onefile --windowed --name "Homework Helper" --icon "assets\homework_helper.ico" --add-data "assets;assets" HomeworkHelper.py
if errorlevel 1 goto fail
set "APPDIR=%LOCALAPPDATA%\HomeworkHelper\App"
if not exist "%APPDIR%" mkdir "%APPDIR%"
copy /Y "dist\Homework Helper.exe" "%APPDIR%\Homework Helper.exe" >nul
if errorlevel 1 goto fail
copy /Y "dist\Homework Helper Engine.exe" "%APPDIR%\Homework Helper Engine.exe" >nul
if errorlevel 1 goto fail
copy /Y "APPLY_UPDATE.ps1" "%APPDIR%\APPLY_UPDATE.ps1" >nul
if not exist "%LOCALAPPDATA%\HomeworkHelper\icons" mkdir "%LOCALAPPDATA%\HomeworkHelper\icons"
xcopy /Y /Q "assets\*.ico" "%LOCALAPPDATA%\HomeworkHelper\icons\" >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "CREATE_THEME_SHORTCUT.ps1"
if errorlevel 1 goto fail
powershell -NoProfile -ExecutionPolicy Bypass -File "MAKE_UPDATE_ZIP.ps1"
if errorlevel 1 goto fail
start "" "%APPDIR%\Homework Helper.exe"
echo Installed into the same Windows app location. Future updates: Recent Updates - Install update ZIP.
pause
exit /b 0
:fail
echo Build or installation failed. See the error above.
pause
exit /b 1
