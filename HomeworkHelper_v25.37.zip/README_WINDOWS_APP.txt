Homework Helper v25.28 - Windows app source and build kit

FIRST INSTALL (Windows 10/11):
1. Extract this ZIP to a folder.
2. Double-click BUILD_AND_INSTALL_WINDOWS_APP.bat.
3. It requires Python 3.14 and an internet connection for PyInstaller and Playwright packages.
4. The script builds two Windows executables and installs them into:
   %LOCALAPPDATA%\HomeworkHelper\App
5. It creates the Homework Helper desktop shortcut and starts the app.
6. Existing settings and browser profile remain in %LOCALAPPDATA%\HomeworkHelper.

FUTURE VERSIONS:
- A future build can produce a Windows update ZIP with MAKE_UPDATE_ZIP.ps1.
- In the installed app open Recent Updates > Install update ZIP.
- Choose the Windows update ZIP (containing both EXEs and a hash manifest).
- The app closes, replaces the existing EXEs and reopens. It does not create a second installation.
- This is a MANUAL update workflow. Automatic online checks require an update host/release endpoint that has not been configured.

THEME ICONS:
- The app window icon changes with the selected colour theme.
- Existing Homework Helper desktop shortcuts are updated where found.
- Windows can cache taskbar/pinned shortcut icons; unpin/re-pin if the old icon remains.

LIMITATIONS:
- This ZIP contains SOURCE AND BUILD TOOLS, not a prebuilt Windows EXE.
- Windows builds cannot be run or verified in this Linux environment.
- The existing AI solver is retained; no live Sparx question testing has been performed.
- Never run an update ZIP received from an untrusted source: hashes detect corruption, not publisher identity.

V25.29: If the browser does not open, run FIX_BROWSER_WINDOWS.bat and restart the app. Browser startup failures now show an error instead of silently exiting.
