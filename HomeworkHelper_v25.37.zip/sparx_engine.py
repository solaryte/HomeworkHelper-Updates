# A stable Chromium install location works in both source and frozen Windows builds.
import os as _hh_os
from pathlib import Path as _hh_Path
_hh_os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH", str(_hh_Path(_hh_os.environ.get("LOCALAPPDATA",str(_hh_Path.home()))) / "HomeworkHelper" / "Browsers"))
import os
import argparse
from pathlib import Path
import base64,json,re,time,urllib.request
import traceback
from playwright.sync_api import sync_playwright

MODEL="qwen2.5vl:7b"; API="http://127.0.0.1:11434/api/chat"
# v25.0 optional strong cloud reasoning. If OPENAI_API_KEY is set, use a stronger
# multimodal model with web search; if it is missing/unavailable, fall back to Ollama.
STRONG_MODEL=os.environ.get("HOMEWORK_HELPER_STRONG_MODEL","gpt-6-sol")
OPENAI_API_KEY=os.environ.get("OPENAI_API_KEY","").strip()
OPENAI_RESPONSES="https://api.openai.com/v1/responses"


DATA_DIR=Path(os.environ.get("LOCALAPPDATA",str(Path.home()))) / "HomeworkHelper"
DATA_DIR.mkdir(parents=True,exist_ok=True)
EXPERIENCE_FILE=DATA_DIR/"solver_experience.json"
KNOWLEDGE_DIR=DATA_DIR/"knowledge"
KNOWLEDGE_DIR.mkdir(parents=True,exist_ok=True)

def imported_knowledge(question,limit_chars=12000):
    """Retrieve relevant passages from user-provided .txt/.md knowledge files."""
    terms=set(re.findall(r"[a-z]{4,}",question.lower()))
    hits=[]
    try:
        for f in list(KNOWLEDGE_DIR.glob("*.txt"))+list(KNOWLEDGE_DIR.glob("*.md")):
            try:text=f.read_text(encoding="utf-8",errors="ignore")
            except:continue
            for chunk in re.split(r"\n\s*\n",text):
                low=chunk.lower()
                score=sum(1 for w in terms if w in low)
                if score>=2:hits.append((score,f.name,chunk.strip()))
    except:pass
    hits.sort(reverse=True,key=lambda x:x[0])
    out=[]; used=0
    for score,name,chunk in hits:
        piece=f"[{name}] {chunk[:2500]}"
        if used+len(piece)>limit_chars:break
        out.append(piece);used+=len(piece)
    return "\n\n".join(out)


def load_experience():
    try:
        d=json.loads(EXPERIENCE_FILE.read_text(encoding="utf-8"))
        return d if isinstance(d,dict) else {}
    except Exception:return {}

EXPERIENCE=load_experience()

def save_experience():
    try:
        EXPERIENCE_FILE.write_text(json.dumps(EXPERIENCE,ensure_ascii=False,indent=2),encoding="utf-8")
    except Exception as e:print("Experience save warning:",repr(e),flush=True)

def remember_result(fp, question, answers, result, feedback=""):
    rec=EXPERIENCE.setdefault(fp,{"question":question[:3000],"wrong":[],"correct":[],"feedback":[]})
    bucket="correct" if result=="correct" else "wrong"
    if answers and answers not in rec[bucket]:rec[bucket].append(dict(answers))
    if feedback and feedback not in rec["feedback"]:rec["feedback"].append(feedback[:3000])
    save_experience()

SCIENCE_KNOWLEDGE="""
AQA GCSE SCIENCE CORE CHECKS:
PHYSICS CIRCUITS: Series current is the same through components; series potential differences add; series resistances add.
Parallel branches have the same potential difference. Total current entering a junction equals total current leaving it.
Adding a parallel branch decreases equivalent resistance; at fixed supply potential difference total current increases (R=V/I).
For parallel resistors, 1/R_total = 1/R1 + 1/R2 + ... and R_total is smaller than the smallest branch resistance.
POWER/ENERGY: P=VI, P=I^2R, E=Pt, E=QV. Charge Q=It. Resistance R=V/I.
MECHANICS: speed=distance/time; acceleration=change in velocity/time; F=ma; weight=mg; work=Fs; kinetic energy=0.5mv^2.
WAVES: wave speed=frequency*wavelength. Frequency is 1/period.
CHEMISTRY: balance equations and conserve atoms; relative formula mass is sum of Ar values; moles=mass/Mr; concentration=moles/volume(dm3).
BIOLOGY: use precise causal chains; distinguish diffusion, osmosis and active transport; enzymes have specific active sites and rates depend on temperature/pH.
PLANT TRANSPORT: XYLEM is the tissue that transports water and mineral ions through a plant; water movement through xylem is associated with the TRANSPIRATION stream. PHLOEM transports dissolved sugars such as sucrose; movement of dissolved sugars through phloem is TRANSLOCATION.
For explain questions, answer the exact command word and connect cause -> scientific mechanism -> outcome.
Sparx marking feedback and confirmed correct/incorrect results outrank model confidence.

GCSE/AQA TERMINOLOGY AND ANSWER-TYPE RULES:
- Read the noun phrase around a blank/question before answering. If it asks for a TYPE of quantity, answer the type, not a device/example that produces it.
- A cell/battery supplies DIRECT CURRENT (d.c.) and a DIRECT POTENTIAL DIFFERENCE (d.c. potential difference). Mains electricity supplies ALTERNATING CURRENT (a.c.) and an ALTERNATING POTENTIAL DIFFERENCE (a.c. potential difference).
- In GCSE wording, a CELL is a single source; a BATTERY is two or more cells. Prefer the exact curriculum term demanded by the sentence.
- Potential difference is measured in volts (V), current in amperes (A), resistance in ohms (Ω), charge in coulombs (C), energy in joules (J), power in watts (W).
- Never answer a category question with merely an example: e.g. if asked "what type of potential difference", do not answer "battery"; if asked "what supplies direct current", prefer "cell" when that is the expected GCSE term.
- For fill-the-blank, grammar is evidence: determine whether the blank requires a noun, adjective/type, quantity, unit, process, component, number or explanation, then answer only that category.
- If Sparx rejects a term, do not use a synonym that preserves the same rejected misconception; re-derive what category the blank requires.
"""

def relevant_experience(question,limit=5):
    q=set(re.findall(r"[a-z]{4,}",question.lower()))
    scored=[]
    for fp,r in EXPERIENCE.items():
        t=str(r.get("question","")).lower()
        score=sum(1 for w in q if w in t)
        if score:scored.append((score,fp,r))
    scored.sort(reverse=True,key=lambda x:x[0])
    return [{"question":r.get("question","")[:900],"wrong":r.get("wrong",[])[:3],
             "correct":r.get("correct",[])[:3],"feedback":r.get("feedback",[])[:2]} for _,_,r in scored[:limit]]


import sys
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

def repair_text(v):
    """Repair repeated UTF-8/cp1252 mojibake while preserving science symbols."""
    t=str(v or "")
    direct={
        "Î©":"Ω","Î¼":"μ","Âµ":"µ","Â°":"°","Ã—":"×",
        "âˆ’":"−","â‰¤":"≤","â‰¥":"≥","â†’":"→","Â":""
    }
    for _ in range(4):
        old=t
        for bad,good in direct.items():
            t=t.replace(bad,good)
        if any(c in t for c in ("Ã","Â","Î","â")):
            for enc in ("latin1","cp1252"):
                try:
                    candidate=t.encode(enc).decode("utf-8")
                    if candidate.count("�") <= t.count("�"):
                        t=candidate
                        break
                except Exception:
                    pass
        if t==old:
            break
    return t

def canon(x):
    import unicodedata,re
    x=repair_text(x)
    x=unicodedata.normalize("NFKC",x)
    x=x.replace("\u200b","").replace("\u200c","").replace("\u200d","").replace("\ufeff","")
    x=x.replace("\u00a0"," ").replace("Ω"," ohm ").replace("ω"," ohm ")
    x=x.replace("MΩ"," megaohm ").replace("kΩ"," kiloohm ")
    x=re.sub(r"\s+"," ",x).strip().lower()
    x=re.sub(r"[^a-z0-9]+","",x)
    return x


def match_option(answer, options):
    """Map AI option labels to Sparx's noisy DOM option strings."""
    raw=repair_text(answer)
    ca=canon(raw)
    # AI may prefix the control id, e.g. C1_R_2.
    ca=re.sub(r"^c\d+","",ca)

    # Exact normalized match.
    for o in options:
        if canon(o)==ca:
            return o

    # Scientific labels: R_2 / R₂ / R2 / C1_R_2 -> any option whose visible
    # DOM text begins with or clearly contains R2. Sparx can append hidden
    # accessibility text, hence strings such as "R 2 2 \\u200b".
    m=re.search(r"([a-z])(\d+)",ca)
    if m:
        token=m.group(1)+m.group(2)
        hits=[]
        for o in options:
            co=canon(o)
            if co.startswith(token) or token in co:
                hits.append(o)
        if len(hits)==1:
            return hits[0]

    # Phrase containment for ordinary choices, after removing control prefixes.
    hits=[]
    for o in options:
        co=canon(o)
        if ca and (ca in co or co in ca):
            hits.append(o)
    return hits[0] if len(hits)==1 else None

def norm(s): return re.sub(r"\s+"," ",str(s or "")).strip().lower()

def _json_from_model_text(s):
    s=(s or "").replace("```json","").replace("```","").strip()
    try:return json.loads(s)
    except Exception:
        a=s.find("{"); b=s.rfind("}")
        if a>=0 and b>a:return json.loads(s[a:b+1])
        raise

def _ask_strong(prompt,text,img=None):
    """Use OpenAI Responses when configured. Vision + web search gives hard GCSE
    questions a much stronger second brain than the local 7B model."""
    if not OPENAI_API_KEY: raise RuntimeError("OPENAI_API_KEY not configured")
    content=[{"type":"input_text","text":text}]
    if img:
        content.append({"type":"input_image","image_url":"data:image/png;base64,"+base64.b64encode(img).decode()})
    payload={
      "model":STRONG_MODEL,
      "instructions":prompt+"\nReturn ONLY the requested JSON object. Use precise UK GCSE/AQA science terminology. First identify what TYPE/CATEGORY of answer the wording requires; never substitute an example component for the requested scientific quantity/type. If prior answers are stated as rejected, treat them as proven false and reason again from first principles.",
      "input":[{"role":"user","content":content}],
      "tools":[{"type":"web_search"}],
      "temperature":0
    }
    req=urllib.request.Request(OPENAI_RESPONSES,data=json.dumps(payload).encode(),headers={"Content-Type":"application/json","Authorization":"Bearer "+OPENAI_API_KEY})
    with urllib.request.urlopen(req,timeout=240) as r:d=json.loads(r.read())
    # Responses API: collect assistant output_text blocks.
    out=[]
    for item in d.get("output",[]):
        if item.get("type")=="message":
            for c in item.get("content",[]):
                if c.get("type")=="output_text": out.append(c.get("text",""))
    return _json_from_model_text("\n".join(out))

def ask(prompt,text,img=None):
    # Strong mode is automatic when a key exists. Any quota/network/API problem
    # falls back to the known-working local Ollama path instead of stopping homework.
    if OPENAI_API_KEY:
        try:
            ans=_ask_strong(prompt,text,img)
            print("AI ROUTE: strong multimodal + web reasoning",flush=True)
            return ans
        except Exception as e:
            print("AI ROUTE: strong model unavailable; local fallback:",type(e).__name__,str(e)[:180],flush=True)
    m=[{"role":"system","content":prompt+"\nUse precise UK GCSE/AQA terminology. Identify the requested answer category before solving. A rejected answer is proven false: do not repeat or defend it."},{"role":"user","content":text}]
    if img:m[-1]["images"]=[base64.b64encode(img).decode()]
    data=json.dumps({"model":MODEL,"stream":False,"format":"json","messages":m,
                     "options":{"temperature":0,"num_ctx":8192}}).encode()
    req=urllib.request.Request(API,data=data,headers={"Content-Type":"application/json"})
    with urllib.request.urlopen(req,timeout=240) as r:d=json.loads(r.read())
    return _json_from_model_text(d["message"]["content"])

def stable(page):
    last=""; same=0
    for _ in range(35):
        try:
            t=page.locator("body").inner_text(timeout=800)[:800]
            if t==last:
                same+=1
                if same>=2:return
            else:last=t;same=0
        except:pass
        time.sleep(.15)


def active_step_region(page):
    """Locate the current Sparx tutorial/correction step and return viewport y bounds."""
    try:
        return page.evaluate(r"""()=>{
          const all=[...document.querySelectorAll('body *')];
          const steps=[];
          for(const e of all){
            const t=(e.innerText||e.textContent||'').trim();
            const m=t.match(/^Step\s+(\d+)\s*\/\s*(\d+)$/i);
            if(!m) continue;
            const r=e.getBoundingClientRect();
            if(r.width>0&&r.height>0&&r.bottom>0&&r.top<innerHeight)
              steps.push({n:+m[1],total:+m[2],y:r.top,text:t});
          }
          if(!steps.length)return null;
          // Highest numbered visible step is the active/current tutorial step.
          steps.sort((a,b)=>a.n-b.n||a.y-b.y);
          const cur=steps[steps.length-1];
          let bottom=innerHeight+1200;
          for(const x of steps)if(x.y>cur.y+20)bottom=Math.min(bottom,x.y);
          return {top:Math.max(100,cur.y-15),bottom:bottom,step:cur.n,total:cur.total,text:cur.text};
        }""")
    except:return None

def layout_profile(page):
    """Classify the currently active Sparx answer layout before solving."""
    reg=active_step_region(page)
    try:
        d=page.evaluate(r"""(reg)=>{
          const inreg=e=>{const r=e.getBoundingClientRect();return r.bottom>(reg?reg.top:120)&&r.top<(reg?reg.bottom:innerHeight+1000)};
          const vis=e=>{const s=getComputedStyle(e),r=e.getBoundingClientRect();return inreg(e)&&r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'};
          return {
            inputs:[...document.querySelectorAll('input:not([type=hidden]):not([type=radio]):not([type=checkbox]),textarea,[contenteditable=true]')].filter(vis).length,
            selects:[...document.querySelectorAll('select')].filter(vis).length,
            radios:[...document.querySelectorAll('input[type=radio],[role=radio]')].filter(vis).length,
            buttons:[...document.querySelectorAll('button,[role=button]')].filter(vis).length,
            step:reg?reg.step:null,total:reg?reg.total:null
          };
        }""",reg)
    except:d={}
    if d.get("selects",0): kind="dropdown"
    elif d.get("inputs",0)>1: kind="multi-input"
    elif d.get("inputs",0)==1: kind="written-or-numeric-input"
    elif d.get("radios",0)>=2: kind="multiple-choice"
    else: kind="mixed/custom"
    d["layout"]=kind
    return d

def active_question_text(page):
    """Read the active tutorial step instead of mixing completed and future steps."""
    reg=active_step_region(page)
    if not reg:return question_text(page)
    try:
        txt=page.evaluate(r"""(reg)=>{
          const els=[...document.querySelectorAll('body *')].filter(e=>{
            const r=e.getBoundingClientRect();
            return r.top>=reg.top-5 && r.top<reg.bottom && r.width>0 && r.height>0;
          });
          // Prefer leaf-ish visible text to avoid huge duplicated parent text.
          let out=[],seen=new Set();
          for(const e of els){
            if(e.children.length>4)continue;
            let t=(e.innerText||e.textContent||'').replace(/\\s+/g,' ').trim();
            if(!t||t.length>1200||seen.has(t))continue;
            seen.add(t);out.push(t);
          }
          return out.join('\n');
        }""",reg)
        return txt or question_text(page)
    except:return question_text(page)

def question_text(page):
    try:return page.locator("body").inner_text(timeout=2500)
    except:return ""

def get_inputs(page):
    # Never expose login/account fields to the answer writer.
    u=(page.url or "").lower()
    if any(x in u for x in ["/login","/signin","/sign-in","/auth"]):
        return []
    loc=page.locator('input:not([type=hidden]):not([type=radio]):not([type=checkbox]),textarea,[contenteditable=true]')
    a=[]
    for i in range(loc.count()):
        try:
            e=loc.nth(i);b=e.bounding_box()
            meta=" ".join([(e.get_attribute("name") or ""),(e.get_attribute("id") or ""),
                           (e.get_attribute("placeholder") or ""),(e.get_attribute("autocomplete") or ""),
                           (e.get_attribute("type") or "")]).lower()
            if any(x in meta for x in ["user","email","login","password","passcode","school"]):
                continue
            reg=active_step_region(page)
            in_region=(not reg) or (b and b["y"]>=reg["top"] and b["y"]<reg["bottom"])
            if e.is_visible() and e.is_enabled() and b and b["y"]>100 and in_region:
                a.append((b["y"],b["x"],e))
        except:pass
    return [x[2] for x in sorted(a)]


UTILITY_CHOICE_LABELS={
    "skip","zoom","imagezoom","zoomin","zoomout","submit","check","checkanswer","continue","next","nextquestion",
    "retry","tryagain","restart","idontknow","reportproblem","reportaproblem",
    "showmethesupportagain","equationssheet","periodictable","menu","back","results",
    "tobottom","totop","clearselection","okayivegotit","letsgot","letsgolearnit"
}
NEVER_CLICK_TEXT={"i dont know","report problem","report a problem","skip","image zoom","zoom in","zoom out","+","−"}

def is_never_click_text(text):
    return canon(text) in {canon(x) for x in NEVER_CLICK_TEXT}
def is_utility_choice_text(text):
    return canon(text) in UTILITY_CHOICE_LABELS

def choices(page):
    """Detect choices only inside the active Sparx step; ignore numeric keypad controls."""
    reg=active_step_region(page)
    raw=page.evaluate("""(reg)=>{
      const bad=/^(submit|check|continue|restart|try again|retry|i don't know|report problem|equations sheet)$/i;
      const els=[...document.querySelectorAll('button,[role="button"],label,[role="radio"],[role="option"],input[type="radio"]')];
      let a=[];
      for(const e0 of els){
        let e=e0;
        if(e0.matches('input[type="radio"]') && e0.labels && e0.labels[0]) e=e0.labels[0];
        const r=e.getBoundingClientRect();
        const st=getComputedStyle(e);
        if(r.width<45||r.height<28||r.bottom<120||r.top>innerHeight+600||r.right<0||r.left>innerWidth) continue;
        if(st.display==='none'||st.visibility==='hidden'||Number(st.opacity)===0) continue;
        let t=(e.innerText||e.textContent||e.getAttribute('aria-label')||'').replace(/\\s+/g,' ').trim();
        if(!t||t.length>260||bad.test(t)) continue;
        if(reg && (r.top<reg.top || r.top>=reg.bottom)) continue;
        // Sparx on-screen numeric keypad is an input aid, NOT a multiple-choice answer.
        if(/^[0-9]$/.test(t) || t==='.' || t==='−' || t==='-' || t==='⌫' || /^(backspace|negate|minus|decimal)$/i.test(t)) {
          if(r.width<180 && r.height<90) continue;
        }
        // Ignore navigation/sidebar controls and tiny icon buttons.
        if(r.top<135 || r.left<20) continue;
        a.push({text:t,x:r.x,y:r.y,w:r.width,h:r.height});
      }
      // Remove nested duplicates: same text and almost the same centre/box.
      let out=[];
      for(const x of a.sort((p,q)=>p.y-q.y||p.x-q.x)){
        if(out.some(y=>y.text===x.text && Math.abs((y.x+y.w/2)-(x.x+x.w/2))<12 &&
                    Math.abs((y.y+y.h/2)-(x.y+x.h/2))<12)) continue;
        out.push(x);
      }
      return out;
    }""",reg)
    # Restrict to plausible question-answer cards by geometry and remove repeated text.
    ded=[]; seen=set()
    for x in raw:
        key=(norm(x.get("text","")),round(x.get("x",0)/8),round(x.get("y",0)/8))
        if not key[0] or key in seen: continue
        seen.add(key);ded.append(x)

    # Group by visual rows first, then merge consecutive vertically stacked wide cards.
    items=sorted(ded,key=lambda z:(z["y"],z["x"]))
    row_groups=[]
    for x in items:
        cy=x["y"]+x["h"]/2
        hit=None
        for g in row_groups:
            gy=sum(q["y"]+q["h"]/2 for q in g)/len(g)
            if abs(cy-gy)<=25:
                hit=g;break
        if hit is None: row_groups.append([x])
        else: hit.append(x)

    groups=[];i=0
    while i<len(row_groups):
        g=sorted(row_groups[i],key=lambda z:z["x"])
        # Horizontal answer cards can wrap onto the next line (e.g. A-E, then F).
        if len(g)>=2:
            merged=list(g); j=i+1
            base_h=sum(x["h"] for x in g)/len(g)
            base_w=sum(x["w"] for x in g)/len(g)
            prev_bottom=max(x["y"]+x["h"] for x in g)
            while j<len(row_groups):
                ng=sorted(row_groups[j],key=lambda z:z["x"])
                top=min(x["y"] for x in ng); gap=top-prev_bottom
                same_cards=all(abs(x["h"]-base_h)<22 and abs(x["w"]-base_w)<90 for x in ng)
                starts_near=abs(ng[0]["x"]-g[0]["x"])<80
                if 0<=gap<=55 and same_cards and starts_near and len(merged)+len(ng)<=10:
                    merged.extend(ng)
                    prev_bottom=max(x["y"]+x["h"] for x in ng); j+=1
                else: break
            groups.append(merged);i=j;continue
        # Single wide rows: collect adjacent same-left/same-width cards as one vertical group.
        first=g[0]; stack=[first]; j=i+1
        while j<len(row_groups) and len(row_groups[j])==1:
            q=row_groups[j][0]
            prev=stack[-1]
            gap=q["y"]-(prev["y"]+prev["h"])
            same_shape=abs(q["x"]-first["x"])<55 and abs(q["w"]-first["w"])<260
            if same_shape and -4<=gap<=42:
                stack.append(q);j+=1
            else: break
        if len(stack)>=2: groups.append(stack)
        i=j if j>i+1 else i+1

    # Keep realistic answer groups and de-duplicate text within each.
    out=[]
    for g in groups:
        gg=[]; st=set()
        for x in g:
            k=norm(x["text"])
            if k not in st: st.add(k);gg.append(x)
        if 2<=len(gg)<=10: out.append(gg)
    # Global safety: Skip/Submit/Zoom/etc are page controls, never science answers.
    out=[[item for item in group if not is_utility_choice_text(item.get("text",""))] for group in out]
    out=[group for group in out if len(group)>=2]
    return out

def native_selects(page):
    loc=page.locator("select");out=[]
    for i in range(loc.count()):
        e=loc.nth(i)
        try:
            b=e.bounding_box();reg=active_step_region(page)
            if e.is_visible() and e.is_enabled() and b and ((not reg) or (b["y"]>=reg["top"] and b["y"]<reg["bottom"])):
                opts=[repair_text(x) for x in e.locator("option").all_text_contents()]
                out.append((e,[x.strip() for x in opts if x.strip()]))
        except:pass
    return out

def dashed(page):
    vals=page.evaluate(r"""()=>{
      let a=[];for(const e of document.querySelectorAll('body *')){
        const r=e.getBoundingClientRect(),s=getComputedStyle(e);
        if(r.y<150||r.bottom>innerHeight-85||r.width<45||r.width>330||r.height<24||r.height>110)continue;
        const b=[s.borderTopStyle,s.borderRightStyle,s.borderBottomStyle,s.borderLeftStyle];
        if(b.filter(x=>x==='dashed').length>=2)a.push({x:r.x,y:r.y,w:r.width,h:r.height});
      }return a;
    }""")
    out=[]
    for v in sorted(vals,key=lambda z:(z["y"],z["x"])):
        if not any(abs(v["x"]-x["x"])<7 and abs(v["y"]-x["y"])<7 for x in out):out.append(v)
    return out

def focus_without_mouse(e):
    try:
        e.evaluate("(el)=>{el.scrollIntoView({block:'center'});el.focus();}")
        return True
    except:return False

def clear_sparx_input(page,e):
    """Clear without mouse clicks, so Sparx keypad overlays cannot intercept."""
    try:
        page.keyboard.press("Escape")
    except:pass
    if not focus_without_mouse(e): return False
    for key in ("Control+A","Backspace"):
        try:e.press(key)
        except:
            try:page.keyboard.press(key)
            except:pass
    time.sleep(.08)
    try:
        if e.input_value().strip()=="": return True
    except:pass
    try:
        e.evaluate("""el=>{
          const p=el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
          const d=Object.getOwnPropertyDescriptor(p,'value');
          if(d&&d.set)d.set.call(el,''); else el.value='';
          el.dispatchEvent(new Event('input',{bubbles:true}));
          el.dispatchEvent(new Event('change',{bubbles:true}));
        }""")
        time.sleep(.08)
        return e.input_value().strip()==""
    except:return False

def keypad_type(page, value):
    """Use Sparx's on-screen number pad when its controlled numeric input rejects normal fill."""
    chars=list(str(value).strip())
    allowed=set("0123456789.-")
    if not chars or any(c not in allowed for c in chars): return False
    for c in chars:
        labels=["−","-"] if c=="-" else [c]
        hit=False
        for lab in labels:
            try:
                loc=page.get_by_text(lab,exact=True)
                for j in range(loc.count()):
                    b=loc.nth(j)
                    if not b.is_visible(): continue
                    box=b.bounding_box()
                    if box and box["y"]>300 and box["height"]<90 and box["width"]<180:
                        b.click(force=True,timeout=1000);hit=True;break
            except: pass
            if hit:break
        if not hit:
            print("Keypad key unavailable:",repr(c)); return False
        time.sleep(.07)
    return True

def sanitize_written_answer(value):
    """Extract one plain answer and remove model markup before entering prose."""
    import unicodedata
    import html
    if isinstance(value, dict):
        for key in ("answer", "text", "value", "response", "I1"):
            if key in value:
                value = value[key]
                break
    if isinstance(value, (list, tuple)):
        value = " ".join(map(str, value))
    value = str(value or "").strip()
    # Some models return a JSON object serialized as text rather than an answer.
    if value.startswith("{") and value.endswith("}"):
        try:
            obj = json.loads(value)
            if isinstance(obj, dict):
                value = next((str(obj[k]) for k in ("answer", "text", "value", "response", "I1") if k in obj), value)
        except (ValueError, TypeError):
            pass
    value = html.unescape(value)
    # Sup/sub are often emitted literally by vision models: convert to digits.
    value = re.sub(r"<\s*/?\s*(?:sup|sub)\s*>", "", value, flags=re.I)
    value = re.sub(r"<\s*br\s*/?\s*>", " ", value, flags=re.I)
    value = re.sub(r"<[^>]*>", " ", value)
    value = value.translate(str.maketrans("⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻₀₁₂₃₄₅₆₇₈₉", "0123456789+-0123456789"))
    for old, new in {"−":"-", "–":"-", "—":"-", "×":"x", "÷":"/", "Ω":"ohms", "→":" to ", "⇒":" to ", "α":"alpha", "β":"beta", "γ":"gamma"}.items():
        value = value.replace(old, new)
    value = unicodedata.normalize("NFKD", value)
    value = "".join(ch for ch in value if ord(ch) < 128 and (ch.isalnum() or ch.isspace() or ch in ".,;:!?()[]+-/=%'"))
    return " ".join(value.split())

def write_input(page,e,value):
    """Enter a Sparx numeric/text answer using the site's own keypad first when present."""
    value=str(value).strip()
    try:
        typ=(e.get_attribute("type") or "").lower()
        tag=e.evaluate("el => el.tagName.toLowerCase()")
        if tag=="textarea" or typ in ("text","search",""):
            cleaned=sanitize_written_answer(value)
            if cleaned!=value: print("INPUT SANITIZER: converted unsupported characters to plain text",flush=True)
            value=cleaned
    except Exception: pass
    bring_into_view(e)
    # Focus field.
    try:e.click()
    except:pass
    time.sleep(.12)

    # Sparx numeric widgets often reject programmatic fill but accept their keypad.
    # Detect visible keypad by digit buttons near the focused input.
    def visible_key(label):
        candidates=[]
        try:
            # exact text/aria label, including Sparx accessibility labels
            for loc in [page.get_by_role("button",name=re.compile("^"+re.escape(label)+"$",re.I)),
                        page.get_by_text(re.compile("^"+re.escape(label)+"$",re.I))]:
                for i in range(min(loc.count(),30)):
                    x=loc.nth(i)
                    try:
                        if x.is_visible() and x.is_enabled(): candidates.append(x)
                    except:pass
        except:pass
        return candidates[0] if candidates else None

    numeric=bool(re.fullmatch(r"-?\d+(?:\.\d+)?",value))
    if numeric:
        # Clear with the widget's own backspace if it already contains anything.
        try:
            cur=e.input_value()
        except:cur=""
        if cur:
            bk=visible_key("backspace")
            if bk:
                for _ in range(len(cur)+2):
                    try:bk.click()
                    except:break
        ok=True
        for ch in value:
            labels=[ch]
            if ch=="-": labels=["negate","minus","-","−"]
            elif ch==".": labels=["decimal",".","point"]
            key=None
            for lab in labels:
                key=visible_key(lab)
                if key:break
            if not key:
                ok=False;break
            try:key.click();time.sleep(.07)
            except:ok=False;break
        if ok:
            try:
                got=e.input_value().strip()
                print(f"KEYPAD VERIFY: wanted {value!r} got {got!r}",flush=True)
                if got==value:return True
            except:pass

    # Normal HTML/text inputs: use native Playwright input mechanisms.
    for attempt in range(3):
        try:
            bring_into_view(e);e.click()
            e.fill(value)
            e.dispatch_event("input");e.dispatch_event("change")
            time.sleep(.12)
            got=e.input_value().strip()
            print(f"INPUT VERIFY attempt {attempt+1}: wanted {value!r} got {got!r}",flush=True)
            if got==value:return True
        except Exception as ex:
            print("INPUT attempt warning:",repr(ex),flush=True)
    return False

def click_text(page,t):
    try:
        l=page.get_by_text(t,exact=True);c=[]
        for i in range(l.count()):
            e=l.nth(i)
            if e.is_visible():
                b=e.bounding_box()
                if b and 150<b["y"]<page.viewport_size["height"]-85:c.append((b["width"]*b["height"],e,b))
        if c:
            _,e,b=min(c,key=lambda z:z[0])
            try:e.click()
            except:page.mouse.click(b["x"]+b["width"]/2,b["y"]+b["height"]/2)
            return True
    except:pass
    return False

def popup_options(page,b):
    before=set(norm(x) for x in question_text(page).splitlines())
    page.mouse.click(b["x"]+b["w"]/2,b["y"]+b["h"]/2);time.sleep(.15)
    vals=[]
    for x in question_text(page).splitlines():
        x=re.sub(r"\s+"," ",x).strip()
        if x and norm(x) not in before and len(x)<100:vals.append(x)
    page.keyboard.press("Escape")
    return list(dict.fromkeys(vals))[:15]



def is_question_page(page):
    """Recognise the live Sparx question from the rendered page, independent of URL shape."""
    try:
        u=(page.url or "").lower()
        if "sparx-learning.com" not in u or any(x in u for x in ("/login","/signin","/sign-in","/auth")):
            return False
        body=page.locator("body").inner_text(timeout=1500).lower()
        if ("password" in body and ("log in" in body or "sign in" in body)):
            return False
        # Native checkbox/radio matrices and connector matching are first-class answer controls too.
        # Older builds excluded input[type=checkbox] from get_inputs(), which made perfectly visible
        # grid questions look like blank pages and triggered the scan loop.
        has_standard=bool(get_inputs(page) or choices(page) or native_selects(page) or dashed(page) or checkbox_table(page) or is_match_pairs_page(page))
        has_grid=bool(checkbox_table(page))
        has_match=any(x in body for x in ("match each", "match the", "match these")) and "/tasks/" in u
        has_controls=has_standard or has_grid or has_match
        has_action=any(x in body for x in ("submit","check answer","i don't know","report problem","clear selection"))
        questionish=("question" in body or "marks" in body or "mark" in body or has_grid or has_match)
        return has_controls or (has_action and questionish)
    except:
        return False

def page_question_score(page):
    try:
        if page.is_closed(): return -999
        url=(page.url or "").lower()
        if "sparx" not in url:return -100
        score=5 if "/tasks/" in url else 0
        if re.search(r"/tasks/[^/?#]+(?:/\d+)?",url):score+=3
        try:body=page.locator("body").inner_text(timeout=1800)
        except:body=""
        low=body.lower()
        if "?" in body or re.search(r"\b(calculate|predict|explain|describe|state|select|choose|what|which|how|why)\b",low):score+=3
        n=0
        for sel in ["input:not([type=hidden]):not([type=password])","textarea","select","[role=radio]","button"]:
            try:
                loc=page.locator(sel)
                for i in range(min(loc.count(),35)):
                    try:
                        if loc.nth(i).is_visible():n+=1
                    except:pass
            except:pass
        if n:score+=4
        return score
    except:return -999

def find_question_page(ctx,current=None):
    candidates=[];seen=set()
    for pg in ([current] if current else [])+list(ctx.pages):
        if not pg or id(pg) in seen:continue
        seen.add(id(pg))
        candidates.append((page_question_score(pg),pg))
    if not candidates:return None
    candidates.sort(key=lambda x:x[0],reverse=True)
    score,pg=candidates[0]
    if score>=7:
        try:pg.bring_to_front()
        except:pass
        return pg
    return None

def active_task_page(ctx, preferred=None):
    live=[]
    for pg in list(ctx.pages):
        try:
            if not pg.is_closed() and "/tasks/" in (pg.url or ""):
                live.append(pg)
        except:
            pass
    return live[-1] if live else preferred

def page_context(page):
    try: page.wait_for_load_state("domcontentloaded", timeout=5000)
    except: pass
    try: page.wait_for_timeout(250)
    except: pass
    try: text=page.locator("body").inner_text(timeout=3000)
    except: text=""
    try: image=page.screenshot(full_page=True)
    except: image=page.screenshot()
    return text,image


def set_input_value(el, value):
    """Set one controlled input without ever appending to its old value."""
    target=str(value).strip()
    for attempt in range(5):
        try:
            el.scroll_into_view_if_needed()
            el.click(force=True, timeout=1500)
        except: pass

        # Method 1: Playwright fill replaces the whole value atomically.
        try:
            el.fill(target, force=True, timeout=1800)
        except: pass
        time.sleep(.10)
        try:
            got=el.input_value(timeout=800).strip()
        except: got=""
        print(f"INPUT VERIFY attempt {attempt+1}: wanted {target!r} got {got!r}")
        if got==target: return True

        # Method 2: native HTMLInputElement setter + React-compatible events.
        try:
            el.evaluate("""(el,v)=>{
              const proto = el instanceof HTMLTextAreaElement
                ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
              const setter=Object.getOwnPropertyDescriptor(proto,'value').set;
              setter.call(el,v);
              el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:v}));
              el.dispatchEvent(new Event('change',{bubbles:true}));
            }""",target)
            el.press("Tab")
        except: pass
        time.sleep(.12)
        try:
            got=el.input_value(timeout=800).strip()
        except: got=""
        if got==target: return True

        # Method 3: keyboard replacement. Home/End is deliberately not used:
        # Ctrl+A + type means partial values such as "1." cannot survive.
        try:
            el.click(force=True)
            el.press("Control+A")
            el.type(target, delay=35)
            el.press("Tab")
        except: pass
        time.sleep(.12)
        try:
            got=el.input_value(timeout=800).strip()
        except: got=""
        if got==target: return True
    return False


def choice_key(v):
    import re, unicodedata
    x=unicodedata.normalize("NFKC",str(v or "")).lower()
    x=x.replace("\u00a0"," ").replace("ω"," ohm ")
    x=x.replace("₀","0").replace("₁","1").replace("₂","2").replace("₃","3").replace("₄","4")
    x=re.sub(r"\\bc\\d+[_ -]*","",x)   # C1_R2 -> R2
    x=re.sub(r"[^a-z0-9]+","",x)
    return x

def match_choice_answer(answer, options):
    """Map model answers to the actual visible option, including R_2/R₂ style labels."""
    a=choice_key(answer)
    if not a:return None
    # exact normalized match first
    for o in options:
        if choice_key(o)==a:return o
    # Extract compact scientific labels such as R1/R2.
    import re
    m=re.search(r"r([0-9]+)",a)
    if m:
        token="r"+m.group(1)
        for o in options:
            if token in choice_key(o): return o
    # Then containment for normal answer phrases.
    candidates=[o for o in options if a in choice_key(o) or choice_key(o) in a]
    if len(candidates)==1:return candidates[0]
    return None


def choice_is_selected(page,item):
    """Best-effort detection for Sparx cards so selecting an answer is idempotent."""
    if not isinstance(item,dict): return False
    try:
        # choices() stores getBoundingClientRect coordinates: these are VIEWPORT coordinates.
        # Never subtract window.scrollX/Y here (that was the v25.13 toggle/state bug).
        x=item["x"]+item["w"]/2;y=item["y"]+item["h"]/2
        return bool(page.evaluate("""([x,y])=>{
          let e=document.elementFromPoint(x,y);
          for(let k=0;e&&k<7;k++,e=e.parentElement){
            if(e.matches && e.matches('input[type=radio],input[type=checkbox]') && e.checked)return true;
            const ac=(e.getAttribute&&e.getAttribute('aria-checked')||'').toLowerCase();
            const ap=(e.getAttribute&&e.getAttribute('aria-pressed')||'').toLowerCase();
            const as=(e.getAttribute&&e.getAttribute('aria-selected')||'').toLowerCase();
            if(ac==='true'||ap==='true'||as==='true')return true;
            const c=(e.className||'').toString().toLowerCase();
            if(/(^|[ _-])(selected|checked|active|chosen)([ _-]|$)/.test(c))return true;
            const inp=e.querySelector&&e.querySelector('input[type=radio]:checked,input[type=checkbox]:checked');
            if(inp)return true;
          }
          return false;
        }""",[x,y]))
    except:return False

def safe_choice_click(page, item, visible_text=""):
    """Click a choice regardless of whether older discovery returned a locator or metadata dict."""
    # Actual Playwright locator path.
    if hasattr(item,"click"):
        try:
            item.scroll_into_view_if_needed(timeout=1200)
        except: pass
        try:
            item.click(force=True,timeout=1800)
            return True
        except Exception as ex:
            print("Locator choice click failed:",repr(ex))
    # Metadata fallback: use stable id/text/position hints rather than calling locator methods on dict.
    if isinstance(item,dict):
        # choices() deliberately records the exact visible card rectangle.
        # Click its centre directly; this avoids hidden accessibility text such as
        # "R 2 2 \\u200b" breaking text-based locators.
        try:
            # getBoundingClientRect values are already viewport-relative Playwright mouse coordinates.
            x=float(item["x"])+float(item["w"])/2
            y=float(item["y"])+float(item["h"])/2
            page.mouse.click(x,y)
            time.sleep(.12)
            return True
        except Exception as ex:
            print("Coordinate choice click failed:",repr(ex))
        for key in ("text","label","name","value"):
            val=item.get(key)
            if val:
                try:
                    loc=page.get_by_text(str(val),exact=False).first
                    if loc.is_visible(timeout=600):
                        loc.click(force=True,timeout=1500); return True
                except: pass
    # Final visible-text fallback, Unicode normalized by browser rather than terminal encoding.
    if visible_text:
        try:
            target=canon(visible_text)
            locs=page.locator("button:visible, [role=radio]:visible, label:visible")
            for i in range(min(locs.count(),80)):
                el=locs.nth(i)
                try:
                    if target and target in canon(el.inner_text(timeout=400)):
                        el.click(force=True,timeout=1500); return True
                except: pass
        except: pass
    return False


LAST_ATTEMPT={}
PARTIAL_LOCKS={}
WRONG_BY_CONTROL={}
KNOWN_WRONG={}
SPARX_FEEDBACK={}
# v25.21: authoritative facts extracted from Sparx teaching/reveal cards.
LEARNED_TEACHING={}

def task_learning_key(page):
    try:
        u=(page.url or "").split("#",1)[0].split("?",1)[0]
        return u.rsplit("/",1)[0] if "/tasks/" in u else u
    except Exception:
        return ""

def capture_teaching_evidence(page):
    """Read a Sparx teaching/reveal card BEFORE acknowledging it."""
    try: raw=repair_text(page.locator("body").inner_text(timeout=1400))
    except Exception: raw=""
    if not raw.strip(): return None
    import hashlib
    sig=hashlib.sha1(raw[:14000].encode("utf-8","ignore")).hexdigest()[:16]
    key=task_learning_key(page); old=LEARNED_TEACHING.get(key,{})
    if old.get("sig")==sig: return old
    item={"sig":sig,"text":raw[:14000],"facts":[],"answer_terms":[],"time":time.time()}
    try:
        prompt="""You are reading an AUTHORITATIVE Sparx Science teaching/reveal card shown after a wrong answer.
Extract only facts and exact answer labels that Sparx itself visibly teaches. Do not infer beyond the card.
If a diagram visibly labels a structure/cell, copy that label exactly. Return ONLY JSON:
{\"facts\":[\"fact\"],\"answer_terms\":[\"exact visible term\"]}."""
        r=ask(prompt,"VISIBLE SPARX TEACHING TEXT:\n"+raw[:14000],page.screenshot())
        if isinstance(r,dict):
            item["facts"]=[str(x) for x in r.get("facts",[]) if str(x).strip()][:30]
            item["answer_terms"]=[str(x).strip() for x in r.get("answer_terms",[]) if str(x).strip()][:30]
    except Exception as ex:
        print("LEARNING: evidence extraction fallback to literal card text:",repr(ex),flush=True)
    LEARNED_TEACHING[key]=item
    print("LEARNING: captured authoritative Sparx teaching evidence:",item.get("answer_terms") or item.get("facts")[:4],flush=True)
    return item

def teaching_grounded_answers(page,controls,shot):
    """Use Sparx teaching evidence before ordinary model guesses."""
    ev=LEARNED_TEACHING.get(task_learning_key(page))
    if not ev or not controls: return {}
    payload={"question":active_question_text(page)[:12000],"controls":controls,
             "sparx_teaching_text":ev.get("text","")[:12000],"sparx_teaching_facts":ev.get("facts",[]),
             "sparx_exact_terms":ev.get("answer_terms",[])}
    prompt="""Use the AUTHORITATIVE Sparx teaching/reveal evidence to answer the CURRENT question.
Sparx teaching evidence outranks prior knowledge and previous model answers. Never replace an exact visible Sparx label with a broader category.
Example: if the teaching diagram labels the pictured cell 'root hair cell' and the question asks the name of that cell, answer 'root hair cell', not 'plant cell', 'animal cell', 'epidermis', or 'mesophyll'.
Return ONLY JSON {\"answers\":{\"I1\":\"...\"},\"grounded\":true,\"evidence\":\"brief exact support\"}.
Only return control IDs present in CONTROLS. If the teaching evidence does not directly determine an answer, omit that ID."""
    try:
        r=ask(prompt,json.dumps(payload,ensure_ascii=False),shot)
        a=r.get("answers",{}) if isinstance(r,dict) else {}; valid={c["id"] for c in controls}
        a={k:v for k,v in a.items() if k in valid and str(v).strip()}
        # A teaching card can contain answers for a DIFFERENT question or option
        # set. Never lock an unselectable answer into the current control group.
        for c in controls:
            cid=c["id"]
            if cid in a and c.get("options"):
                exact=match_option(a[cid],c["options"])
                if exact is None:
                    print("TEACHING GROUNDING: ignoring stale/unavailable option",cid,repr(a[cid]),flush=True)
                    del a[cid]
                else:
                    a[cid]=exact
        if a and set(a)==valid:
            print("TEACHING GROUNDING: validated current-control answers:",a,flush=True)
            return a
        if a: print("TEACHING GROUNDING: incomplete evidence; falling back to current question reasoning",flush=True)
        return {}
    except Exception as ex:
        print("TEACHING GROUNDING: could not parse evidence answer:",repr(ex),flush=True); return {}

LAST_TASK_FILE=DATA_DIR/"last_active_task.json"

def save_active_task(page):
    try:
        if "/tasks/" in (page.url or ""):
            LAST_TASK_FILE.write_text(json.dumps({"url":page.url,"time":time.time(),"completed":False},indent=2),encoding="utf-8")
    except:pass

def recover_after_unexpected_exit(page):
    """Last-resort recovery only. Never bounce away from retry/correction flows."""
    try:
        url=page.url or ""
        if "/tasks/" in url:
            save_active_task(page)
            page._hh_packages_since=None
            page._hh_recovery_tries=0
            return False
        if "science.sparx-learning.com" not in url or "/packages" not in url:
            page._hh_packages_since=None
            return False
        now=time.time()
        since=getattr(page,"_hh_packages_since",None)
        if since is None:
            page._hh_packages_since=now
            print("NAV LOCK: active task unexpectedly left; preparing immediate restore of the saved task URL.",flush=True)
            return False
        # A task is not allowed to remain on /packages before verified completion.
        # Keep only a tiny grace period for Sparx's own in-task transitions.
        if now-since < 0.65:
            return False
        last_restore=getattr(page,"_hh_last_restore",0.0)
        if now-last_restore < 1.5:
            return False
        try:data=json.loads(LAST_TASK_FILE.read_text(encoding="utf-8"))
        except:return False
        if data.get("completed"): return False
        target=data.get("url","")
        if "/tasks/" not in target:return False
        page._hh_recovery_tries=getattr(page,"_hh_recovery_tries",0)+1
        page._hh_last_restore=now
        print("NAV LOCK: restoring exact saved active-task URL before any solver/menu action.",flush=True)
        try:
            page.goto(target,wait_until="domcontentloaded",timeout=12000); time.sleep(.7)
        except:return False
        if "/tasks/" in (page.url or ""):
            page._hh_packages_since=None
            print("RECOVERY: saved task reopened; transient solve/submit state will be rebuilt from the visible page.",flush=True)
            return True
        print("NAV LOCK: restore was redirected to menu; will retry after cooldown while task remains unverified.",flush=True)
        return False
    except Exception as e:
        print("Task recovery warning:",repr(e),flush=True); return False

INTERACTION_FILE=DATA_DIR/"interaction_experience.json"
try:
    INTERACTION_EXPERIENCE=json.loads(INTERACTION_FILE.read_text(encoding="utf-8"))
    if not isinstance(INTERACTION_EXPERIENCE,dict):raise ValueError()
except:
    INTERACTION_EXPERIENCE={"success":{},"failures":[]}

def remember_interaction(kind,wanted,observed="",success=False):
    key=f"{kind}:{canon(wanted)}"
    if success:
        INTERACTION_EXPERIENCE.setdefault("success",{})[key]={"observed":str(observed)[:300],"time":time.time()}
    else:
        arr=INTERACTION_EXPERIENCE.setdefault("failures",[])
        arr.append({"kind":kind,"wanted":str(wanted)[:300],"observed":str(observed)[:600],"time":time.time()})
        del arr[:-250]
    try:INTERACTION_FILE.write_text(json.dumps(INTERACTION_EXPERIENCE,ensure_ascii=False,indent=2),encoding="utf-8")
    except Exception as e:print("Interaction-memory save warning:",repr(e),flush=True)



def qfingerprint(page):
    import hashlib
    try:
        txt=active_question_text(page)
        try:
            fs=flashcard_state(page)
            if fs: txt=f'FLASHCARD_{fs}\n'+txt
        except: pass
        reg=active_step_region(page)
        if reg: txt=f"TUTORIAL_STEP_{reg['step']}_OF_{reg['total']}\n"+txt
    except: txt=""
    return hashlib.sha1(txt[:12000].encode("utf-8","ignore")).hexdigest()[:16]

def feedback_key(page):
    """URL is stable across a second-chance attempt even when feedback changes page text."""
    try: return page.url.split("#",1)[0]
    except: return ""

def read_sparx_feedback(page):
    """Read partial-mark / second-chance feedback currently visible on Sparx."""
    try:
        txt=page.locator("body").inner_text(timeout=1500)
    except:
        return ""
    low=txt.lower()
    signals=("second chance","how to improve","marks given for","mark given for","hint:")
    partial_match = bool(re.search(r"\b\d+\s+out of\s+\d+\s+(?:are|is)\s+correct\b", low))
    if not any(x in low for x in signals) and not partial_match:
        return ""
    # Keep the useful feedback region, not the whole page.
    starts=[low.find(x) for x in ("second chance","marks given for","how to improve") if low.find(x)>=0]
    st=min(starts) if starts else 0
    chunk=txt[st:st+6000]
    return chunk.strip()

def verify_solution(page, controls, proposal, screenshot, wrong_answers=None):
    """Independent second-pass GCSE science verifier. It may correct the first model answer."""
    wrong_answers=wrong_answers or []
    verify_prompt="""You are the verification stage for an AQA GCSE Science solver.
Independently solve the exact question again from the screenshot and extracted text. Do NOT simply agree
with the first proposal. FIRST identify the grammatical/scientific CATEGORY required by each blank (number, unit, quantity, type/property, component, process, term, explanation). Reject a candidate that belongs to the wrong category even if it is related science knowledge. Check formulas, arithmetic, units, unit conversions, significant figures,
series/parallel circuit rules, graph scales, diagram labels, scientific terminology and consistency
between multiple parts.

For numerical multiple-choice questions, calculate the result first and compare it with EVERY supplied
option. If the proposal's own working contradicts its selected option, correct the option.
For circuit questions explicitly distinguish series from parallel. For two resistors in parallel use
1/R_total = 1/R1 + 1/R2. For series, resistances add. Check current/voltage rules against the diagram.
Treat any KNOWN WRONG answer as rejected evidence: do not return that same complete answer set again.
If SPARX MARKING FEEDBACK is supplied, it is authoritative evidence from the previous attempt.
Preserve the scientific points that earned marks and explicitly fix EVERY item under 'How to improve' or Hint.
CRITICAL CONSISTENCY RULE: if your verifier check says the candidate is incomplete, misses the hint, or is scientifically weak, you MUST CHANGE the returned answer. Never describe a flaw and then return the same flawed answer.
For current/resistance feedback, require an explicit statement about TOTAL CURRENT and its relationship to equivalent resistance; reject "shorter path" as the explanation.
For written answers, do not merely paraphrase the rejected answer.

Return ONLY JSON:
{"approved":true,"answers":{"C1":"exact option","I1":"text"},"check":"brief independent check","confidence":0.0}
Return exactly one answer for every supplied control ID. Use only supplied choice/select/dropdown options.
If uncertain, still choose the best-supported answer but set confidence below 0.70."""
    payload={
      "question":question_text(page)[:15000],
      "controls":controls,
      "first_proposal":proposal,
      "known_wrong_attempts":wrong_answers,
      "sparx_marking_feedback":SPARX_FEEDBACK.get(feedback_key(page),""),
      "trusted_local_science_knowledge":SCIENCE_KNOWLEDGE,
      "relevant_confirmed_experience":relevant_experience(question_text(page))
    }
    return ask(verify_prompt,json.dumps(payload,ensure_ascii=False),screenshot)

def feedback_compliance(page,controls,answers,screenshot):
    fb=SPARX_FEEDBACK.get(feedback_key(page),"").strip()
    if not fb:return answers
    payload={"question":question_text(page)[:12000],"controls":controls,"candidate_answers":answers,"sparx_feedback":fb[:6000]}
    prompt="""You are the FINAL AQA GCSE Science marking-feedback gate. Sparx has marked an earlier attempt.
The candidate MUST explicitly satisfy EVERY missing point in 'How to improve' and every Hint. If it does not,
correct it yourself. Never identify a flaw then return the unchanged candidate. Preserve earned scientific points,
add the exact missing causal link, and remove misleading explanations. If feedback asks how current changes,
explicitly state whether TOTAL CURRENT increases/decreases and connect it to resistance/potential difference with
the appropriate relationship. For parallel resistance, 'shorter path' is not an acceptable reason.
Return JSON only: {"answers":{"I1":"corrected answer"},"changed":true,"reason":"short check"}"""
    try:
        data=ask(prompt,json.dumps(payload,ensure_ascii=False),screenshot)
        fixed=data.get("answers") if isinstance(data,dict) else None
        if isinstance(fixed,dict) and fixed:
            expected={c["id"] for c in controls}
            if set(fixed)!=expected:
                print("FEEDBACK FRESHNESS GUARD: ignored stale feedback answer IDs",set(fixed),"for current controls",expected,flush=True)
                return answers
            print("Feedback gate result:",fixed,flush=True);return fixed
    except Exception as e:print("Feedback gate warning:",e,flush=True)
    return answers


def inspect_full_page(page):
    """Navigate the page, then capture the active question area rather than mixing every tutorial step."""
    try:
        reg=active_step_region(page)
        if reg:
            # Keep current active step near the top so its question, diagram and controls are visible together.
            page.evaluate("(y)=>scrollBy(0,y)",reg["top"]-180)
            time.sleep(.18)
            return page.screenshot(type="png")
        # Normal question: inspect top and then return to answer controls; full-page remains useful.
        old=page.evaluate("()=>scrollY")
        page.evaluate("()=>scrollTo(0,0)");time.sleep(.12)
        img=page.screenshot(type="png",full_page=True)
        page.evaluate("(y)=>scrollTo(0,y)",old)
        return img
    except Exception:return page.screenshot(type="png")

def bring_into_view(locator):
    try:
        locator.scroll_into_view_if_needed(timeout=2500)
        time.sleep(.12)
        return True
    except:return False

def classify_question(text):
    t=text.lower()
    if any(x in t for x in ["calculate","work out","how many","determine"]):return "calculation"
    if any(x in t for x in ["explain","why","suggest why"]):return "explanation"
    if any(x in t for x in ["graph","plot","line of best fit"]):return "graph"
    if any(x in t for x in ["practical","method","experiment","investigation"]):return "practical"
    if any(x in t for x in ["equation","balance the"]):return "equation"
    return "general"

def deep_preflight(page,controls,first,shot,wrong):
    """Spend compute before spending a Sparx attempt."""
    q=active_question_text(page)[:18000]
    qtype=classify_question(q)
    imported=imported_knowledge(q)
    evidence={
      "question":q,"question_type":qtype,"controls":controls,
      "candidate":first,"known_wrong":wrong,
      "sparx_feedback":SPARX_FEEDBACK.get(feedback_key(page),""),
      "past_confirmed_experience":relevant_experience(q),
      "imported_knowledge":imported[:12000],
      "interaction_contract":interaction_contract(controls)
    }
    p="""You are the FINAL PRE-SUBMISSION examiner for an AQA GCSE Science answer.
A Sparx attempt is scarce: do not approve a guess. Independently solve the question first, then compare.
Use the screenshot, trusted science rules, retrieved user knowledge, confirmed past experience and any
Sparx feedback. For calculations independently recompute formula, substitution, arithmetic, units,
conversion and rounding. For multiple choice test every option. For explanations ensure each mark-worthy
causal point is explicit. For graphs/diagrams inspect the visual itself. Never return a known-wrong answer.
Return ONLY JSON {"answers":{...},"confidence":0.0,"check":"brief","needs_more_evidence":false}.
The answer object MUST contain exactly the supplied control IDs. Never create an answer for keypad buttons,
completed tutorial steps, navigation buttons or controls outside the active step.
If evidence is ambiguous, still return the best fully checked answer but lower confidence."""
    if imported:p+="\nRelevant imported study material is included in the evidence."
    p+="\nTRUSTED CORE RULES:\n"+SCIENCE_KNOWLEDGE
    try:return ask(p,json.dumps(evidence,ensure_ascii=False),shot)
    except Exception as e:
        print("Deep preflight warning:",repr(e),flush=True);return {}


def physically_inspect_context(page):
    """Physically move the browser up to read context, then down to the active answer."""
    reg=active_step_region(page)
    try:
        sy=page.evaluate("()=>scrollY"); vh=page.evaluate("()=>innerHeight")
        if reg:
            absolute=sy+reg["top"]
            above=max(0,absolute-int(vh*.82))
            page.evaluate("(y)=>scrollTo(0,y)",above);time.sleep(.25)
            above_text=page.evaluate("()=>document.body.innerText.slice(0,18000)")
            # Now physically return to the current step/answer.
            page.evaluate("(y)=>scrollTo(0,y)",max(0,absolute-180));time.sleep(.25)
            print(f"Physical navigation: looked above Step {reg['step']}/{reg['total']} then moved down to its answer.",flush=True)
            return {"above_text":above_text[-10000:],"step":reg["step"],"total":reg["total"]}
        page.evaluate("()=>scrollTo(0,0)");time.sleep(.2)
        return {"above_text":page.evaluate("()=>document.body.innerText.slice(0,12000)")}
    except Exception as e:
        print("Physical navigation warning:",repr(e),flush=True);return {"above_text":""}

def interaction_contract(controls):
    out={}
    for c in controls:
        k=c.get("kind");cid=c["id"]
        if k=="choice":out[cid]={"action":"click exact displayed option","options":c.get("options",[])}
        elif k in ("select","dropdown"):out[cid]={"action":"open control and select exact option","options":c.get("options",[])}
        elif k=="input":out[cid]={"action":"enter answer in field; ignore the on-screen keypad as choices"}
        else:out[cid]={"action":"use only this detected answer control"}
    return out


def autonomous_scroll_scan(page):
    """Freely move through the Sparx document, rendering and inspecting all vertical regions."""
    try:
        h=page.evaluate("()=>document.documentElement.scrollHeight")
        vh=page.evaluate("()=>innerHeight")
        cur=page.evaluate("()=>scrollY")
        points=[]
        # Current area, above it, top, then progressively below, then back to active area.
        for y in [cur, max(0,cur-vh*.7), 0]:
            if int(y) not in points: points.append(int(y))
        y=0
        while y < h:
            if int(y) not in points: points.append(int(y))
            y += max(300,int(vh*.65))
        if max(0,h-vh) not in points: points.append(max(0,h-vh))
        snapshots=[]
        for y in points:
            page.evaluate("(y)=>scrollTo(0,y)",y); time.sleep(.08)
            txt=page.evaluate("()=>document.body.innerText")
            snapshots.append({"y":y,"text":txt[max(0,len(txt)-5000):]})
        reg=active_step_region(page)
        if reg:
            sy=page.evaluate("()=>scrollY")
            # active_step_region is viewport-relative, so move current active marker near top.
            page.evaluate("(d)=>scrollBy(0,d)",reg["top"]-180);time.sleep(.12)
        else:
            page.evaluate("(y)=>scrollTo(0,y)",cur)
        print(f"Free scroll scan: inspected {len(points)} vertical positions.",flush=True)
        return snapshots
    except Exception as e:
        print("Free scroll scan warning:",repr(e),flush=True);return []

def regenerate_rejected(page,controls,ans,shot,fp):
    """Force fresh alternatives for every control whose current value Sparx has rejected."""
    rejected=KNOWN_WRONG.get(fp,[])
    badmap=WRONG_BY_CONTROL.get(fp,{})

    # A partial second-chance screen may reject only one field, so checking whole answer dicts is not enough.
    # IMPORTANT: a rejected multi-field submission does NOT prove every field was wrong.
    # Only per-control red/incorrect evidence belongs in the per-field blacklist.
    # Whole rejected dictionaries remain combination-level memory below, so a correct
    # field can be preserved while another field is changed on the second chance.
    forbidden={}
    for cid,vals in badmap.items():
        forbidden.setdefault(cid,[]).extend(str(v) for v in vals)

    def collision(cid,val):
        cv=canon(val)
        return any(cv==canon(v) for v in forbidden.get(cid,[]))

    bad_ids=[cid for cid,val in ans.items() if collision(cid,val)]
    exact_rejected = any(isinstance(old,dict) and old == ans for old in rejected)
    if not bad_ids and not exact_rejected:
        return ans
    # If only the whole combination was rejected, ask for a corrected combination
    # without falsely blacklisting every individual field.
    if exact_rejected and not bad_ids:
        bad_ids=list(ans.keys())

    # High-value correction pattern: Sparx asks for one incorrect word and its replacement.
    # If a rejected pair came from changing a scientifically valid process word, reconsider
    # the whole sentence rather than asking the model to paraphrase the same misconception.
    qtxt=active_question_text(page)
    qlow=qtxt.lower()
    if len(controls)==2 and "one word" in qlow and "incorrect" in qlow and "changed to" in qlow:
        ids=[c.get("id") for c in controls]
        semantic_pairs=[]
        # GCSE science ontology corrections. These are concept relations, not question-specific answers.
        ontology=[
            (r"\bphloem\s+is\s+an?\s+organ\b","organ","tissue"),
            (r"\bxylem\s+is\s+an?\s+organ\b","organ","tissue"),
        ]
        for pat,wrong,repl in ontology:
            if re.search(pat,qlow,re.I): semantic_pairs.append((wrong,repl))
        for wrong,repl in semantic_pairs:
            proposal={ids[0]:wrong,ids[1]:repl}
            if all(not collision(cid,val) for cid,val in proposal.items()):
                print("SEMANTIC RESET: rejected interpretation abandoned; whole-sentence science check found",proposal,flush=True)
                return proposal

    payload={
      "question":active_question_text(page),
      "controls":controls,
      "current_proposal":ans,
      "controls_that_must_change":bad_ids,
      "rejected_answers":rejected,
      "FORBIDDEN_BY_CONTROL":forbidden,
      "sparx_feedback":SPARX_FEEDBACK.get(feedback_key(page),"") or read_sparx_feedback(page)[:5000],
      "knowledge":SCIENCE_KNOWLEDGE,
      "past_experience":relevant_experience(active_question_text(page))
    }
    prompt="""Sparx has explicitly marked one or more current written/input answers WRONG.
Re-solve the CURRENT question from scratch. FORBIDDEN_BY_CONTROL is absolute: no returned value may equal a
forbidden value for that control, even if you previously believed it was correct. If per-control forbidden evidence exists, those controls MUST receive genuinely different answers.
If only the whole multi-field combination was rejected, change at least ONE field but preserve any field that is scientifically correct;
do NOT assume every field in a rejected submission was individually wrong. Re-read the exact grammar and scientific claim; identify what word/concept is
actually wrong rather than defending the previous interpretation. If the task says ONE WORD is incorrect, explicitly test
each scientific noun/verb/adjective in the original sentence and choose a different source word if the previous source word
was rejected; do not keep the same source concept and merely paraphrase its replacement. Preserve only controls that are genuinely confirmed
correct. Use GCSE/AQA terminology and any Sparx feedback/tutorial evidence. Do not merely paraphrase a forbidden
answer. Return ONLY JSON {"answers":{...},"reason":"brief"}, with exactly the supplied active control IDs."""

    expected={c["id"] for c in controls}
    candidate=dict(ans)
    # Stay in alternative generation instead of falling back to page scanning when the model repeats itself.
    for attempt in range(1,5):
        try:
            payload["current_proposal"]=candidate
            payload["alternative_attempt"]=attempt
            r=ask(prompt,json.dumps(payload,ensure_ascii=False),shot)
            new=r.get("answers",{}) if isinstance(r,dict) else {}
            if set(new)!=expected:
                print("ALTERNATIVE RESOLVER: wrong control IDs on attempt",attempt,flush=True)
                continue
            collisions=[cid for cid,val in new.items() if collision(cid,val)]
            unchanged=[cid for cid in bad_ids if cid in new and canon(new[cid])==canon(ans.get(cid,""))]
            if collisions or unchanged:
                print("ALTERNATIVE RESOLVER: rejected repeated values on attempt",attempt,
                      "collisions=",collisions,"unchanged=",unchanged,flush=True)
                candidate=new
                # Make the next request even more explicit about values just repeated.
                for cid in set(collisions+unchanged):
                    forbidden.setdefault(cid,[]).append(str(new.get(cid,"")))
                payload["FORBIDDEN_BY_CONTROL"]=forbidden
                continue
            print("ALTERNATIVE RESOLVER: fresh non-rejected answer:",new,flush=True)
            return new
        except Exception as e:
            print("ALTERNATIVE RESOLVER warning attempt",attempt,repr(e),flush=True)
    print("ALTERNATIVE RESOLVER: no safe fresh answer after 4 attempts; leaving fields empty rather than recycling a known-wrong value.",flush=True)
    return ans


def visual_sweep(page):
    """Physically inspect the page vertically and horizontally for diagrams/values outside the current view."""
    try:
        oldx=page.evaluate("()=>scrollX"); oldy=page.evaluate("()=>scrollY")
        sw=page.evaluate("()=>document.documentElement.scrollWidth")
        sh=page.evaluate("()=>document.documentElement.scrollHeight")
        vw=page.evaluate("()=>innerWidth"); vh=page.evaluate("()=>innerHeight")
        pts=[(0,0),(max(0,sw-vw),0),(0,max(0,sh-vh)),(max(0,sw-vw),max(0,sh-vh))]
        seen=[]
        for x,y in pts:
            page.evaluate("([x,y])=>scrollTo(x,y)",[x,y]);time.sleep(.10)
            seen.append({"x":x,"y":y})
        page.evaluate("([x,y])=>scrollTo(x,y)",[oldx,oldy]);time.sleep(.10)
        print("Visual sweep inspected:",seen,flush=True)
    except Exception as e:print("Visual sweep warning:",repr(e),flush=True)


def deterministic_mcq_guard(question, controls, answer, reason=""):
    """Reject obvious physics contradictions before a Sparx attempt is spent."""
    if len(controls)!=1 or controls[0].get("kind")!="choice":
        return answer
    opts=controls[0].get("options",[])
    q=(repair_text(question)+" "+repair_text(reason)).lower()
    # For positive resistors in parallel, equivalent R is below the smallest branch resistance.
    if "parallel" in q and "resistance" in q:
        less=[o for o in opts if canon(o).startswith("lessthan")]
        between=[o for o in opts if canon(o).startswith("between")]
        if less and answer.get("C1") in between:
            print("Deterministic physics guard: parallel resistance must be below the smallest branch resistance.",flush=True)
            return {"C1":less[0]}
    return answer

def simple_mcq_preflight(page,controls,shot,known_wrong):
    """Fast but independent path for one-control MCQs; avoids unnecessary long pipelines."""
    if len(controls)!=1 or controls[0].get("kind")!="choice":return None
    q=active_question_text(page)
    payload={"question":q,"options":controls[0].get("options",[]),
             "known_wrong":known_wrong,"science_rules":SCIENCE_KNOWLEDGE,
             "experience":relevant_experience(q)}
    prompt="""Solve this AQA GCSE Science multiple-choice question carefully. Inspect the screenshot/diagram.
Test EVERY displayed option against the science, calculations and units. Do not use a known-wrong option.
Return ONLY JSON {"answers":{"C1":"exact displayed option"},"confidence":0.0,"reason":"brief"}.
The C1 value MUST exactly match one supplied option."""
    try:
        r=ask(prompt,json.dumps(payload,ensure_ascii=False),shot)
        a=r.get("answers",{})
        if set(a)=={"C1"} and any(canon(a["C1"])==canon(o) for o in controls[0]["options"]):
            a=deterministic_mcq_guard(q,controls,a,r.get("reason",""))
            print("Fast MCQ preflight:",a,"confidence:",r.get("confidence"),flush=True)
            return a
    except Exception as e:print("Fast MCQ preflight failed; falling back to full solver:",repr(e),flush=True)
    return None


def indexed_mcq_decision(page,controls,shot,wrong):
    """Choose by option INDEX, not copied option text, so Ω/subscripts/mojibake cannot block clicking."""
    if len(controls)!=1 or controls[0].get("kind")!="choice":return None
    opts=controls[0].get("options",[])
    if any(is_utility_choice_text(o) for o in opts):
        opts=[o for o in opts if not is_utility_choice_text(o)]
        controls[0]["options"]=opts
    if len(opts)<2:return None
    q=active_question_text(page)
    numbered=[{"index":i,"text":repair_text(o)} for i,o in enumerate(opts)]
    payload={"question":q,"options":numbered,"known_wrong":wrong,
             "science":SCIENCE_KNOWLEDGE,"experience":relevant_experience(q)}
    prompt="""Solve this AQA GCSE Science multiple-choice question from the screenshot and text.
Return an OPTION INDEX, not copied option text. Independently check the science/calculation first.
For parallel resistors, equivalent resistance is always less than the smallest positive branch resistance.
Return ONLY JSON {"option_index":0,"confidence":0.0,"reason":"brief"}.
option_index must be an integer from 0 to the last supplied index."""
    try:
        r=ask(prompt,json.dumps(payload,ensure_ascii=False),shot)
        oi=int(r.get("option_index",-1))
        reason=str(r.get("reason",""))
        if not (0<=oi<len(opts)):return None
        # Deterministic circuit sanity guard: never spend an attempt on the classic parallel-R contradiction.
        evidence=(q+" "+reason).lower()
        if "parallel" in evidence and "resist" in evidence:
            less=[i for i,o in enumerate(opts) if canon(o).startswith("lessthan")]
            between=[i for i,o in enumerate(opts) if canon(o).startswith("between")]
            if less and oi in between:
                print("Deterministic physics guard changed MCQ index",oi,"->",less[0],flush=True)
                oi=less[0]
        print("Indexed MCQ decision:",oi,repr(opts[oi]),"confidence:",r.get("confidence"),flush=True)
        return {"index":oi,"answer":opts[oi],"reason":reason}
    except Exception as e:
        print("Indexed MCQ decision failed:",repr(e),flush=True)
        return None

def click_choice_index(page,group,index,label):
    """Click a Sparx choice AT MOST ONCE per question/choice until explicit feedback changes the plan.

    Some Sparx cards do not expose checked/aria-selected state. Older builds interpreted that
    missing signal as a failed click and clicked the same answer up to three times, toggling it.
    A successful physical click is now latched; verification is observational and never causes
    another click. Explicit wrong feedback/blacklisting can still choose a different option.
    """
    if not (0<=index<len(group)): return False
    target=group[index]
    try: fp=qfingerprint(page)
    except: fp=(page.url or "")
    latch_key=f"{fp}|{index}|{canon(label)}"
    latched=getattr(page,"_hh_choice_click_latches",set())
    if latch_key in latched:
        print(f"CHOICE LATCH: already clicked index {index} {label!r}; not clicking it again.",flush=True)
        return True
    if choice_is_selected(page,target):
        latched.add(latch_key); page._hh_choice_click_latches=latched
        remember_interaction("choice_click",f"index:{index}",label,True)
        return True
    try:
        clicked=safe_choice_click(page,target,label)
    except Exception:
        clicked=False
    if not clicked:
        remember_interaction("choice_click",f"index:{index}",f"physical click failed for {label}",False)
        return False
    # Latch immediately after ONE successful physical click. Never toggle it by retrying.
    latched.add(latch_key); page._hh_choice_click_latches=latched
    time.sleep(.22)
    verified=choice_is_selected(page,target)
    remember_interaction("choice_click",f"index:{index}",label,True)
    if verified:
        print(f"Choice click verified: index {index} {label!r}",flush=True)
    else:
        print(f"CHOICE LATCH: clicked index {index} {label!r} once; selection state is not exposed, so no re-click will occur.",flush=True)
    return True


def submit_current_answer(page):
    """Submit once after answer entry. Visible Submit + task URL + answer controls is sufficient evidence.

    Do not let the stricter coordinate-fallback safety gate block a real, visible Sparx Submit button.
    """
    if "/tasks/" not in (page.url or ""):
        print("SUBMIT blocked: browser is not on a task URL.",flush=True)
        return False
    # Strong positive evidence: we are on a task, have answer controls, and Sparx exposes Submit/Check.
    # This deliberately bypasses safe_for_visual_fallback(), which is for blind coordinate clicks and
    # was incorrectly rejecting prompts such as 'Complete the sentences...'.
    try:
        has_answer_controls=bool(get_inputs(page) or choices(page) or native_selects(page) or dashed(page) or checkbox_table(page) or is_match_pairs_page(page))
        body=repair_text(page.locator("body").inner_text(timeout=1000)).lower()
        has_submit_text=any(x in body for x in ("submit","check answer"))
    except:
        has_answer_controls=False; has_submit_text=False
    if not (has_answer_controls and has_submit_text) and not safe_for_visual_fallback(page):
        print("SUBMIT blocked: no positive question/answer evidence yet.",flush=True)
        return False
    before_url=page.url
    try: before_text=repair_text(page.locator("body").inner_text(timeout=1200))
    except: before_text=""
    if not nav(page,["Check","Submit","Check answer"],allow_scroll=False):
        # Only move the page if Submit genuinely wasn't found in the current DOM/viewport.
        print("SUBMIT: not immediately visible; moving to the answer footer once.",flush=True)
        try:
            page.evaluate("()=>scrollTo(0,document.documentElement.scrollHeight)")
            time.sleep(.18)
        except:pass
        if not nav(page,["Check","Submit","Check answer"],allow_scroll=False):
            remember_interaction("submit","current_answer","no submit/check control found",False)
            print("SUBMIT: selected answer kept; no Submit/Check control found yet.",flush=True)
            return False
    print("SUBMIT: clicked once; waiting for Sparx to respond.",flush=True)
    deadline=time.time()+6
    while time.time()<deadline:
        time.sleep(.2)
        try:
            now=repair_text(page.locator("body").inner_text(timeout=800))
            low=now.lower()
            if page.url!=before_url or now!=before_text:
                if any(x in low for x in ("correct","incorrect","try again","retry","continue","next question","second chance","results")) or now!=before_text:
                    remember_interaction("submit","current_answer","state changed",True)
                    return True
        except:pass
    remember_interaction("submit","current_answer","clicked but no visible state change yet",False)
    return True


def checkbox_table(page):
    """Detect a Sparx matrix and capture row/column geometry plus CURRENT checked state."""
    try:
        return page.evaluate(r"""()=>{
          const vis=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'};
          const selected=c=>{
            const inp=c.querySelector('input[type=checkbox],input[type=radio]');
            if(inp && inp.checked) return true;
            const a=(c.getAttribute('aria-checked')||c.getAttribute('aria-selected')||'').toLowerCase();
            if(a==='true') return true;
            const d=c.querySelector('[aria-checked=true],[aria-selected=true],input:checked'); if(d) return true;
            const cl=((c.className||'')+' '+((c.firstElementChild&&c.firstElementChild.className)||'')).toLowerCase();
            return /checked|selected|active/.test(cl);
          };
          for(const t of [...document.querySelectorAll('table')].filter(vis)){
            const allRows=[...t.querySelectorAll('tr')].filter(vis); if(allRows.length<3) continue;
            const headRow=allRows.find(r=>[...r.querySelectorAll('th')].filter(vis).length>=2)||allRows[0];
            let headers=[...headRow.querySelectorAll('th,td')].map(x=>(x.innerText||x.textContent||'').replace(/\\s+/g,' ').trim()).filter(Boolean);
            const rows=[];
            for(const tr of allRows){
              if(tr===headRow) continue;
              const cells=[...tr.querySelectorAll(':scope > th,:scope > td')].filter(vis); if(cells.length<3) continue;
              const label=(cells[0]?.innerText||cells[0]?.textContent||'').replace(/\\s+/g,' ').trim(); if(!label) continue;
              const ac=cells.slice(1);
              rows.push({label,count:ac.length,cells:ac.map(c=>{const r=c.getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2,selected:selected(c)}})});
            }
            if(rows.length>=2){const maxc=Math.max(...rows.map(r=>r.count)); if(headers.length>=maxc) headers=headers.slice(-maxc); return {headers,rows,custom:true};}
          }
          return null;
        }""")
    except Exception:return None

def solve_checkbox_table(page, table):
    """Solve grid semantically, then click ONLY cells whose current checked state differs from target."""
    feedback=read_sparx_feedback(page)
    previous=LAST_ATTEMPT.get('answers') if LAST_ATTEMPT else None
    q=active_question_text(page)[:10000]
    multi=any(x in canon(q) for x in ('selectall','tickall','chooseall','oneormore','allthatapply','allcorrect'))
    prompt="""You are solving an AQA GCSE Science TABLE/GRID question from a screenshot. Treat each row as its own mini-question. Read the instruction to decide whether a row needs ONE box or MAY need MULTIPLE boxes. Return ONLY JSON {\"answers\":{\"T1\":[\"exact header\"],\"T2\":[\"exact header\"]},\"reason\":\"brief\"}. Values are ALWAYS lists, even for one box. Solve every row from science, not by copying the current checked pattern. On a second chance, current checks are editable: compute the correct target state and change them. Preserve a current box only if it belongs in the correct target. Never use Skip."""
    payload={'question':q,'selection_hint':'multiple per row allowed' if multi else 'normally one per row unless wording/science requires more','headers':table.get('headers',[]),'rows':[{'label':r.get('label'),'current':[j for j,c in enumerate(r.get('cells',[])) if c.get('selected')]} for r in table.get('rows',[])],'feedback':feedback,'previous_rejected_attempt':previous}
    # Deterministic curriculum guard for common cell/tissue/organ classification grids.
    # This is semantic, not coordinate-specific, and prevents a capable model from being overruled by stale context.
    qcan=canon(q); hcan=[canon(x) for x in table.get('headers',[])]
    deterministic=None
    # Deterministic GCSE plant-transport matrix guard. This is a curriculum rule, not a page-coordinate hack.
    # It covers tables such as Water / Dissolved sugars / Mineral ions vs Phloem / Xylem.
    if all(x in hcan for x in ('phloem','xylem')):
        plant_transport={'water':'xylem','dissolved sugars':'phloem','mineral ions':'xylem','sucrose':'phloem','sugars':'phloem'}
        da={}; ok=True
        for i,row in enumerate(table.get('rows',[])):
            lab=canon(row.get('label','')); target=None
            for k,v in plant_transport.items():
                if canon(k)==lab: target=v; break
            if not target: ok=False; break
            exact=next((h for h in table.get('headers',[]) if canon(h)==canon(target)),None)
            if not exact: ok=False; break
            da[f'T{i+1}']=[exact]
        if ok and da:
            deterministic={'answers':da,'reason':'GCSE plant transport: water/mineral ions in xylem, dissolved sugars in phloem'}
            print('TABLE MODE: deterministic GCSE plant-transport guard =>',da,flush=True)
    if deterministic is None and all(x in hcan for x in ('cell','tissue','organ')) and all(x in qcan for x in ('cell','tissue','organ')):
        known={'leaf':'organ','stem':'organ','root':'organ','flower':'organ','root hair cell':'cell','guard cell':'cell','sperm cell':'cell','egg cell':'cell','xylem':'tissue','phloem':'tissue','epithelial tissue':'tissue','muscle tissue':'tissue'}
        da={}; ok=True
        for i,row in enumerate(table.get('rows',[])):
            lab=canon(row.get('label','')); target=None
            for k,v in known.items():
                if canon(k)==lab: target=v; break
            if not target: ok=False; break
            exact=next((h for h in table.get('headers',[]) if canon(h)==canon(target)),None)
            if not exact: ok=False; break
            da[f'T{i+1}']=[exact]
        if ok and da:
            deterministic={'answers':da,'reason':'GCSE biological organisation classification'}
            print('TABLE MODE: deterministic GCSE organisation guard =>',da,flush=True)
    r=deterministic or ask(prompt,json.dumps(payload,ensure_ascii=False),page.screenshot())
    ans=r.get('answers',{}) if isinstance(r,dict) else {}
    headers=table.get('headers',[]); maxc=max((x.get('count',0) for x in table.get('rows',[])),default=0)
    cols=headers[-maxc:] if maxc and len(headers)>=maxc else headers
    if len(ans)!=len(table.get('rows',[])) or len(cols)<2:return False
    targets=[]; final={}
    for i,row in enumerate(table['rows']):
        vals=ans.get(f'T{i+1}',[]); vals=[vals] if isinstance(vals,str) else vals
        if not isinstance(vals,list) or not vals:return False
        idx=[]
        for val in vals:
            m=next((j for j,h in enumerate(cols) if canon(h)==canon(val)),None)
            if m is None:return False
            idx.append(m)
        idx=sorted(set(idx)); targets.append(set(idx)); final[f'T{i+1}']=[cols[j] for j in idx]
    fp=qfingerprint(page)
    for old in KNOWN_WRONG.get(fp,[]):
        if isinstance(old,dict) and old==final:
            print('TABLE MODE: rejected target repeated; requesting a fresh solve next pass.',flush=True); return False
    try:
        for i,row in enumerate(table['rows']):
            cells=row.get('cells',[]); current={j for j,c in enumerate(cells) if c.get('selected')}
            for j in sorted(current.symmetric_difference(targets[i])):
                if j>=len(cells):return False
                pt=cells[j]; page.mouse.click(float(pt['x']),float(pt['y'])); time.sleep(.14)
    except Exception:return False
    LAST_ATTEMPT.clear(); LAST_ATTEMPT.update({'fingerprint':fp,'answers':final})
    print('TABLE MODE: applied checked-state diff:',final,flush=True)
    return True

def is_multi_select_question(page, controls):
    """Detect explicit multi-select wording even on multipart questions with several choice groups."""
    choice_controls=[c for c in controls if c.get("kind")=="choice"]
    if not choice_controls: return False
    q=canon(active_question_text(page))
    phrases=("selectallcorrectanswers","selectallthatapply","chooseallcorrectanswers","chooseallthatapply",
             "selectallanswers","tickallcorrect","tickallthatapply","chooseevery","oneormore")
    return any(x in q for x in phrases)

def solve_multi_select(page, controls, shot):
    """Solve one or more multipart choice groups where each group may require several selected cards."""
    choice_controls=[c for c in controls if c.get("kind")=="choice"]
    if not choice_controls:return False
    groups=choices(page)
    # A single Sparx multi-select can be discovered twice when its cards wrap across rows. Collapse
    # identical option sets before asking the model, otherwise one visible question becomes fake M1/M2 parts.
    compact=[]; compact_groups=[]; seen=[]
    for c,g in zip(choice_controls,groups):
        key=tuple(canon(x) for x in c.get('options',[]))
        if key and key in seen: continue
        seen.append(key); compact.append(c); compact_groups.append(g)
    choice_controls=compact; groups=compact_groups
    if len(groups)<len(choice_controls):return False
    options=[c.get("options",[]) for c in choice_controls]
    prompt="""Solve this AQA GCSE Science MULTI-SELECT / MULTIPART question from the screenshot.
The wording explicitly says selections such as 'Select all correct answers', so DO NOT force one answer per part.
Treat EACH visible sub-question (a, b, etc.) independently. Inspect graphs/diagrams visually and decide whether
EVERY displayed option is correct for that part. Return the COMPLETE desired selection set for every group.
Return ONLY JSON like {\"groups\":[[0,2],[1,3]],\"reason\":\"brief\"}. Each inner list contains zero-based
option indexes for that choice group. A group may contain ONE OR SEVERAL indexes. Preserve visibly green/ticked
answers on a second chance unless the screenshot clearly shows they are not part of that group."""
    payload={"question":active_question_text(page)[:16000],"groups":options,
             "instruction":"Select all correct answers; multipart groups may each have multiple answers"}
    q=canon(active_question_text(page))
    if 'neon' in q and 'electronconfiguration' in q and len(options)==1:
        import re as _re
        atomic={'na':11,'mg':12,'f':9,'k':19,'cl':17}
        hits=[]
        for j,opt in enumerate(options[0]):
            raw=opt.lower().translate(str.maketrans('⁺⁻²³','+-23'))
            clean=_re.sub(r'\s+','',raw)
            m=_re.match(r'^(na|mg|f|k|cl)([0-9]*)([+-])$',clean)
            if m:
                charge=int(m.group(2) or '1')*(1 if m.group(3)=='+' else -1)
                if atomic[m.group(1)]-charge==10:hits.append(j)
        r={'groups':[hits]} if hits else ask(prompt,json.dumps(payload,ensure_ascii=False),shot)
        if hits:print('MULTI-SELECT: neon electron count indices',hits,flush=True)
    else:r=ask(prompt,json.dumps(payload,ensure_ascii=False),shot)
    raw=r.get("groups",[]) if isinstance(r,dict) else []
    if not isinstance(raw,list) or len(raw)!=len(choice_controls):return False
    desired=[]
    try:
        for gi,vals in enumerate(raw):
            if not isinstance(vals,list):return False
            idxs=sorted(set(int(x) for x in vals))
            if not idxs or any(i<0 or i>=len(options[gi]) for i in idxs):return False
            desired.append(set(idxs))
    except:return False
    final={}
    for gi,(g,wanted) in enumerate(zip(groups,desired)):
        opts=options[gi]
        if len(g)<len(opts):return False
        for i,item in enumerate(g[:len(opts)]):
            selected=choice_is_selected(page,item)
            should=i in wanted
            # On retries, a visibly selected/green correct option remains selected if the model includes it.
            if selected != should:
                if not safe_choice_click(page,item,opts[i]):return False
                time.sleep(.12)
        final[f"M{gi+1}"]=[opts[i] for i in sorted(wanted)]
    fp=qfingerprint(page)
    LAST_ATTEMPT.clear();LAST_ATTEMPT.update({"fingerprint":fp,"answers":final})
    print("MULTI-SELECT MULTIPART MODE: selected",final,flush=True)
    return True

def vision_first_plan(page, controls, shot, wrong=None):
    """Use the screenshot as the primary understanding layer, then map back to DOM controls."""
    q=active_question_text(page)[:16000]
    prompt="""You are the PRIMARY visual solver for an AQA GCSE Science question.
Study the SCREENSHOT FIRST as if you were a student looking at the whole question. Use the extracted text and
DOM controls only as supporting metadata. Read diagrams, arrows, labels, superscripts, subscripts, tables,
row/column relationships, graphs, axes, units, selected states, red crosses, green ticks, tutorial steps and
multipart structure. Do not infer a generic diagram when the screenshot shows the actual one.

BEFORE solving, silently classify each requested answer as one of: NUMBER, UNIT, SCIENTIFIC_QUANTITY, TYPE/PROPERTY, COMPONENT/OBJECT, PROCESS, TERM, or EXPLANATION. Check the grammar around every blank. A common failure is giving a source/example when the question asks for the TYPE of a quantity; never do that. Use the trusted GCSE/AQA terminology rules supplied by the program.

Return ONLY JSON in this shape:
{"answers":{"C1":{"index":0},"I1":"value"},"reason":"brief visual reasoning including required answer category","confidence":0.95}
For C/S/D controls, prefer a ZERO-BASED option index so corrupted Unicode cannot change the intended option.
For I controls return the exact text/number to enter. Return exactly one answer for every active control.
If this is a correction/second chance, preserve visibly green/correct parts and change visibly red/wrong parts.
Never choose Submit, Skip, I don't know, Report Problem, question tabs, Results, navigation or keypad digits as answers.
For a numeric field with a unit printed outside the box, return the number only.
Before returning, independently recompute calculations and check the chosen answer against the screenshot."""
    payload={"question_text":q,"controls":controls,"known_wrong":wrong or [],
             "feedback":read_sparx_feedback(page)[:5000],"layout":layout_profile(page)}
    try:
        r=ask(prompt,json.dumps(payload,ensure_ascii=False),shot)
        raw=r.get("answers",{}) if isinstance(r,dict) else {}
        out={}
        for c in controls:
            cid=c["id"]
            if cid not in raw:return None
            v=raw[cid]
            if c["kind"] in ("choice","select","dropdown"):
                opts=c.get("options",[])
                idx=None
                if isinstance(v,dict):idx=v.get("index")
                elif isinstance(v,int):idx=v
                if idx is not None:
                    try:idx=int(idx)
                    except:return None
                    if idx<0 or idx>=len(opts):return None
                    out[cid]=opts[idx]
                else:
                    mapped=match_option(v,opts)
                    if not mapped:return None
                    out[cid]=mapped
            else:
                out[cid]=str(v)
        print("VISION FIRST plan:",out,"confidence:",r.get("confidence"),flush=True)
        print("VISION FIRST reason:",r.get("reason",""),flush=True)
        return {"answers":out,"reason":r.get("reason",""),"confidence":r.get("confidence",0)}
    except Exception as e:
        print("VISION FIRST warning:",repr(e),flush=True)
        return None

def semantic_science_guard(page, controls, ans):
    """High-confidence GCSE relations used to stop model/control mapping contradictions."""
    q=repair_text(active_question_text(page)).lower()
    out=dict(ans or {})
    # Series circuit: one broken lamp opens the ONLY current path. Apply to
    # each current choice group separately; do not reuse stale teaching C2.
    if ("series circuit" in q and "lamp" in q and "break" in q):
        for c in controls:
            if c.get("kind")!="choice": continue
            opts=c.get("options",[])
            for wanted in ("All the lamps go out", "There is only one path for the current"):
                exact=match_option(wanted,opts)
                if exact is not None:
                    out[c["id"]]=exact
                    break
        print("SEMANTIC SCIENCE GUARD: open series circuit =>",out,flush=True)
    # Plant transport table: xylem transports water by transpiration; phloem transports dissolved sugars by translocation.
    if len(controls)>=2 and all(c.get("kind")=="choice" for c in controls[:2]) and "xylem" in q and "phloem" in q:
        opts=controls[0].get("options",[])
        # Resolve letters from the visible A-F table text rather than trusting a model letter.
        lines=[repair_text(x).strip() for x in active_question_text(page).splitlines() if repair_text(x).strip()]
        rows={}
        for line in lines:
            m=re.match(r"^([A-F])\s+(.+)$",line,re.I)
            if m: rows[m.group(1).upper()]=m.group(2).lower()
        def findrow(words):
            for k,v in rows.items():
                if all(w in v for w in words): return k
        x=findrow(["water","transpiration"])
        ph=findrow(["dissolved","sugar","translocation"])
        if x in opts and ph in controls[1].get("options",[]):
            out[controls[0]["id"]]=x; out[controls[1]["id"]]=ph
            print("SEMANTIC SCIENCE GUARD: plant transport chain =>",out,flush=True)
    # Direct plant-transport written questions: distinguish TISSUE from TRANSPORT METHOD.
    # This prevents answers such as "phloem" when the question explicitly asks for the method.
    if controls and all(c.get("kind")=="input" for c in controls):
        if "plant tissue" in q and "transports water" in q and "transport method" in q and "dissolved sugars" in q:
            if len(controls) >= 1:
                out[controls[0]["id"]]="xylem"
            if len(controls) >= 2:
                out[controls[1]["id"]]="translocation"
            print("SEMANTIC SCIENCE GUARD: tissue-vs-method plant transport =>",out,flush=True)
        elif "transport method" in q and "dissolved sugars" in q and len(controls)==1:
            out[controls[0]["id"]]="translocation"
            print("SEMANTIC SCIENCE GUARD: dissolved-sugar transport method => translocation",flush=True)
    # Xylem sentence vocabulary: mature vessel cells are hollow and lignified.
    if "xylem tissue is formed from" in q and "cells" in q:
        for c in controls:
            opts=c.get("options",[])
            if any(canon(o)=="hollow" for o in opts): out[c["id"]]=next(o for o in opts if canon(o)=="hollow")
            if any(canon(o)=="lignin" for o in opts): out[c["id"]]=next(o for o in opts if canon(o)=="lignin")
        print("SEMANTIC SCIENCE GUARD: xylem vocabulary =>",out,flush=True)
    return out

def solve(page):
    save_active_task(page)
    # Connector matching layouts do not expose ordinary inputs/radios, so detect them first.
    if is_match_pairs_page(page):
        print("MATCH_PAIRS mode detected: solving the complete mapping once.",flush=True)
        return solve_match_pairs(page)
    if not is_question_page(page):
        print("No rendered question controls found yet.")
        return False
    stable(page)
    navctx=physically_inspect_context(page)
    # Always initialise free-scroll memory before any prompt construction.
    scroll_memory=autonomous_scroll_scan(page)
    visual_sweep(page)
    visible_feedback=read_sparx_feedback(page)
    if visible_feedback:
        fk=feedback_key(page)
        if SPARX_FEEDBACK.get(fk)!=visible_feedback:
            SPARX_FEEDBACK[fk]=visible_feedback
            print("Detected existing Sparx second-chance feedback BEFORE solving:",flush=True)
            print(visible_feedback[:1800],flush=True)
    profile=layout_profile(page)
    print("Active layout:",profile,flush=True)
    if profile.get("step"):
        print(f"Tutorial Step {profile['step']}/{profile['total']} detected; scoping controls to this step.",flush=True)
    ins=get_inputs(page); rows=choices(page); sels=native_selects(page); ds=dashed(page)
    # Avoid double counting native selects if dashed styling happens to overlap.
    reg=active_step_region(page)
    if reg: ds=[b for b in ds if b.get("y",0)>=reg["top"] and b.get("y",0)<reg["bottom"]]
    dopt=[popup_options(page,b) for b in ds]
    ropt=[[repair_text(x["text"]) for x in g] for g in rows]
    controls=[]
    for i,o in enumerate(ropt):controls.append({"id":f"C{i+1}","kind":"choice","options":o})
    for i,(e,o) in enumerate(sels):controls.append({"id":f"S{i+1}","kind":"select","options":o})
    for i,o in enumerate(dopt):controls.append({"id":f"D{i+1}","kind":"dropdown","options":o})
    for i in range(len(ins)):controls.append({"id":f"I{i+1}","kind":"input"})
    if not controls:
        table=checkbox_table(page)
        if table:
            print("TABLE MODE: detected checkbox matrix with",len(table.get("rows",[])),"rows.",flush=True)
            return solve_checkbox_table(page,table)
        return False
    contract=interaction_contract(controls)
    print("Interaction contract:",contract,flush=True)

    # Explicit multi-select questions must bypass the single-answer MCQ pipeline.
    # Example: "Select all correct answers" can require Na+, F- and Mg2+ simultaneously.
    if is_multi_select_question(page,controls):
        print("MULTI-SELECT MODE: instruction allows more than one answer.",flush=True)
        shot=inspect_full_page(page)
        return solve_multi_select(page,controls,shot)

    prompt="""You solve AQA GCSE Science questions: Combined Science Trilogy and relevant separate-science GCSE
Biology, Chemistry and Physics knowledge. Use GCSE equations, units, required-practical reasoning,
graphs/data and precise scientific terminology. Base the answer on the ACTUAL visible question.
Return ONLY JSON: {"answers":{"C1":"exact option","I1":"text"},"reason":"brief"}.
The supplied control IDs are authoritative. Return exactly one value for every supplied ID and NO other IDs.
Never invent a choice control from an on-screen numeric keypad. Labels such as backspace, negate, digits,
minus and decimal are input aids, not answers.
For a choice/select/dropdown, copy an option exactly, including subscripts/superscripts when possible.
Do not rewrite R₂ as R_2 or alter the displayed option text. For input boxes, return only text to type.
If a unit such as A, V, ohms, J, W, kg or m/s is already printed beside a numeric box, return ONLY the number.
For circuit questions, inspect the actual diagram: current is conserved at junctions; add branch currents for
a main wire and use the branch current only inside that branch. Do not assume two labelled points have the
same current unless the diagram shows they are on the same unbranched path.
For word-bank sentence questions use the exact supplied word(s).
For written explain/describe questions, write a concise GCSE mark-scheme style response with enough linked
scientific points for the stated marks. Return the complete written response as the input value.
Before returning answers, internally check every calculation and compare numerical results with the
available options. Never choose an option that contradicts your own arithmetic.
LAYOUT RULES: multiple-choice -> return exact displayed option; numeric box -> number only if unit is printed;
written/textarea -> complete mark-scheme-style sentence(s); dropdown -> exact option; multi-input -> answer each
input ID independently; tutorial/correction mode -> answer ONLY the current active Step, never completed steps;
on-screen number keypad buttons are input aids and NEVER multiple-choice answers. Solve all ACTIVE parts."""
    # Always capture the active Sparx page. This lets the vision model inspect circuit
    # diagrams, graphs, tables, apparatus, ray diagrams, biological drawings, labels, etc.
    shot=inspect_full_page(page)
    fp=qfingerprint(page)
    wrong=KNOWN_WRONG.get(fp,[])
    visual_primary=vision_first_plan(page,controls,shot,wrong)
    indexed_choice=None
    visual_hint="""
IMPORTANT VISUAL INSTRUCTION:
Inspect the screenshot as well as the extracted text. If the question says "diagram", "image",
"graph", "table", "figure", "shown", "above", "below", "circuit", or otherwise depends on a
visual, treat the screenshot as essential evidence. Read labels, scales, axes, arrows, symbols,
component connections and relative positions from the image. Do not guess a standard diagram
from the wording. Solve the exact visual shown.
"""
    prior_feedback=SPARX_FEEDBACK.get(feedback_key(page),"")
    correction_note=""
    if prior_feedback:
        correction_note="\n\nSPARX FEEDBACK FROM THE PREVIOUS ATTEMPT:\n"+prior_feedback[:6000]+"""
\nThis is a SECOND-CHANCE CORRECTION. The Sparx feedback is a HARD REQUIREMENT.
Keep the points that earned marks, then explicitly answer every item under How to improve and every Hint.
If the hint asks how current changes, explicitly state whether TOTAL CURRENT increases/decreases and connect that to resistance using the correct physics (for example R=V/I at fixed potential difference when appropriate).
Do NOT explain lower parallel resistance by saying current takes a "shorter path".
Do not repeat or merely paraphrase an answer Sparx has already marked incomplete."""
    qtext=active_question_text(page)[:15000]
    memory_note="\n\nLOCAL VERIFIED SCIENCE KNOWLEDGE:\n"+SCIENCE_KNOWLEDGE
    memory_note+="\n\nCONTEXT PHYSICALLY READ ABOVE THE ACTIVE ANSWER:\n"+navctx.get("above_text","")[-10000:] 
    memory_note+="\n\nFREE-SCROLL PAGE INSPECTION:\n"+json.dumps(scroll_memory,ensure_ascii=False)[-12000:]
    memory_note+="\n\nEXACT INTERACTION CONTRACT:\n"+json.dumps(contract,ensure_ascii=False)
    imported=imported_knowledge(qtext)
    if imported:
        memory_note+="\n\nRETRIEVED USER STUDY/TEXTBOOK KNOWLEDGE:\n"+imported
    exp=relevant_experience(qtext)
    if exp:
        memory_note+="\n\nRELEVANT PAST SPARX EXPERIENCE (confirmed results):\n"+json.dumps(exp,ensure_ascii=False)
    teaching_ans=teaching_grounded_answers(page,controls,shot)
    if teaching_ans:
        r={"answers":teaching_ans,"reason":"Authoritative Sparx teaching/reveal evidence"}
        ans=dict(teaching_ans)
        print("Controls:",controls); print("Teaching-grounded answer:",ans)
    elif visual_primary:
        r=visual_primary
        ans=r.get("answers",{})
        print("Controls:",controls);print("Visual-first answer:",ans)
    else:
        # Compatibility fallback: retain the mature text+vision solver if the structured visual pass fails.
        r=ask(prompt+visual_hint+memory_note,"QUESTION:\n"+qtext+"\n\nCONTROLS:\n"+json.dumps(controls,ensure_ascii=False)+correction_note,shot)
        ans=r.get("answers",{})
        print("Controls:",controls);print("Fallback first answer:",ans);print("First reason:",r.get("reason",""))
    fast_answer=None
    if fast_answer:
        ans=fast_answer
        # Still pass through hard blacklist/canonical checks below, but skip redundant verifier calls.
        print("Using fast MCQ answer; retaining deterministic safety checks.",flush=True)
    if wrong:
        print("Known wrong attempts for this question:",wrong)
    teaching_locked=bool(teaching_ans)
    if teaching_locked:
        print("TEACHING LOCK: ordinary verifier/preflight cannot override Sparx-provided evidence.",flush=True)
    if not fast_answer and not indexed_choice and not teaching_locked:
        try:
            check=verify_solution(page,controls,{"answers":ans,"reason":r.get("reason","")},shot,wrong)
            checked=check.get("answers",{})
            print("Verifier answer:",checked)
            print("Verifier check:",check.get("check",""))
            print("Verifier confidence:",check.get("confidence",""))
            solver_before_verify=dict(ans)
            verifier_conf=float(check.get("confidence",0) or 0)
            consensus = bool(checked) and all(canon(checked.get(k,""))==canon(solver_before_verify.get(k,"")) for k in solver_before_verify if k in checked) and verifier_conf >= 0.82
            if checked:
                expected_now={c["id"] for c in controls}
                if set(checked)==expected_now:
                    ans=checked
                else:
                    print("VERIFIER FRESHNESS GUARD: ignored stale control IDs",set(checked),"expected",expected_now,flush=True)
                    checked={}
            if consensus:
                print("SMART CONSENSUS: independent solver + verifier agree; skipping redundant preflight.",flush=True)
        except Exception as ex:
            consensus=False
            print("Verifier error; keeping first proposal:",repr(ex))
    else:
        consensus=False
    ans=deterministic_mcq_guard(qtext,controls,ans,r.get("reason",""))
    ans=semantic_science_guard(page,controls,ans)
    if not fast_answer and not indexed_choice and not teaching_locked:
        ans=feedback_compliance(page,controls,ans,shot)
    if teaching_locked:
        # Absolute priority: restore the answer grounded in Sparx's own reveal/teaching card
        # after all generic science guards. No model layer may mutate it.
        ans=dict(teaching_ans)
    pre={} if (fast_answer or indexed_choice or consensus or teaching_locked) else deep_preflight(page,controls,ans,shot,wrong)
    if pre.get("answers"):
        pre_ans=pre["answers"]
        print("Deep preflight answer:",pre_ans,flush=True)
        print("Deep preflight check:",pre.get("check",""),flush=True)
        print("Deep preflight confidence:",pre.get("confidence",""),flush=True)
        # v24.8: a later verifier is NEVER allowed to resurrect an answer Sparx already rejected.
        # Keep the earlier non-rejected candidate instead of letting a weaker stage overwrite it.
        if any(pre_ans==bad for bad in wrong):
            print("REJECTION GUARD: ignored preflight because it proposed a Sparx-confirmed wrong answer; keeping",ans,flush=True)
        else:
            badmap=WRONG_BY_CONTROL.get(fp,{})
            violates=False
            for cid,val in pre_ans.items():
                if canon(val) in badmap.get(cid,set()):
                    violates=True; print("REJECTION GUARD: preflight tried rejected value",cid,repr(val),flush=True)
            if not violates:
                # Preflight is a critic, not a dictator. A disagreement triggers caution but does not
                # silently replace a valid earlier answer unless its confidence is very high.
                pc=float(pre.get("confidence",0) or 0)
                if pc >= 0.94:
                    ans=pre_ans
                    print("PRE-FLIGHT: accepted high-confidence correction.",flush=True)
                else:
                    print("PRE-FLIGHT: advisory disagreement ignored (confidence below 0.94); keeping",ans,flush=True)
    expected={x["id"] for x in controls}
    if set(ans)!=expected:
        print("RECOVERY QUESTION REBIND: stale answer/control IDs detected; discarding old mapping",set(ans),"->",expected,flush=True)
        # Sparx can replace a repeatedly-missed question with an easier recovery question without changing
        # the task URL. Re-read the CURRENT screenshot and CURRENT controls instead of failing/scrolling.
        fresh_shot=inspect_full_page(page)
        fresh=vision_first_plan(page,controls,fresh_shot,KNOWN_WRONG.get(qfingerprint(page),[]))
        fresh_ans=(fresh or {}).get("answers",{})
        if set(fresh_ans)==expected:
            ans=fresh_ans
            print("RECOVERY QUESTION REBIND: fresh current-control answer:",ans,flush=True)
        else:
            print("Answer/control mismatch after fresh rebind:",expected-set(fresh_ans),set(fresh_ans)-expected,flush=True)
            return False

    # Canonicalise model answers to the exact text Sparx displays.
    # This handles R_2 vs R₂, zero-width spaces, subscripts and harmless formatting.
    for x in controls:
        if "options" in x:
            if indexed_choice and x["id"]=="C1":
                ans[x["id"]]=x["options"][indexed_choice["index"]]
                continue
            m=match_option(ans[x["id"]],x["options"])
            if not m:
                print("Invalid option:",x["id"],ans[x["id"]],"available:",x["options"])
                remember_interaction("option_mapping",ans[x["id"]],repr(x["options"]),False)
                return False
            ans[x["id"]]=m
            remember_interaction("option_mapping",ans[x["id"]],m,True)

    # If this exact answer was rejected before, actively create a different one BEFORE interaction.
    ans=regenerate_rejected(page,controls,ans,shot,fp)

    # HARD BLACKLIST: confirmed Sparx-wrong answers can never be clicked again.
    rejected=KNOWN_WRONG.get(fp,[])
    if any(ans==bad for bad in rejected):
        print("HARD BLACKLIST blocked repeated rejected answer:",ans,flush=True)
        # Deterministic escape for a single choice with only one non-rejected option.
        if len(controls)==1 and controls[0].get("kind")=="choice":
            cid=controls[0]["id"]; opts=controls[0].get("options",[])
            badvals={canon(x.get(cid,"")) for x in rejected if isinstance(x,dict)}
            allowed=[o for o in opts if canon(o) not in badvals]
            if len(allowed)==1:
                ans[cid]=allowed[0]
                print("Only non-rejected option remains; using:",allowed[0],flush=True)
            else:
                print("Re-solving required: AI returned a blacklisted answer and multiple alternatives remain.",flush=True)
                return False
        else:
            print("Rejected answer still proposed. Clearing editable controls and requesting another solve cycle.",flush=True)
            try:
                for _e in get_inputs(page):
                    try: _e.fill("")
                    except: pass
            except: pass
            return False

    # Partial-mark protection: never change an answer Sparx has already marked green.
    locks=PARTIAL_LOCKS.get(fp,{})
    for cid,val in locks.items():
        if cid in ans:
            if canon(ans[cid])!=canon(val):
                print("PARTIAL LOCK restored",cid,repr(val),"instead of",repr(ans[cid]),flush=True)
            ans[cid]=val

    # Per-control hard blacklist: a red option can never be selected again on this question.
    badmap=WRONG_BY_CONTROL.get(fp,{})
    for c in controls:
        cid=c["id"]
        if cid not in ans or canon(ans[cid]) not in badmap.get(cid,set()):continue
        if c.get("kind")=="choice":
            allowed=[o for o in c.get("options",[]) if canon(o) not in badmap.get(cid,set())]
            if len(allowed)==1:
                print("PARTIAL RETRY: only one non-rejected option remains for",cid,repr(allowed[0]),flush=True)
                ans[cid]=allowed[0]
            else:
                print("PARTIAL RETRY blocked another known-wrong value for",cid,repr(ans[cid]),flush=True)
                return False
        else:
            print("PARTIAL RETRY: written/input value is still rejected; forcing alternative resolver for",cid,flush=True)
            ans=regenerate_rejected(page,controls,ans,shot,fp)
            if canon(ans.get(cid,"")) in badmap.get(cid,set()):
                print("PARTIAL RETRY: no safe alternative yet; keeping fields clear and retrying reasoning without page scan.",flush=True)
                try:
                    for _e in get_inputs(page):
                        try: _e.fill("")
                        except: pass
                except: pass
                return False

    LAST_ATTEMPT.clear()
    LAST_ATTEMPT.update({"fingerprint":fp,"answers":dict(ans)})
    print("Verified final answers:",ans)

    # Choice latch: once a choice has been physically clicked for this exact question,
    # never click it again while waiting for Submit. Sparx choices are toggles, so a
    # second identical click DESELECTS the answer (the v25.13 on/off loop).
    _choice_fp = fp
    try:
        if getattr(page, "_hh_choice_latch_fp", None) != _choice_fp:
            page._hh_choice_latch_fp = _choice_fp
            page._hh_choice_latch = {}
    except Exception:
        pass

    for i,g in enumerate(rows):
        val=ans[f"C{i+1}"]
        _cid=f"C{i+1}"
        try:
            _latched = getattr(page, "_hh_choice_latch", {}).get(_cid)
        except Exception:
            _latched = None
        if _latched is not None and canon(_latched)==canon(val):
            print(f"CHOICE LATCH: {_cid} {val!r} already clicked; preserving it while waiting for Submit.",flush=True)
            continue
        if indexed_choice and i==0:
            idx=indexed_choice["index"]
            if not click_choice_index(page,g,idx,val):
                print("Indexed choice could not be physically selected:",idx,repr(val),flush=True)
                return False
            print(f"Selected indexed choice {idx}: {val}",flush=True)
            try: page._hh_choice_latch[_cid]=val
            except Exception: pass
            continue
        opts=controls[i].get("options",[]) if i < len(controls) else []
        try: idx=opts.index(val)
        except: idx=-1
        clicked=False
        if idx>=0 and idx<len(g):
            try:
                clicked=click_choice_index(page,g,idx,val)
            except Exception as ex:print("Direct choice click failed:",repr(ex))
        if not clicked and not click_text(page,val):
            remember_interaction("choice_click",val,"text/index click failed",False)
            print(f"Could not click choice {i+1}: {canon(val)}")
            return False
        try: page._hh_choice_latch[_cid]=val
        except Exception: pass
    for i,(e,o) in enumerate(sels):
        bring_into_view(e)
        val=ans[f"S{i+1}"]
        try:e.select_option(label=val)
        except:
            try:e.select_option(value=val)
            except:return False
    for i,b in enumerate(ds):
        val=ans[f"D{i+1}"]
        page.mouse.click(b["x"]+b["w"]/2,b["y"]+b["h"]/2);time.sleep(.1)
        if not click_text(page,val):page.keyboard.press("Escape");return False
    for i,e in enumerate(ins):
        bring_into_view(e)
        val=str(ans[f"I{i+1}"])
        if not write_input(page,e,val):
            print("Could not enter input",i+1,"value",val)
            return False
        print("Entered input",i+1,"=",val)
    return True



def is_match_pairs_page(page):
    """Detect Sparx connector-dot matching questions without treating ordinary MCQs as matching."""
    try:
        t=repair_text(page.locator("body").inner_text(timeout=1000)).lower()
        if "image zoom" in t:
            return False
        if not any(x in t for x in ("match each", "match the", "match these")):
            return False
        # Matching pages normally have two answer columns and no native answer inputs.
        return "/tasks/" in (page.url or "") and not get_inputs(page) and not native_selects(page)
    except Exception:
        return False


def match_grade_feedback(page):
    """Return (correct,total,text) when Sparx has already graded a connector mapping."""
    try:
        txt=repair_text(page.locator("body").inner_text(timeout=1000))
    except Exception:
        return None
    m=re.search(r"\b(\d+)\s+out of\s+(\d+)\s+(?:are|is)\s+correct\b", txt, re.I)
    if not m:
        return None
    return int(m.group(1)),int(m.group(2)),m.group(0)


def reset_match_plan_after_grade(page):
    """Sparx grading is authoritative: a partial connector score invalidates the locked plan."""
    grade=match_grade_feedback(page)
    if not grade:
        return False
    good,total,label=grade
    if good>=total:
        return False
    old=getattr(page,"_hh_match_plan",None)
    if old:
        hist=getattr(page,"_hh_match_rejected_plans",[])
        if old not in hist: hist.append(old)
        page._hh_match_rejected_plans=hist[-8:]
    page._hh_match_locked=False
    page._hh_match_sig=None
    page._hh_match_grade=(good,total)
    print(f"MATCH_PAIRS GRADED: {label}; unlocking the rejected mapping and entering CORRECTING_MATCHES.",flush=True)
    return True


def match_endpoints(page):
    """Extract connector dots and split them into the two real endpoint columns.

    Matching questions may have MORE choices on the right than rows on the left (distractors),
    and the question can occupy only part of the viewport.  Therefore never split at viewport
    centre and never require balanced columns.
    """
    try:
        return page.evaluate(r"""()=>{
          const bad=/^(clear selection|report problem|i don't know|zoom|image zoom|close|submit|check|show me the support again|periodic table)$/i;
          const vis=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none'};
          let dots=[];
          for(const e of [...document.querySelectorAll('body *')]){
            if(!vis(e))continue; const r=e.getBoundingClientRect();
            if(r.width<5||r.height<5||r.width>30||r.height>30||r.top<150||r.bottom>innerHeight-35)continue;
            const st=getComputedStyle(e), rad=parseFloat(st.borderRadius||'0'), border=parseFloat(st.borderTopWidth||'0');
            if(rad<Math.min(r.width,r.height)*.30 || border<1)continue;
            // Find the nearest compact ancestor containing the label for this endpoint.
            let box=e.parentElement, txt='';
            for(let k=0;box&&k<6;k++,box=box.parentElement){
              const t=(box.innerText||box.textContent||'').replace(/\s+/g,' ').trim();
              const br=box.getBoundingClientRect();
              if(t && t.length<=120 && br.width<520 && br.height<150 && !bad.test(t)){txt=t;break;}
            }
            if(!txt||txt.length>120||bad.test(txt))continue;
            dots.push({x:r.left+r.width/2,y:r.top+r.height/2,text:txt});
          }
          // De-dupe the same rendered dot.
          let raw=[]; for(const d of dots){if(!raw.some(o=>Math.hypot(o.x-d.x,o.y-d.y)<7))raw.push(d)}
          if(raw.length<4)return [];

          // Cluster by X coordinate. Connector layouts form two narrow vertical dot columns.
          // This works even when the whole question sits on the left side of a wide viewport.
          raw.sort((a,b)=>a.x-b.x);
          let clusters=[];
          for(const d of raw){
            let c=clusters.find(c=>Math.abs(c.cx-d.x)<=24);
            if(!c){c={cx:d.x,items:[]};clusters.push(c)}
            c.items.push(d); c.cx=c.items.reduce((s,z)=>s+z.x,0)/c.items.length;
          }
          clusters=clusters.filter(c=>c.items.length>=2).sort((a,b)=>a.cx-b.cx);
          if(clusters.length<2)return [];
          // Pick the adjacent pair of substantial clusters with the clearest horizontal gap.
          let best=null;
          for(let i=0;i<clusters.length-1;i++){
            const a=clusters[i],b=clusters[i+1],gap=b.cx-a.cx;
            const score=gap + 8*Math.min(a.items.length,b.items.length);
            if(gap>45 && (!best||score>best.score))best={a,b,score};
          }
          if(!best)return [];
          const uniq=a=>{let m=new Map();for(const d of a){let key=d.text.toLowerCase();let old=m.get(key);if(!old)m.set(key,d)}return [...m.values()].sort((x,y)=>x.y-y.y)};
          return {left:uniq(best.a.items),right:uniq(best.b.items)};
        }""")
    except Exception:return None

def match_endpoints_from_boxes(page):
    """Fallback for Sparx connector UIs whose dots are canvas/pseudo-elements.
    Ground endpoints from the two columns of compact labelled boxes, then click the box edge
    where the connector dot is rendered. This never uses free-form vision coordinates."""
    try:
        return page.evaluate(r"""()=>{
          const bad=/^(clear selection|report problem|i don't know|zoom|image zoom|close|submit|check|show me the support again|periodic table)$/i;
          const vis=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none'};
          let a=[];
          for(const e of [...document.querySelectorAll('button,[role=button],div,li')]){
            if(!vis(e))continue; const r=e.getBoundingClientRect();
            if(r.top<250||r.bottom>innerHeight-55||r.width<100||r.width>480||r.height<35||r.height>125)continue;
            const t=(e.innerText||e.textContent||'').replace(/\s+/g,' ').trim();
            if(!t||t.length>100||bad.test(t)||/[?]/.test(t))continue;
            // Keep leaf-ish labelled boxes; discard wrappers containing several child labels.
            const kids=[...e.children].filter(vis).map(x=>(x.innerText||x.textContent||'').trim()).filter(Boolean);
            if(kids.filter(x=>x!==t).length>1)continue;
            a.push({text:t,left:r.left,right:r.right,y:r.top+r.height/2,cx:r.left+r.width/2});
          }
          // Deduplicate nested elements by text + near-identical centre.
          let raw=[];for(const d of a){if(!raw.some(o=>o.text===d.text&&Math.abs(o.cx-d.cx)<15&&Math.abs(o.y-d.y)<15))raw.push(d)}
          let clusters=[];for(const d of raw){let c=clusters.find(c=>Math.abs(c.cx-d.cx)<55);if(!c){c={cx:d.cx,items:[]};clusters.push(c)}c.items.push(d);c.cx=c.items.reduce((s,z)=>s+z.cx,0)/c.items.length}
          clusters=clusters.filter(c=>c.items.length>=2).sort((x,y)=>x.cx-y.cx); if(clusters.length<2)return null;
          let best=null;for(let i=0;i<clusters.length-1;i++){for(let j=i+1;j<clusters.length;j++){let l=clusters[i],r=clusters[j],gap=r.cx-l.cx;if(gap<120)continue;let score=Math.min(l.items.length,r.items.length)*100-gap*.05;if(!best||score>best.score)best={l,r,score}}}
          if(!best)return null;
          const uniq=(arr,side)=>{let m=new Map();for(const d of arr.sort((x,y)=>x.y-y.y)){if(!m.has(d.text.toLowerCase()))m.set(d.text.toLowerCase(),{text:d.text,x:side==='L'?d.right-2:d.left+2,y:d.y})}return [...m.values()]};
          return {left:uniq(best.l.items,'L'),right:uniq(best.r.items,'R')};
        }""")
    except Exception:return None

def match_key(v):
    """Canonical matching label key that PRESERVES ionic charge signs.

    General canon() intentionally removes punctuation, which makes -2 and +2 identical.
    Connector questions need + / - to remain semantically distinct.
    """
    x=repair_text(v).strip().lower()
    x=x.replace("−","-").replace("–","-").replace("—","-").replace("＋","+")
    x=re.sub(r"\s+","",x)
    # Keep charge signs and ordinary label characters; remove only harmless wrappers/punctuation.
    return re.sub(r"[^a-z0-9+\-]","",x)


def _match_plan_from_json(pairs,left,right):
    """Map an AI pair list back to currently grounded endpoints without losing +/- signs."""
    clean=[]; ls=set(); rs=set()
    for pair in pairs or []:
        lk=match_key(pair.get('left','')); rk=match_key(pair.get('right',''))
        lt=next((x for x in left if match_key(x['text'])==lk),None)
        rt=next((x for x in right if match_key(x['text'])==rk),None)
        if not lt or not rt or lk in ls or rk in rs:
            return None
        ls.add(lk); rs.add(rk); clean.append((lt,rt))
    return clean

def solve_match_pairs(page):
    """Solve matching by semantic labels. Right-side distractors are allowed."""
    sig=qfingerprint(page)
    grade=match_grade_feedback(page)
    if getattr(page,"_hh_match_sig",None)==sig and getattr(page,"_hh_match_locked",False) and not (grade and grade[0]<grade[1]):
        print("MATCH_PAIRS: verified plan already applied; preserving it.",flush=True); return True
    ep=match_endpoints(page)
    if not ep or len(ep.get('left',[]))<2 or len(ep.get('right',[]))<2:
        ep=match_endpoints_from_boxes(page)
        if ep and len(ep.get('left',[]))>=2 and len(ep.get('right',[]))>=2:
            print("MATCH_PAIRS: connector dots are not DOM nodes; grounded endpoints from labelled box edges.",flush=True)
        else:
            print("MATCH_PAIRS: could not extract the two connector columns safely.",flush=True); return False
    left=ep['left']; right=ep['right']; n=len(left)
    if len(right)<n:
        print("MATCH_PAIRS: fewer answer endpoints than prompts; refusing unsafe interaction.",flush=True); return False
    print(f"MATCH_PAIRS: grounded {len(left)} prompt endpoints and {len(right)} answer endpoints (distractors allowed).",flush=True)
    rejected=getattr(page,"_hh_match_rejected_plans",[])
    # High-confidence GCSE semantic guards for recurring matching layouts. Right-side distractors are allowed.
    lmap={match_key(x['text']):x for x in left}; rmap={match_key(x['text']):x for x in right}
    deterministic_pairs=None
    periodic={'group1':'+1','group2':'+2','group6':'-2','group7':'-1'}
    if all(match_key(k) in lmap for k in periodic) and all(match_key(v) in rmap for v in periodic.values()):
        deterministic_pairs=[(lmap[match_key(k)],rmap[match_key(v)]) for k,v in periodic.items()]
        print('MATCH_PAIRS: deterministic GCSE ion-charge mapping available.',flush=True)
    phloem_rules={
      match_key('Comes with companion cells'):match_key('Contain mitochondria to provide energy to the phloem'),
      match_key('Have pores in the end walls'):match_key('To allow dissolved sugars to move from cell to cell'),
      match_key('No nucleus'):match_key('To maximise space for the movement of dissolved sugars'),
      match_key('Thick cell wall'):match_key('To withstand the pressure inside cell')}
    if deterministic_pairs is None and all(k in lmap for k in phloem_rules) and all(v in rmap for v in phloem_rules.values()):
        deterministic_pairs=[(lmap[k],rmap[v]) for k,v in phloem_rules.items()]
        print('MATCH_PAIRS: deterministic GCSE phloem-adaptation mapping available.',flush=True)
    prompt="""Solve this AQA GCSE Science matching question. Return ONLY JSON {"pairs":[{"left":"exact left label","right":"exact right label"}],"reason":"brief"}. Pair EVERY supplied left label exactly once. Each right label may be used AT MOST once. There may be unused right-side distractors, so DO NOT force every right label to be used. Do not pair by vertical position. Derive each relation scientifically from the question/screenshot. Never return utility controls."""
    payload={"question":active_question_text(page)[:14000],"left_labels":[x['text'] for x in left],"right_labels":[x['text'] for x in right],"rejected_complete_mappings":rejected[-6:],"feedback":read_sparx_feedback(page)[:3000]}
    shot=inspect_full_page(page); plan=deterministic_pairs
    for attempt in range(4) if plan is None else range(0):
        r=ask(prompt,json.dumps(payload,ensure_ascii=False),shot); pairs=r.get('pairs',[]) if isinstance(r,dict) else []
        if len(pairs)!=n: continue
        clean=_match_plan_from_json(pairs,left,right)
        candidate=[{"left":a['text'],"right":b['text']} for a,b in (clean or [])]
        if clean and len(clean)==n and candidate not in rejected: plan=clean;break
        payload['repair_note']='Previous mapping was incomplete, invalid, duplicated a right answer, or was rejected by Sparx. Produce a different complete scientifically checked mapping. Unused right-side distractors are allowed.'
    if not plan:
        print("MATCH_PAIRS: no complete safe semantic mapping available.",flush=True);return False

    proposed=[{"left":a['text'],"right":b['text']} for a,b in plan]
    verify_prompt="""Independently verify this AQA GCSE Science matching answer using the screenshot. Return ONLY JSON {"correct":true/false,"pairs":[{"left":"exact","right":"exact"}],"reason":"brief","confidence":0.0}. Re-solve the science yourself. Every LEFT label must be paired exactly once; right-side options can include unused distractors and each chosen right label can be used at most once. If any proposed pair is wrong, return the corrected COMPLETE mapping. Never guess from vertical position."""
    vr=ask(verify_prompt,json.dumps({"question":active_question_text(page)[:14000],"proposed":proposed,"left_labels":[x['text'] for x in left],"right_labels":[x['text'] for x in right]},ensure_ascii=False),shot)
    vpairs=vr.get('pairs',[]) if isinstance(vr,dict) else []
    def _normpairs(pp):
        try:return sorted((match_key(x.get('left','')),match_key(x.get('right',''))) for x in pp)
        except:return []
    agree=bool(vr.get('correct')) and _normpairs(vpairs)==_normpairs(proposed) and float(vr.get('confidence',0) or 0)>=0.88
    if deterministic_pairs is not None:
        # The deterministic map already passed exact visible-label and one-to-one endpoint checks above.
        agree=True
    if not agree and deterministic_pairs is None:
        # A verifier disagreement must not deadlock a diagram matching question. If the verifier
        # supplied a complete high-confidence correction, adjudicate solver vs verifier once.
        vplan=_match_plan_from_json(vpairs,left,right)
        vconf=float(vr.get('confidence',0) or 0) if isinstance(vr,dict) else 0.0
        if vplan and len(vplan)==n and vconf>=0.88:
            corrected=[{"left":a['text'],"right":b['text']} for a,b in vplan]
            judge_prompt="""Adjudicate two COMPLETE AQA GCSE Science matching mappings from the screenshot. Return ONLY JSON {"choice":"A"|"B","confidence":0.0,"reason":"brief"}. Inspect the actual diagram/arrows/labels, not vertical position. Every left label must be mapped once. Choose the scientifically and visually correct complete mapping."""
            jr=ask(judge_prompt,json.dumps({"question":active_question_text(page)[:14000],"A":proposed,"B":corrected},ensure_ascii=False),shot)
            choice=str(jr.get('choice','')).strip().upper() if isinstance(jr,dict) else ''
            jconf=float(jr.get('confidence',0) or 0) if isinstance(jr,dict) else 0.0
            if choice=='B' and jconf>=0.78:
                plan=vplan; proposed=corrected; agree=True
                print("MATCH_PAIRS: adjudicator accepted verifier's complete corrected mapping.",flush=True)
            elif choice=='A' and jconf>=0.78:
                agree=True
                print("MATCH_PAIRS: adjudicator confirmed solver's complete mapping.",flush=True)
        if not agree:
            print("MATCH_PAIRS: mapping disagreement remains after adjudication; retrying reasoning without clicks.",flush=True); return False
    if not agree:
        print("MATCH_PAIRS: independent verifier did not confirm the full mapping; leaving it untouched.",flush=True); return False
    print("MATCH_PAIRS: complete mapping verified.",flush=True)

    # AI/full-page inspection can temporarily change rendering/scroll geometry. Re-ground every
    # connector from its exact visible label immediately before clicking. This also prevents stale
    # coordinates from being reused across pairs.
    fresh=match_endpoints(page) or match_endpoints_from_boxes(page)
    if not fresh:
        print("MATCH_PAIRS: could not re-ground endpoints before interaction.",flush=True); return False
    fl={match_key(x['text']):x for x in fresh['left']}; fr={match_key(x['text']):x for x in fresh['right']}
    rebound=[]
    for pair in proposed:
        a=fl.get(match_key(pair['left'])); b=fr.get(match_key(pair['right']))
        if not a or not b:
            print("MATCH_PAIRS: a verified label disappeared before clicking; retrying safely.",flush=True); return False
        rebound.append((a,b))
    plan=rebound
    try:
        clear=page.get_by_text(re.compile(r"^\s*Clear selection\s*$",re.I))
        if clear.count() and clear.first.is_visible() and (grade and grade[0] < grade[1]): clear.first.click(timeout=1200);time.sleep(.2)
    except:pass
    before=page.screenshot()
    for idx,pair in enumerate(proposed,1):
        # Re-read endpoint geometry before EVERY pair. Sparx can redraw the connector layer after a line.
        cur=match_endpoints(page) or match_endpoints_from_boxes(page)
        if not cur: print("MATCH_PAIRS: endpoints disappeared during pairing; stopping safely.",flush=True); return False
        cl={match_key(x['text']):x for x in cur['left']}; cr={match_key(x['text']):x for x in cur['right']}
        a=cl.get(match_key(pair['left'])); b=cr.get(match_key(pair['right']))
        if not a or not b: print("MATCH_PAIRS: could not re-ground pair",idx,"of",len(proposed),flush=True); return False
        page.mouse.click(a['x'],a['y']); time.sleep(.30)
        page.mouse.click(b['x'],b['y']); time.sleep(.55)
        after=page.screenshot()
        if after==before:
            print("MATCH_PAIRS: pair",idx,"produced no visible state change; aborting without spam.",flush=True);return False
        before=after
        print(f"MATCH_PAIRS: pair {idx}/{len(proposed)} confirmed visual state change:",repr(a['text']),"->",repr(b['text']),flush=True)
    page._hh_match_plan=proposed; page._hh_match_sig=sig; page._hh_match_locked=True; page._hh_match_time=time.time()
    print("MATCH_PAIRS: complete DOM-grounded plan applied and locked.",flush=True);return True

def visual(page):
    prompt="""Solve this AQA GCSE Science question by carefully inspecting the screenshot. Read all visible
diagrams, circuit symbols and connections, graphs and axis scales, tables, apparatus, biological
drawings, arrows, labels and image-based evidence. This may also be an unusual interactive layout
such as sorting, matching/linking, drag-and-drop or a custom table. Return ONLY JSON:
{"actions":[{"kind":"click","x":1,"y":1},{"kind":"type","x":1,"y":1,"text":"..."},{"kind":"drag","x1":1,"y1":1,"x2":2,"y2":2}],"reason":"brief"}.
Use screenshot coordinates. Never interact with Submit, Next, question tabs, Menu, Report Problem, help,
I don't know, Results, Image zoom, zoom +/-, Close, browser UI, or navigation. Image/diagram controls are evidence-only: NEVER click them. Include answer-entry actions only."""
    r=ask(prompt,"Solve the visible question with the fewest actions.",page.screenshot())
    acts=r.get("actions",[]);print("Fallback:",acts)
    if not acts or len(acts)>20:return False

    # v25.9: Coordinate vision is an answer-entry fallback, never a navigation system.
    # Small/placeholder coordinates such as (1,1) were able to hit Sparx's back/header
    # controls and eject an unfinished task to /packages. Reject the ENTIRE plan before
    # making any click if an action is outside the safe question/answer region.
    try:
        vp=page.viewport_size or {"width":1600,"height":900}
        vw,vh=float(vp.get("width",1600)),float(vp.get("height",900))
    except:
        vw,vh=1600.0,900.0
    def safe_xy(x,y):
        try:
            x=float(x); y=float(y)
            # Keep away from Sparx back/header/question-tab navigation and browser-edge
            # placeholders. Answer controls in Sparx render below this protected band.
            return 70 <= x <= vw-25 and 145 <= y <= vh-35
        except:return False
    for a in acts:
        k=norm(a.get("kind",""))
        if k in ("click","type") and not safe_xy(a.get("x"),a.get("y")):
            print("VISUAL SAFETY: rejected unsafe coordinate action before clicking:",a,flush=True)
            return False
        if k=="drag" and (not safe_xy(a.get("x1"),a.get("y1")) or not safe_xy(a.get("x2"),a.get("y2"))):
            print("VISUAL SAFETY: rejected unsafe drag before interacting:",a,flush=True)
            return False

    def unsafe_target_text(x,y):
        try:
            t=page.evaluate("""([x,y])=>{let e=document.elementFromPoint(x,y); if(!e)return ''; for(let i=0;i<4&&e;i++,e=e.parentElement){let t=(e.innerText||e.textContent||e.getAttribute?.('aria-label')||'').replace(/\\s+/g,' ').trim(); if(t)return t;} return '';}""",[float(x),float(y)])
            return is_never_click_text(t) or canon(t) in {"menu","back","results","showmethesupportagain","imagezoom","zoomin","zoomout","close"}
        except Exception:return False
    start_url=page.url or ""
    for a in acts:
        try:
            k=norm(a["kind"])
            if k in ("click","type") and unsafe_target_text(a.get("x"),a.get("y")):
                print("UTILITY GUARD: blocked visual fallback from clicking forbidden utility control.",flush=True); return False
            if k=="drag" and (unsafe_target_text(a.get("x1"),a.get("y1")) or unsafe_target_text(a.get("x2"),a.get("y2"))):
                print("UTILITY GUARD: blocked visual fallback drag touching forbidden utility control.",flush=True); return False
            if k=="click":page.mouse.click(float(a["x"]),float(a["y"]))
            elif k=="type":
                page.mouse.click(float(a["x"]),float(a["y"]));page.keyboard.type(str(a["text"]))
            elif k=="drag":
                page.mouse.move(float(a["x1"]),float(a["y1"]));page.mouse.down()
                page.mouse.move(float(a["x2"]),float(a["y2"]),steps=10);page.mouse.up()
            else:return False
            time.sleep(.1)
            # If an answer-entry fallback somehow navigates away, stop immediately.
            if "/tasks/" in start_url and "/tasks/" not in (page.url or ""):
                print("VISUAL SAFETY: answer-entry action unexpectedly left active task; aborting remaining actions.",flush=True)
                return False
        except:return False
    return True

def nav(page,names,allow_scroll=True):
    """Click navigation controls. Search the CURRENT viewport/DOM first; scroll only as fallback."""
    aliases={"retry":["Retry","Try again","Restart","Have another go","Second chance"],
             "restart":["Restart","Try again","Retry"],"try again":["Try again","Retry","Restart"],
             "next":["Next","Continue","Next question"],"continue":["Continue","Next","Next question"],
             "submit":["Submit","Check","Check answer"],"check":["Check","Submit","Check answer"],
             "let's learn it":["Let's learn it","Lets learn it"],"okay, i've got it":["Okay, I've got it","Okay, Ive got it","Okay I've got it","Got it"],"finish":["Finish"],"let's go":["Let's go","Lets go"]}
    labels=[]
    for n in names:
        for x in aliases.get(n.lower(),[n]):
            if x not in labels:labels.append(x)

    def attempt(label):
        pat=re.compile(r"^\s*"+re.escape(label)+r"\s*$",re.I)
        locators=[]
        try:locators.append(("button",page.get_by_role("button",name=pat)))
        except:pass
        try:locators.append(("link",page.get_by_role("link",name=pat)))
        except:pass
        try:locators.append(("text",page.get_by_text(pat)))
        except:pass
        # Native input buttons as another fallback.
        try:locators.append(("input",page.locator("input[type=submit],input[type=button]")))
        except:pass

        for kind,loc in locators:
            try:
                for i in range(min(loc.count(),30)):
                    e=loc.nth(i)
                    if not e.is_visible() or not e.is_enabled():continue
                    if kind=="input":
                        val=repair_text(e.get_attribute("value") or "")
                        if canon(val)!=canon(label):continue
                    bring_into_view(e)
                    time.sleep(.05)
                    e.click(timeout=1800)
                    remember_interaction("navigation",label,kind,True)
                    print("Navigation action:",label,"via",kind,flush=True)
                    return True
            except:pass
        return False

    # 1) Current page first. For the screenshot's visible Submit this should finish here.
    for lab in labels:
        if attempt(lab):return True

    # 2) Only physically scan when the action genuinely isn't currently locatable.
    if allow_scroll:
        print("Navigation control not visible; using free scroll as fallback.",flush=True)
        autonomous_scroll_scan(page)
        for lab in labels:
            if attempt(lab):return True

    remember_interaction("navigation"," / ".join(names),"not found"+(" after fallback scan" if allow_scroll else ""),False)
    return False



def close_accidental_report_problem(page):
    """Close Sparx Report a problem if an old/fallback interaction ever opened it.

    Report Problem is a utility control and is globally forbidden as an answer/retry path.
    """
    try:
        body=repair_text(page.locator("body").inner_text(timeout=700)).lower()
        if "report a problem" not in body or "what problem have you found" not in body:
            return False
        for label in ("Close", "×"):
            try:
                pat=re.compile(r"^\s*"+re.escape(label)+r"\s*$",re.I)
                for role in ("button","link"):
                    loc=page.get_by_role(role,name=pat)
                    if loc.count() and loc.first.is_visible():
                        loc.first.click(timeout=1200)
                        print("UTILITY GUARD: closed accidental Report a problem dialog; solver will retry the question.",flush=True)
                        time.sleep(.25); return True
            except Exception: pass
    except Exception: pass
    return False

def close_accidental_image_zoom(page):
    """Close Sparx's image-zoom viewer immediately; it is evidence UI, never an answer control."""
    try:
        body=repair_text(page.locator("body").inner_text(timeout=700)).lower()
        if "image zoom" not in body:
            return False
        # The viewer has its own Close control. Prefer exact accessible names and never touch +/-.
        for pat in (re.compile(r"^\s*Close(?:\s*[×x])?\s*$",re.I), re.compile(r"^\s*[×x]\s*$",re.I)):
            for role in ("button","link"):
                try:
                    loc=page.get_by_role(role,name=pat)
                    for i in range(min(loc.count(),4)):
                        if loc.nth(i).is_visible():
                            loc.nth(i).click(timeout=1200)
                            print("UTILITY GUARD: closed accidental Image zoom overlay; returning to the unchanged question.",flush=True)
                            time.sleep(.25); return True
                except Exception: pass
        # Text fallback, restricted to visible exact Close.
        loc=page.get_by_text(re.compile(r"^\s*Close\s*[×x]?\s*$",re.I))
        if loc.count() and loc.first.is_visible():
            loc.first.click(timeout=1200); time.sleep(.25)
            print("UTILITY GUARD: closed accidental Image zoom overlay; returning to the unchanged question.",flush=True)
            return True
    except Exception: pass
    return False

def flashcard_state(page):
    """Recognise Sparx flashcard states. Completion evidence is stronger than page branding."""
    try:
        body=repair_text(page.locator("body").inner_text(timeout=1000)).lower()
    except Exception:
        return None
    # A completed flashcard task can lose/alter the Flashcards heading, so do not require it.
    if "task complete" in body and ("well done" in body or "accurate" in body or "xp" in body):
        return "complete"
    if "flashcards" in body and "let's go" in body and ("new" in body or "review" in body):
        return "start"
    if "flashcards" in body:
        return "card"
    return None


def handle_flashcard_navigation(page):
    """Handle the unambiguous Flashcards entry/finish controls before generic solving."""
    st=flashcard_state(page)
    if st=="start":
        print("STATUS|FLASHCARDS_START",flush=True)
        if nav(page,["Let's go"],allow_scroll=False):
            print("FLASHCARDS: clicked Let's go; reading the first card next.",flush=True)
            time.sleep(.7); return True
    elif st=="complete":
        print("STATUS|FLASHCARDS_COMPLETE",flush=True)
        # Finish is a completion/navigation action, never an answer. Try visible DOM first,
        # then one targeted navigation scan in case the result card is slightly below view.
        if nav(page,["Finish"],allow_scroll=False) or nav(page,["Finish"],allow_scroll=True):
            mark_task_complete(page)
            print("FLASHCARDS: Task Complete verified; clicked Finish once and will re-read the changed page.",flush=True)
            try: page.wait_for_timeout(900)
            except Exception: time.sleep(.9)
            return True
        print("FLASHCARDS: Task Complete is visible but Finish was not locatable yet; will retry without solving the result screen.",flush=True)
        return True
    return False



def handle_learning_info(page):
    """Advance explicit Sparx teaching/info cards. These are navigation, never answer choices."""
    try:
        body=repair_text(page.locator("body").inner_text(timeout=900)).lower()
    except Exception:
        return False
    teaching = ("let's learn it" in body or "lets learn it" in body or "show me the support again" in body)
    acknowledgement = ("okay, i've got it" in body or "okay, ive got it" in body or "okay i've got it" in body)
    # The final support card can contain only the acknowledgement button; the teaching
    # text may be above the current viewport or removed from the DOM. The exact button
    # is sufficient evidence that this is tutorial navigation, never an answer.
    if acknowledgement:
        print("STATUS|LEARNING",flush=True)
        capture_teaching_evidence(page)
        if nav(page,["Okay, I've got it"],allow_scroll=False) or nav(page,["Okay, I've got it"],allow_scroll=True):
            print("LEARNING: authoritative teaching evidence saved; clicked Okay, I've got it and will use that evidence on the retry.",flush=True)
            try: page.wait_for_timeout(650)
            except Exception: time.sleep(.65)
            return True
        print("LEARNING: support card detected; acknowledgement button not locatable yet, will retry safely.",flush=True)
        return True
    return False

def recover_stalled_learning_card(page):
    """Recover Sparx tutorial cards that show only 'Show me the support again'.
    This is tutorial navigation, never an answer and never a reason to scan/solve the blank card.
    """
    try:
        body=repair_text(page.locator("body").inner_text(timeout=900)).lower()
        if "let's learn it" not in body and "think about what you've learnt" not in body and "think about what you've learned" not in body:
            return False
        b=page.get_by_text(re.compile(r"^\s*Show me the support again\s*$",re.I))
        if b.count() and b.first.is_visible():
            b.first.click(timeout=1200); time.sleep(.55)
            print("LEARNING: support card was stalled; reopened the support instead of treating it as a question.",flush=True)
            return True
    except Exception: pass
    return False

def enter_correction_flow(page):
    """Correction/tutorial actions outrank Submit/recovery. Never choose Skip."""
    try:
        body=repair_text(page.locator("body").inner_text(timeout=900)).lower()
    except Exception:
        body=""
    if any(x in body for x in ("incorrect","second chance","one more try","rows are correct","row is correct")):
        if "let's learn it" in body or "lets learn it" in body:
            if nav(page,["Let's learn it"],allow_scroll=False):
                print("CORRECTION: clicked Let's learn it; tutorial becomes the active question state.",flush=True)
                time.sleep(.65); return True
        if nav(page,["Try again","Retry","Restart"],allow_scroll=False):
            print("CORRECTION: entered editable retry state.",flush=True)
            time.sleep(.4); return True
    return False

def rewrite_inline_rejected_inputs(page):
    """Handle Sparx second-chance screens where red-crossed text boxes stay editable.

    Some recovery questions do not expose Try again/Retry. Sparx simply marks the
    existing inputs red and expects them to be overwritten. In that state we must
    learn the rejected values, clear only those exact fields, then let the normal
    solver produce a genuinely different answer on the next pass.
    """
    try:
        if not current_attempt_rejected(page):
            return False
        attempted=LAST_ATTEMPT.get("answers") or {}
        if not attempted:
            return False
        ins=get_inputs(page)
        if not ins:
            return False
        # Only act when the visible editable values are still the exact submitted
        # attempt. This prevents repeatedly clearing a newly-generated correction
        # while Sparx's old red-cross decoration is still on screen.
        rejected_visible=[]
        for i,el in enumerate(ins):
            cid=f"I{i+1}"
            if cid not in attempted:
                continue
            try: cur=repair_text(el.input_value(timeout=500))
            except Exception: cur=""
            if cur and canon(cur)==canon(attempted.get(cid,"")):
                rejected_visible.append((cid,el,cur))
        if not rejected_visible:
            return False

        # A visible retry/tutorial control owns the transition; this handler is
        # specifically for the no-button inline rewrite variant.
        try:
            body=repair_text(page.locator("body").inner_text(timeout=700)).lower()
        except Exception:
            body=""
        if any(x in body for x in ("let's learn it","lets learn it")):
            return False
        for label in ("Try again","Retry","Restart"):
            try:
                b=page.get_by_role("button",name=re.compile(r"^\s*"+re.escape(label)+r"\s*$",re.I))
                if b.count() and b.first.is_visible():
                    return False
            except Exception:
                pass

        feedback=read_sparx_feedback(page)
        record_last_rejection(page,feedback)
        fp=LAST_ATTEMPT.get("fingerprint")
        for cid,el,cur in rejected_visible:
            if fp:
                WRONG_BY_CONTROL.setdefault(fp,{}).setdefault(cid,set()).add(canon(cur))
            try:
                el.fill("")
                el.evaluate("""e=>{e.value='';e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}))}""")
            except Exception:
                try: el.press("Control+A"); el.press("Backspace")
                except Exception: pass
            print("INLINE SECOND CHANCE: cleared rejected",cid,repr(cur),"and blacklisted it for the rewrite.",flush=True)
        print("INLINE SECOND CHANCE: no Try again button is required; re-solving the editable fields now.",flush=True)
        return True
    except Exception as ex:
        print("Inline second-chance rewrite warning:",repr(ex),flush=True)
        return False

def recover_question_page(ctx,page,timeout=8):
    end=time.time()+timeout
    while time.time()<end:
        q=find_question_page(ctx,page)
        if q:return q
        try:
            for pg in ctx.pages:
                if "sparx" in (pg.url or "").lower():
                    pg.bring_to_front()
        except:pass
        time.sleep(.3)
    return None


def visible_wrong_state(page):
    try:
        txt=repair_text(page.locator("body").inner_text(timeout=1000)).lower()
        return any(x in txt for x in ("second chance!","one more try","incorrect","how to improve:","0 out of","rows are correct","row is correct"))
    except:return False


def current_attempt_rejected(page):
    """Authoritative rejection gate: red/incorrect state always beats navigation."""
    if visible_wrong_state(page):
        return True
    attempted=LAST_ATTEMPT.get("answers") or {}
    if attempted:
        try:
            states=marked_choice_results(page,attempted)
            if any(v=="wrong" for v in states.values()):
                return True
        except Exception:
            pass
    return False

def confirmed_result_ready_for_next(page):
    """Detect a fully graded correct result before any solver gets another turn.

    This deliberately outranks MATCH_PAIRS and the normal question solver. Sparx can
    leave the completed question DOM mounted with a visible Next button; without this
    gate the old question was analysed again instead of advancing.
    """
    if current_attempt_rejected(page):
        return False
    grade=match_grade_feedback(page)
    if grade and grade[0] >= grade[1] and grade[1] > 0:
        return True
    try:
        body=repair_text(page.locator("body").inner_text(timeout=900)).lower()
    except Exception:
        return False
    # Strong result-screen evidence. Avoid bare word 'correct' by itself because it
    # can occur in question instructions.
    strong=(
        "full marks" in body or "well done" in body or
        re.search(r"\b(\d+)\s+out of\s+\1\s+(?:are|is)\s+correct\b",body) is not None
    )
    if not strong:
        # Standard Sparx accepted state normally exposes both Correct and Next.
        strong=("correct" in body and re.search(r"\bnext\b",body) is not None)
    return bool(strong)

def advance_confirmed_result(page):
    """Click Next exactly once for an accepted result and wait for page mutation."""
    if not confirmed_result_ready_for_next(page):
        return False
    before=(page.url or "", question_text(page)[:700])
    print("STATUS|CORRECT",flush=True)
    print("COMPLETION GATE: Sparx has fully accepted this question; solver is paused and Next has absolute priority.",flush=True)
    if not nav(page,["Next","Continue","Next question"],allow_scroll=True):
        print("COMPLETION GATE: accepted result detected but Next is not locatable yet; waiting without re-solving.",flush=True)
        return True
    # Latch the navigation while Sparx changes the question/URL.
    for _ in range(20):
        time.sleep(.15)
        try:
            after=(page.url or "", question_text(page)[:700])
            if after != before:
                break
        except Exception:
            break
    if task_list_page(page):
        mark_task_complete(page)
        print("TASK COMPLETE: final Next returned to the homework task list; next unfinished task will be selected.",flush=True)
    print("COMPLETION GATE: Next clicked once; waiting for the new question before solving again.",flush=True)
    return True

def current_attempt_confirmed_correct(page):
    """Only call an answer accepted when Sparx gives positive evidence."""
    if current_attempt_rejected(page): return False
    try:
        body=repair_text(page.locator("body").inner_text(timeout=900)).lower()
        if any(x in body for x in ("correct","well done","full marks","next question","continue")):
            return True
    except: pass
    attempted=LAST_ATTEMPT.get("answers") or {}
    if attempted:
        try:
            states=marked_choice_results(page,attempted)
            return bool(states) and all(v=="correct" for v in states.values())
        except Exception: pass
    return False

def marked_choice_results(page, attempted):
    """Read Sparx's red/green marking from the exact choices we just submitted."""
    result={}
    try:
        rows=choices(page)
        for i,g in enumerate(rows):
            cid=f"C{i+1}"; val=(attempted or {}).get(cid)
            if not val: continue
            target=next((x for x in g if canon(x.get("text",""))==canon(val)),None)
            if not target: continue
            x=target["x"]+target["w"]/2; y=target["y"]+target["h"]/2
            info=page.evaluate("""([x,y])=>{
              let e=document.elementFromPoint(x,y);
              if(!e)return {};
              for(let n=0;n<5 && e;n++,e=e.parentElement){
                const c=getComputedStyle(e), cl=(e.className||'').toString().toLowerCase();
                const txt=((e.getAttribute&&e.getAttribute('aria-label'))||'').toLowerCase();
                const sig=[c.backgroundColor,c.color,c.borderColor,cl,txt].join(' ');
                if(/incorrect|wrong|error|danger/.test(sig))return {state:'wrong',sig};
                if(/correct|success/.test(sig))return {state:'correct',sig};
                const nums=(c.backgroundColor.match(/\\d+/g)||[]).map(Number);
                if(nums.length>=3){
                  const [r,g,b]=nums;
                  if(r>180 && r>g*1.18 && r>b*1.18)return {state:'wrong',sig};
                  if(g>115 && g>r*1.12 && g>b*1.05)return {state:'correct',sig};
                }
              }
              return {};
            }""",[x,y])
            if info and info.get("state"):result[cid]=info["state"]
    except Exception as e: print("Partial-mark state read warning:",repr(e),flush=True)
    return result

def record_last_rejection(page,feedback=""):
    fp=LAST_ATTEMPT.get("fingerprint")
    attempted=LAST_ATTEMPT.get("answers")
    if not fp or not attempted:return
    states=marked_choice_results(page,attempted)
    PARTIAL_LOCKS.setdefault(fp,{})
    WRONG_BY_CONTROL.setdefault(fp,{})
    if states:
        for cid,state in states.items():
            if state=="correct":
                PARTIAL_LOCKS[fp][cid]=attempted.get(cid)
                print("PARTIAL MARK: locking confirmed-correct",cid,repr(attempted.get(cid)),flush=True)
            elif state=="wrong":
                WRONG_BY_CONTROL[fp].setdefault(cid,set()).add(canon(attempted.get(cid,"")))
                PARTIAL_LOCKS[fp].pop(cid,None)
                print("PARTIAL MARK: blacklisting only wrong control",cid,repr(attempted.get(cid)),flush=True)
    # Keep whole-attempt memory for learning, but per-control locks decide what may be changed.
    KNOWN_WRONG.setdefault(fp,[])
    if attempted not in KNOWN_WRONG[fp]:KNOWN_WRONG[fp].append(dict(attempted))
    remember_result(fp,question_text(page),attempted,"wrong",feedback or read_sparx_feedback(page))
    remember_interaction("answer_result",str(attempted),"rejected by Sparx",False)
    print("HARD MEMORY: rejected attempt recorded; confirmed-correct parts will be preserved.",flush=True)

def task_list_page(page):
    """Recognise the Sparx homework task list without confusing it with a question."""
    try:
        if "/tasks/" in (page.url or ""): return False
        body=repair_text(page.locator("body").inner_text(timeout=1000))
        return bool(re.search(r"\bTask\s+\d+\b",body,re.I) and re.search(r"\b\d{1,3}%\b",body))
    except: return False


def try_next_homework_task(ctx,page):
    """On the task list, open the first visible unfinished task in DOM order."""
    try:
        if not task_list_page(page): return None
        rows=page.get_by_text(re.compile(r"^\s*Task\s+\d+\s*$",re.I))
        candidates=[]; seen=set()
        for i in range(min(rows.count(),40)):
            e=rows.nth(i)
            try:
                if not e.is_visible(): continue
                info=e.evaluate("""el=>{
                  let p=el, best=el;
                  for(let n=0;n<8 && p;n++,p=p.parentElement){
                    const t=(p.innerText||'').trim();
                    if(/^Task\s+\d+/i.test(t)) best=p;
                    if(/\b\d{1,3}%\b/.test(t) && /\bTask\s+\d+\b/i.test(t)){best=p;break;}
                  }
                  const t=(best.innerText||el.innerText||'').trim();
                  const m=t.match(/\b(\d{1,3})%\b/);
                  return {text:t, percent:m?Number(m[1]):null, cls:(best.className||'').toString()};
                }""")
                label=repair_text(e.inner_text()).strip()
                if label.lower() in seen: continue
                seen.add(label.lower()); candidates.append((e,label,info or {}))
            except: continue
        for e,label,info in candidates:
            pct=info.get("percent")
            low=(info.get("text","")+" "+info.get("cls","")).lower()
            completed=(pct is not None and pct>=100) or any(x in low for x in ("completed"," complete "," done "))
            if completed:
                print("TASK LIST: skipping completed",label,(str(pct)+"%") if pct is not None else "",flush=True); continue
            print("STATUS|NEXT_TASK",flush=True)
            print("TASK LIST: opening first unfinished task",label,(str(pct)+"%") if pct is not None else "(progress unknown)",flush=True)
            bring_into_view(e); e.click(timeout=2200)
            remember_interaction("next_task",label,"opened unfinished task",True)
            for _ in range(24):
                time.sleep(.15)
                if "/tasks/" in (page.url or ""): break
            return find_question_page(ctx,page) or page
        print("TASK LIST: no unfinished visible tasks remain on this homework list.",flush=True)
    except Exception as ex: print("Next-task navigation warning:",repr(ex),flush=True)
    return None



TASK_COMPLETE_FILE=DATA_DIR/"task_completion_state.json"

def task_completion_signal(page):
    """Require positive Sparx evidence that the current task really finished."""
    try:
        body=repair_text(page.locator("body").inner_text(timeout=1200)).lower()
        # Strong completion/result signals only. A wrong answer/second chance is explicitly NOT completion.
        if any(x in body for x in ("second chance","one more try","incorrect","how to improve")):
            return False
        strong=("task complete","task completed","completed this task","you've completed",
                "you have completed","results","all questions complete","homework complete")
        if any(x in body for x in strong):
            return True
        # Question tabs all visibly completed is another safe signal.
        tabs=page.locator("text=/^Q[0-9]+$/")
        n=tabs.count()
        if n:
            # DOM/body commonly exposes ticks for completed questions; require Results plus no active question prompt.
            return "results" in body and ("✓" in body or "check" in body) and "?" not in body
        return False
    except:return False

def mark_task_complete(page):
    try:
        LAST_TASK_FILE.write_text(json.dumps({"url":"","time":time.time(),"completed":True},indent=2),encoding="utf-8")
    except:pass

def choose_next_task_only_after_completion(page):
    """Advance only after a verified completion event, never because an error returned us to /packages."""
    if not task_completion_signal(page): return None
    mark_task_complete(page)
    print("TASK COMPLETE: verified completion; returning to Homework and selecting the next task.",flush=True)
    try:
        # Existing task-picker is retained, but it is now protected by the completion gate.
        return try_next_homework_task(None,page)
    except Exception as e:
        print("Next-task navigation warning:",repr(e),flush=True); return None

def safe_for_visual_fallback(page):
    """Never let coordinate fallback operate on menus, results pages or transitional blank states."""
    try:
        if "/tasks/" not in (page.url or ""):return False
        body=repair_text(page.locator("body").inner_text(timeout=1000)).lower()
        if any(x in body for x in ("my homework","older homework")):return False
        question_words=("?" in body or any(x in body for x in ("calculate","predict","explain","describe","what is","which ","how ","state ","select ","complete ","complete the","choose from","fill in","enter ")))
        answer_ui=any(x in body for x in ("submit","check answer","i don't know","report problem","mark","clear selection"))
        structural=bool(checkbox_table(page)) or any(x in body for x in ("match each","match the","match these"))
        return (question_words or structural) and answer_ui
    except:return False

def main():
    """One long-lived browser worker owned by Homework Helper.

    Commands arrive over stdin. The browser/profile is never killed between Login and Start,
    so the exact live Sparx tab the user is looking at is the tab the solver reads and controls.
    """
    import sys, threading
    print("Homework Helper Engine v25.29", flush=True)
    print("STATUS|ENGINE_BOOTING", flush=True)
    try:
        urllib.request.urlopen("http://127.0.0.1:11434/api/tags",timeout=2)
        print("STATUS|AI_READY", flush=True)
    except Exception:
        print("STATUS|AI_OFFLINE", flush=True)
        print("Ollama is offline. Login/browser access will still work; start Ollama before solving.", flush=True)

    state={"run":False,"shutdown":False,"login":False}
    def commands():
        for line in sys.stdin:
            cmd=line.strip().upper()
            if cmd=="START": state["run"]=True
            elif cmd=="STOP": state["run"]=False
            elif cmd=="LOGIN": state["login"]=True
            elif cmd=="SHUTDOWN":
                state["shutdown"]=True
                break
    threading.Thread(target=commands,daemon=True).start()

    with sync_playwright() as p:
        appdata=Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "HomeworkHelper"
        appdata.mkdir(parents=True,exist_ok=True)
        profile_dir=str(appdata/"sparx_login_profile")
        try:
            ctx=p.chromium.launch_persistent_context(
                profile_dir,headless=False,viewport={"width":1600,"height":900})
        except Exception as ex:
            print("STATUS|BROWSER_START_FAILED",flush=True)
            print("Browser startup error:",repr(ex),flush=True)
            print("Check that Playwright Chromium is installed. Run FIX_BROWSER_WINDOWS.bat once.",flush=True)
            traceback.print_exc()
            raise RuntimeError("Chromium could not start") from ex

        pages=list(ctx.pages)
        sparx=[pg for pg in pages if "sparx-learning.com" in (pg.url or "")]
        page=sparx[-1] if sparx else (pages[-1] if pages else ctx.new_page())
        try:
            if "sparx-learning.com" not in (page.url or ""):
                page.goto("https://science.sparx-learning.com/",wait_until="domcontentloaded",timeout=30000)
            page.bring_to_front()
        except Exception as ex:
            print("Could not open Sparx:",repr(ex),flush=True)
        print("STATUS|BROWSER_CONNECTED",flush=True)
        print("Browser connected. Login and solving now use this same live browser.",flush=True)

        question_number=0
        last_signature=None
        while not state["shutdown"]:
            try:
                if page.is_closed():
                    live=[x for x in ctx.pages if not x.is_closed()]
                    if not live: break
                    page=live[-1]

                if state["login"]:
                    state["login"]=False
                    try:
                        candidates=[x for x in ctx.pages if "sparx-learning.com" in (x.url or "")]
                        page=candidates[-1] if candidates else page
                        if "sparx-learning.com" not in (page.url or ""):
                            page.goto("https://science.sparx-learning.com/",wait_until="domcontentloaded",timeout=30000)
                        page.bring_to_front()
                        print("STATUS|LOGIN_READY",flush=True)
                        print("Sparx is ready. Sign in here; this exact browser stays connected to Homework Helper.",flush=True)
                    except Exception as ex: print("Login navigation error:",repr(ex),flush=True)

                # Utility overlays/dialogs are never solver states. Close them before any solver action.
                if close_accidental_image_zoom(page) or close_accidental_report_problem(page):
                    last_signature=None
                    continue

                # Flashcard landing/completion pages are valid Sparx workflow states.
                if handle_flashcard_navigation(page):
                    last_signature=None
                    continue

                # Teaching/support cards are valid workflow states and must be acknowledged before solving resumes.
                if state["run"] and handle_learning_info(page):
                    last_signature=None; page._hh_submit_misses=0
                    continue

                # Incorrect/second-chance correction controls outrank Submit and recovery.
                if state["run"] and enter_correction_flow(page):
                    last_signature=None; page._hh_submit_misses=0
                    continue

                # Some Sparx second-chance pages keep the red-crossed inputs editable
                # and provide no Try again button. Clear/rewrite those exact rejected
                # fields instead of waiting forever for a Submit/Retry control.
                if state["run"] and recover_stalled_learning_card(page):
                    last_signature=None; page._hh_submit_misses=0
                    time.sleep(.2)
                    continue

                if state["run"] and rewrite_inline_rejected_inputs(page):
                    last_signature=None; page._hh_submit_misses=0
                    time.sleep(.2)
                    continue

                found=find_question_page(ctx,page)
                if found:
                    page=found
                    if not state["run"]:
                        print("STATUS|QUESTION_READY",flush=True)
                elif state["run"]:
                    # TASK_LIST is a navigation state: select the first unfinished card and never run the question solver here.
                    if task_list_page(page):
                        nxt=try_next_homework_task(ctx,page)
                        if nxt:
                            page=nxt; last_signature=None; page._hh_submit_misses=0; time.sleep(.6); continue
                        print("STATUS|TASK_LIST",flush=True); time.sleep(.5); continue
                    if task_completion_signal(page):
                        mark_task_complete(page)
                        nxt=try_next_homework_task(ctx,page)
                        if nxt:
                            page=nxt; last_signature=None; time.sleep(.6); continue
                    if recover_after_unexpected_exit(page):
                        last_signature=None
                        time.sleep(.5); continue
                    print("STATUS|WAITING_QUESTION",flush=True)
                    print("On Homework menu without verified task completion; refusing to advance and waiting/recovering the active task.",flush=True)
                    time.sleep(.35); continue

                if not state["run"]:
                    time.sleep(.25); continue

                # Accepted-result navigation outranks AI availability, MATCH_PAIRS, and every
                # answer solver. Never analyse/click a completed question again.
                if advance_confirmed_result(page):
                    last_signature=None; page._hh_submit_misses=0
                    time.sleep(.25)
                    continue

                # AI is only required for solving, never for opening/logging into Sparx.
                try:
                    urllib.request.urlopen("http://127.0.0.1:11434/api/tags",timeout=2)
                except Exception:
                    print("STATUS|AI_OFFLINE",flush=True)
                    print("Start Ollama to solve questions. The Sparx browser will remain open.",flush=True)
                    state["run"]=False
                    time.sleep(.5); continue

                # Stay attached to the same rendered page and solve it.
                found=find_question_page(ctx,page)
                if not found:
                    if recover_after_unexpected_exit(page):
                        last_signature=None
                    time.sleep(.3); continue
                page=found
                try: page.bring_to_front()
                except: pass
                stable(page)
                body=question_text(page)
                sig=(page.url, body[:500])
                if sig==last_signature:
                    # Connector questions may auto-grade as soon as the final line is made. A visible
                    # "N out of M are correct" is grading evidence, not a missing-Submit condition.
                    if is_match_pairs_page(page) and match_grade_feedback(page):
                        grade=match_grade_feedback(page)
                        if grade[0] < grade[1]:
                            reset_match_plan_after_grade(page)
                            print("STATUS|CORRECTING_MATCHES",flush=True)
                            last_signature=None; page._hh_submit_misses=0
                            time.sleep(.2); continue
                    # Same question: try Submit, but never wait forever in a stale submit state.
                    if submit_current_answer(page):
                        print("STATUS|CHECKING",flush=True); time.sleep(.8); last_signature=None
                        page._hh_submit_misses=0
                    else:
                        page._hh_submit_misses=getattr(page,"_hh_submit_misses",0)+1
                        if page._hh_submit_misses>=3:
                            # IMPORTANT: do NOT clear last_signature here. Clearing it caused solve()
                            # to run again and click the same toggle choices off/on forever. Keep the
                            # entered answer latched and continue looking only for Submit/page change.
                            print("STATE WATCHDOG: Submit missing; preserving latched choices and waiting for Submit/page change (no re-click).",flush=True)
                            page._hh_submit_misses=0
                        time.sleep(.35)
                    continue
                last_signature=sig
                question_number+=1
                print(f"STATUS|ANALYSING",flush=True)
                print(f"Question {question_number}: reading text, controls and visual context...",flush=True)

                standard=bool(get_inputs(page) or choices(page) or native_selects(page) or dashed(page) or checkbox_table(page) or is_match_pairs_page(page))
                ok=solve(page)
                if not ok and is_match_pairs_page(page):
                    # Matching has its own semantic/connector solver. Never fall through to blind visual clicks;
                    # that path can hit diagram Zoom or other utility controls.
                    print("MATCH_PAIRS: safe plan unavailable; retrying the matching solver only (visual fallback disabled).",flush=True)
                elif not ok and not standard and safe_for_visual_fallback(page):
                    print("Using full-page visual interaction fallback on confirmed task question...",flush=True)
                    ok=visual(page)
                elif not ok and not standard:
                    print("Visual fallback blocked: page is not a confirmed question. No blind clicks will be made.",flush=True)
                if not ok:
                    print("STATUS|NEEDS_ATTENTION",flush=True)
                    page._hh_map_failures=getattr(page,"_hh_map_failures",0)+1
                    if is_match_pairs_page(page):
                        print("MATCH_PAIRS: not safely verified yet; leaving the current mapping untouched and retrying reasoning only.",flush=True)
                    elif page._hh_map_failures <= 2:
                        print("Could not map this pass safely; doing one bounded page inspection before retrying.",flush=True)
                        autonomous_scroll_scan(page)
                    else:
                        print("Could not map safely after repeated attempts; pausing interaction on this unchanged question instead of spamming scans/clicks.",flush=True)
                    last_signature=None
                    time.sleep(1.2 if page._hh_map_failures>2 else .65)
                    continue

                page._hh_map_failures=0
                print("STATUS|ANSWERED",flush=True)
                time.sleep(.15)
                if is_match_pairs_page(page) and match_grade_feedback(page):
                    grade=match_grade_feedback(page)
                    print(f"MATCH_PAIRS: Sparx already graded the completed mapping ({grade[0]} out of {grade[1]} correct); not waiting for a Submit button.",flush=True)
                    submitted=True
                else:
                    submitted=submit_current_answer(page)
                if not submitted:
                    print("STATUS|WAITING_TO_SUBMIT",flush=True)
                    # Preserve the selected answer. Do not solve/click it again on the next loop.
                    time.sleep(.7)
                    if submit_current_answer(page):
                        submitted=True
                if not submitted:
                    print("Submit still unavailable; keeping selection and waiting instead of spamming.",flush=True)
                    time.sleep(.6)
                    continue
                print("STATUS|CHECKING",flush=True)
                time.sleep(.9)

                # Sparx can award partial marks and expose a "Second chance" without a Restart button.
                feedback=read_sparx_feedback(page)
                if feedback or current_attempt_rejected(page):
                    # Only explicit Sparx feedback may unlock a connector plan.
                    try:
                        page._hh_match_locked=False
                        page._hh_match_sig=None
                    except: pass
                    if feedback:
                        key=feedback_key(page)
                        SPARX_FEEDBACK[key]=feedback
                    record_last_rejection(page,feedback)
                    save_active_task(page)
                    print("STATUS|RETRYING",flush=True)
                    print("Sparx gave second-chance/partial-mark feedback. Re-solving using the marking feedback:",flush=True)
                    print(feedback[:1800],flush=True)
                    # Correction/tutorial action has priority over retry and generic navigation.
                    if enter_correction_flow(page):
                        print("RETRY: entered Sparx correction/tutorial state.",flush=True)
                    last_signature=None; page._hh_submit_misses=0
                    print("PARTIAL RETRY: re-reading current controls and changing only what needs changing.",flush=True)
                    time.sleep(.25)
                    continue

                # Never advance just because a Next/Continue-looking control exists.
                # Sparx must positively confirm this submitted attempt was accepted.
                if current_attempt_confirmed_correct(page) and nav(page,["Next","Continue"]):
                    print("STATUS|CORRECT",flush=True)
                    _fp=LAST_ATTEMPT.get("fingerprint"); _ans=LAST_ATTEMPT.get("answers")
                    if _fp and _ans: remember_result(_fp,question_text(page),_ans,"correct")
                    print("Answer accepted and saved as confirmed experience. Moving to the next question.",flush=True)
                    SPARX_FEEDBACK.pop(feedback_key(page),None)
                    last_signature=None; time.sleep(.7); continue
                if current_attempt_rejected(page):
                    feedback=read_sparx_feedback(page)
                    record_last_rejection(page,feedback)
                    print("STATUS|RETRYING",flush=True)
                    print("COMPLETION GATE: current question is still wrong; staying on it and re-solving instead of advancing.",flush=True)
                    last_signature=None; time.sleep(.45); continue

                if nav(page,["Restart","Try again","Retry"]):
                    print("STATUS|RETRYING",flush=True)
                    fp=LAST_ATTEMPT.get("fingerprint")
                    attempted=LAST_ATTEMPT.get("answers")
                    if fp and attempted:
                        KNOWN_WRONG.setdefault(fp,[])
                        if attempted not in KNOWN_WRONG[fp]:
                            KNOWN_WRONG[fp].append(dict(attempted))
                        remember_result(fp,question_text(page),attempted,"wrong",read_sparx_feedback(page))
                        print("Recorded rejected answer in hard blacklist + long-term experience:",attempted,flush=True)
                    print("Answer was not accepted. Restarting and independently re-solving the question.",flush=True)
                    last_signature=None; time.sleep(.8); continue

                # Sparx may navigate automatically or show another part without a Next button.
                old=body[:500]
                for _ in range(16):
                    time.sleep(.25)
                    now=find_question_page(ctx,page) or recover_question_page(ctx,page,2)
                    if now:
                        page=now
                        if question_text(page)[:500] != old:
                            last_signature=None
                            print("STATUS|NEXT_PART",flush=True)
                            break
                else:
                    last_signature=None
            except Exception as ex:
                print("Engine error:",repr(ex),flush=True)
                last_signature=None
                time.sleep(.7)
        try: ctx.close()
        except: pass

if __name__=="__main__":
    try:
        main()
    except Exception:
        import traceback
        print("FATAL ENGINE STARTUP ERROR:",flush=True)
        traceback.print_exc()
        try: sys.stdout.flush(); sys.stderr.flush()
        except: pass
        raise
