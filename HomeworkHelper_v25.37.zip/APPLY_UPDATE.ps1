param([Parameter(Mandatory=$true)][string]$Archive,[Parameter(Mandatory=$true)][int]$ParentPid)
$ErrorActionPreference='Stop'
$install=Split-Path -Parent $MyInvocation.MyCommand.Path
$temp=Join-Path $env:TEMP ("HomeworkHelperUpdate_"+[guid]::NewGuid().ToString('N'))
try {
  if (-not (Test-Path -LiteralPath $Archive -PathType Leaf)) { throw 'Update ZIP not found.' }
  New-Item -ItemType Directory -Path $temp | Out-Null
  Expand-Archive -LiteralPath $Archive -DestinationPath $temp -Force
  $gui=Join-Path $temp 'Homework Helper.exe'
  $engine=Join-Path $temp 'Homework Helper Engine.exe'
  if (-not (Test-Path $gui) -or -not (Test-Path $engine)) {throw 'Invalid update ZIP: both application executables are required.'}
  $manifest=Join-Path $temp 'update_manifest.json'
  if (-not (Test-Path $manifest)) {throw 'Missing update manifest.'}
  $m=Get-Content -LiteralPath $manifest -Raw | ConvertFrom-Json
  if ($m.product -ne 'HomeworkHelper' -or $m.version -notmatch '^\d+\.\d+$') {throw 'Invalid update manifest.'}
  foreach($name in @('Homework Helper.exe','Homework Helper Engine.exe')) {
    $expected=$m.sha256.$name
    $actual=(Get-FileHash -LiteralPath (Join-Path $temp $name) -Algorithm SHA256).Hash
    if (-not $expected -or $expected -ne $actual) {throw "Hash check failed: $name"}
  }
  $old=Get-Process -Id $ParentPid -ErrorAction SilentlyContinue
  if ($old) { $old.WaitForExit(30000) | Out-Null }
  Start-Sleep -Seconds 2
  $backup=Join-Path $install 'previous_version'
  New-Item -ItemType Directory -Force -Path $backup | Out-Null
  foreach($name in @('Homework Helper.exe','Homework Helper Engine.exe')) {
    $target=Join-Path $install $name
    if(Test-Path $target){Copy-Item -LiteralPath $target -Destination (Join-Path $backup $name) -Force}
    Copy-Item -LiteralPath (Join-Path $temp $name) -Destination $target -Force
  }
  Start-Process -FilePath (Join-Path $install 'Homework Helper.exe') -WorkingDirectory $install
} catch {
  Write-Host "Update failed: $_" -ForegroundColor Red
  Write-Host 'Your saved login and settings were not touched.'
  Read-Host 'Press Enter to close'
} finally {Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue}
