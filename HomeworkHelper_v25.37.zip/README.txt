HOMEWORK HELPER v20.0
Release: 4 October 2026, 11:31 PM BST

SMARTER ANSWER ENGINE
- Solve -> Verify -> Act.
- First AI pass solves the complete question from text + screenshot.
- A second independent AI pass checks the first answer before browser interaction.
- Verification explicitly checks formulas, arithmetic, units/conversions, significant figures,
  circuit rules, diagrams/graphs and whether a numeric result agrees with the available options.
- If Sparx rejects an answer and Restart appears, that exact final answer set is remembered for
  that question during the session and supplied to the next verification pass as known-wrong.
- The solver therefore should not blindly repeat the same rejected complete answer set.

RECENT UPDATES
- Release cards now include dates.
- v20 records its actual build/release time: 4 October 2026, 11:31 PM BST.
- Older entries use their known date only where an exact historical release time was not recorded;
  no fake historical times are invented.

RETAINED
- v19.1 browser-control fixes and Sparx keypad fallback
- integrated persistent Chromium browser
- cross-version login/settings in %LOCALAPPDATA%\HomeworkHelper
- themes, Dark/Light variants, dynamic in-app branding
- scrollable Recent Updates and Activity
- Windows app/icon build tooling
\n\nv20.1 — 4 October 2026, 11:35 PM BST\n- Fixed multi-part choice grouping.\n- Already-selected choice cards are not clicked again.\n- Missing Submit/Check no longer forces an immediate identical re-solve.\n

v20.2 — 4 October 2026, 11:39 PM BST
- Full-width Sparx choice cards are no longer discarded.
- Improved grouping of vertically stacked long choices.
- Activity logs detected choice groups.
- Improved Windows/PyInstaller icon loading.
- For the actual executable/taskbar icon, build and launch dist\Homework Helper.exe.


v20.3 — 4 October 2026, 11:45 PM BST
- Fixed recursive EXE spawning.
- The Windows build now produces two files in dist:
    Homework Helper.exe
    Homework Helper Engine.exe
- The GUI launches the dedicated engine executable when frozen.
- Source/BAT mode still launches sparx_engine.py through Python.
- Keep both EXE files together in the dist folder.


v20.4 — 4 October 2026, 11:51 PM BST
- Fixed the actual remaining recursive worker launch in App.start_worker().
- Packaged GUI now calls Homework Helper Engine.exe directly.
- Engine build is windowed, so it does not create a separate console window.
- Source/BAT mode remains unchanged.
IMPORTANT: delete the OLD dist/build folders or use this installer, which cleans them automatically.


v20.5 — 4 October 2026, 11:58 PM BST
- New clickable-card choice detector; no narrow width assumption.
- Long vertically stacked answers can form C2/C3 groups.
- Added Windows single-instance mutex to stop duplicate GUI spam.
- Installer deletes/recreates the desktop shortcut with an explicit GUI target and working directory.
- App now visibly reports v20.5.


v20.6 — 5 October 2026, 12:06 AM BST
- EXE Login/Start commands wait for the engine to report BROWSER_CONNECTED.
- Commands clicked during engine startup are queued and automatically sent once ready.
- Activity logs queued/sent commands so silent button failures are visible.
- Keeps v20.5 multipart choice detection and Windows single-instance protection.


v20.7 — 5 October 2026, 12:14 AM BST
- Engine build explicitly collects Playwright and its driver package.
- Engine is temporarily console-enabled for diagnosis if Windows startup fails.
- GUI now reports the engine exit code instead of failing silently.
- Duplicate LOGIN commands are not queued repeatedly.
- Displayed version corrected to v20.7.
IMPORTANT: the installer deletes old build/dist folders. Build v20.7 fresh; do not copy its EXE over an old dist manually.


v20.8 — 5 October 2026, 12:22 AM BST
- Added desktop shortcut icon variants for all seven colour themes.
- Changing palette updates Homework Helper.lnk to the matching ICO on Windows.
- Requests an Explorer icon refresh after changing theme.
- The EXE's embedded icon remains the permanent purple fallback; the shortcut is dynamic.
- Keeps v20.7 packaged-browser diagnostics/fixes and v20.5 multipart detection.


v20.9 — 5 October 2026, 12:31 AM BST
- Login/browser works without Ollama.
- Ollama checked only when solving starts.
- Theme shortcut icons persist in %LOCALAPPDATA%\\HomeworkHelper\\icons.


v21.0 — 5 October 2026, 12:41 AM BST
CLEAN WINDOWS INSTALL REBUILD
- Installer always places BOTH Homework Helper.exe and Homework Helper Engine.exe in:
  %LOCALAPPDATA%\HomeworkHelper\App
- Desktop shortcut always targets that permanent installed GUI.
- Existing login profile/settings remain in %LOCALAPPDATA%\HomeworkHelper.
- Login/browser startup does not require Ollama.
- Theme shortcut icons persist in %LOCALAPPDATA%\HomeworkHelper\icons.
- The app still uses one GUI instance and keeps the v20 multipart/verification work.


v21.1 — 5 October 2026, 12:48 AM BST
- Reads Sparx partial-mark and Second chance feedback.
- Feeds 'Marks given for', 'How to improve' and Hint text back into both solver and verifier.
- Preserves points that earned marks and forces correction of missing points.
- Clears written input before replacing it with the improved second-chance answer.
- Prevents the exact rejected answer from being treated as a fresh solution.
- RUN_WORKING_SOURCE_VERSION.bat is included for the source/browser path that currently works reliably.


v21.2 — 5 October 2026, 12:56 AM BST
- Reads already-visible Second chance feedback BEFORE solving.
- How to improve/Hint are hard requirements.
- Verifier must alter an answer if its own check finds a missing marking point.


v21.3 — 5 October 2026, 1:04 AM BST
- Strict feedback gate.
- Recent Updates expanded to earliest recorded versions; unknown dates are labelled.


v21.4 — 5 October 2026, 1:18 AM BST
- HARD blacklist: an answer Sparx has rejected cannot be clicked again.
- If a two-option question has one confirmed-wrong option, the remaining option is selected.
- Persistent solver experience saved to %LOCALAPPDATA%\HomeworkHelper\solver_experience.json.
- Confirmed correct answers, wrong answers and Sparx feedback are remembered.
- Similar future questions receive relevant confirmed past experience.
- Added local GCSE science equations/rules as an independent knowledge layer.
- Fixed v21.3 feedback gate: ask() already returns JSON; removed undefined parse_json call.
- Sparx marking results outrank AI confidence.
