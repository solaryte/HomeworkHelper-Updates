$ErrorActionPreference='Stop'
$dist=Join-Path $PSScriptRoot 'dist'
$files=@('Homework Helper.exe','Homework Helper Engine.exe')
$hashes=@{}
foreach($f in $files){$path=Join-Path $dist $f;if(-not (Test-Path $path)){throw "Build missing: $f"};$hashes[$f]=(Get-FileHash $path -Algorithm SHA256).Hash}
$manifest=@{product='HomeworkHelper';version='25.37';sha256=$hashes}|ConvertTo-Json -Depth 4
$manifest | Set-Content -LiteralPath (Join-Path $dist 'update_manifest.json') -Encoding UTF8
$zip=Join-Path $PSScriptRoot 'Update.zip'
if(Test-Path $zip){Remove-Item $zip -Force}
Compress-Archive -LiteralPath ($files | ForEach-Object {Join-Path $dist $_}) -DestinationPath $zip
# Append manifest without flattening existing archive contents.
Compress-Archive -LiteralPath (Join-Path $dist 'update_manifest.json') -DestinationPath $zip -Update
Write-Host "Update ZIP created: $zip"
