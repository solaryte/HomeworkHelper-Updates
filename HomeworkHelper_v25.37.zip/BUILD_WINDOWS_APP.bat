@echo off
setlocal
cd /d "%~dp0"
title Homework Helper v21.0 Installer

echo ==========================================
echo   Homework Helper v21.0 Windows Installer
echo ==========================================

where py >nul 2>nul || (echo Python launcher not found.& pause & exit /b 1)
py -3.14 -m pip install --upgrade pyinstaller
if errorlevel 1 goto :fail

if exist build rmdir /s /q build
if exist dist rmdir /s /q dist

echo Building browser engine...
py -3.14 -m PyInstaller --noconfirm --clean --onefile --console ^
 --name "Homework Helper Engine" ^
 --collect-all playwright ^
 --hidden-import playwright.sync_api ^
 --hidden-import playwright._impl._driver ^
 sparx_engine.py
if errorlevel 1 goto :fail

echo Building app...
py -3.14 -m PyInstaller --noconfirm --clean --onefile --windowed ^
 --name "Homework Helper" ^
 --icon "assets\homework_helper.ico" ^
 --add-data "assets;assets" ^
 HomeworkHelper.py
if errorlevel 1 goto :fail

set "APPDIR=%LOCALAPPDATA%\HomeworkHelper\App"
if not exist "%APPDIR%" mkdir "%APPDIR%"
copy /Y "dist\Homework Helper.exe" "%APPDIR%\Homework Helper.exe" >nul
copy /Y "dist\Homework Helper Engine.exe" "%APPDIR%\Homework Helper Engine.exe" >nul
if errorlevel 1 goto :fail

echo Creating clean desktop shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$app='%APPDIR%';$desktop=[Environment]::GetFolderPath('Desktop');$lnk=Join-Path $desktop 'Homework Helper.lnk';if(Test-Path $lnk){Remove-Item $lnk -Force};$w=New-Object -ComObject WScript.Shell;$s=$w.CreateShortcut($lnk);$s.TargetPath=Join-Path $app 'Homework Helper.exe';$s.WorkingDirectory=$app;$s.IconLocation=(Join-Path $app 'Homework Helper.exe')+',0';$s.Save()"
if errorlevel 1 goto :fail

echo.
echo INSTALLED SUCCESSFULLY
echo App folder: %APPDIR%
echo Both required EXE files have been installed together.
echo Use the new Homework Helper desktop shortcut.
echo.
pause
exit /b 0

:fail
echo.
echo INSTALL FAILED. Read the error above.
pause
exit /b 1
