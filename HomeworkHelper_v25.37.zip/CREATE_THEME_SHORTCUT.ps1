$ErrorActionPreference='Stop'
$app=Join-Path $env:LOCALAPPDATA 'HomeworkHelper\App'
$settings=Join-Path $env:LOCALAPPDATA 'HomeworkHelper\homework_helper_settings.json'
$theme='teal'
if(Test-Path $settings){
 try { $cfg=Get-Content -LiteralPath $settings -Raw | ConvertFrom-Json; if($cfg.palette -match '^(Teal|Blue|Purple|Green|Orange|Rose|Monochrome)$'){$theme=$cfg.palette.ToLowerInvariant()} } catch {}
}
$icon=Join-Path $env:LOCALAPPDATA ('HomeworkHelper\icons\homework_helper_'+$theme+'.ico')
if(-not (Test-Path $icon)){$icon=Join-Path $app 'Homework Helper.exe'}
$desktop=[Environment]::GetFolderPath('Desktop')
$lnk=Join-Path $desktop 'Homework Helper.lnk'
$w=New-Object -ComObject WScript.Shell
$s=$w.CreateShortcut($lnk)
$s.TargetPath=Join-Path $app 'Homework Helper.exe'
$s.WorkingDirectory=$app
$s.IconLocation=$icon+',0'
$s.Save()
Write-Host "Desktop shortcut updated with $theme icon."
