@echo off
setlocal
title Homework Helper Setup
cd /d "%~dp0"
set "PYEXE=py -3.14"
%PYEXE% -c "import sys" >nul 2>&1
if errorlevel 1 set "PYEXE=python"

echo Installing Homework Helper requirements...
%PYEXE% -m pip install -r requirements.txt
if errorlevel 1 goto :fail
%PYEXE% -m playwright install chromium
if errorlevel 1 goto :fail
echo ready>".browser_ready"
echo.
echo Setup complete. You can now use START_HOMEWORK_HELPER.bat
pause
exit /b 0
:fail
echo.
echo Setup failed. Please send a screenshot of this window.
pause
exit /b 1
