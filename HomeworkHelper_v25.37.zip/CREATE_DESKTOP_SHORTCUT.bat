@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
 "$ws=New-Object -ComObject WScript.Shell; $s=$ws.CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Homework Helper.lnk'); $s.TargetPath='%~dp0START_HOMEWORK_HELPER.bat'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%~dp0assets\homework_helper.ico,0'; $s.Save()"
echo Homework Helper shortcut created on your desktop.
pause
