@echo off
cd /d "%~dp0"
call "%~dp0START_HOMEWORK_HELPER.bat"
