@echo off
cd /d "%~dp0"
py -3.14 HomeworkHelper.py
if errorlevel 1 pause
