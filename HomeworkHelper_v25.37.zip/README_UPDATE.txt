Homework Helper v25.34 - Automatic GitHub Update Checks

ONE-TIME SETUP:
1. Extract HomeworkHelper_v25.34.zip.
2. Run BUILD_AND_INSTALL_WINDOWS_APP.bat on Windows with Python 3.14.
3. Start Homework Helper using your existing desktop shortcut.

From now on, the installed app checks the latest release at:
https://github.com/solaryte/HomeworkHelper-Updates/releases

To publish a NEW version (e.g. v25.35):
1. Build that new version using BUILD_AND_INSTALL_WINDOWS_APP.bat on Windows.
2. Find Update.zip in the extracted build folder (created by MAKE_UPDATE_ZIP.ps1).
3. On GitHub, create a release with the matching tag v25.35.
4. Attach the generated Update.zip file (not the source build kit).
5. Publish the release. Installed v25.34 apps will detect it on next startup or via Recent updates > Check for updates.

The updater asks permission before downloading/installing. It checks the version in the update manifest and validates SHA-256 checksums before replacing the two executables. User data in %LOCALAPPDATA%\HomeworkHelper remains untouched.

Note: A public GitHub release is required for the automatic update checker. v25.33 is older than v25.34, so v25.34 will correctly report that it is already up to date until a newer release is published.
