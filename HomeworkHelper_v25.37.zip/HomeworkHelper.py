import sys
import os,sys,subprocess,threading,queue,json,tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
import urllib.request, urllib.error, re

APP_VERSION="25.37"
RELEASE_API="https://api.github.com/repos/solaryte/HomeworkHelper-Updates/releases/latest"
ROOT=Path(__file__).resolve().parent
ENGINE=ROOT/"sparx_engine.py"
DATA=Path(os.environ.get("LOCALAPPDATA",str(Path.home()))) / "HomeworkHelper"
DATA.mkdir(parents=True,exist_ok=True)
SETTINGS=DATA/"homework_helper_settings.json"

THEMES={
 "Teal":{"Dark":{"bg":"#081b1b","side":"#0d2928","panel":"#123633","panel2":"#194640","log":"#061414","accent":"#55e0c0","accent2":"#38bfa4"},
         "Light":{"bg":"#e9faf6","side":"#d2f3ea","panel":"#ffffff","panel2":"#c1eadf","log":"#f5fffc","accent":"#159d83","accent2":"#42bda4"}},
 "Blue":{"Dark":{"bg":"#0a1424","side":"#10233c","panel":"#162e4a","panel2":"#1e3d5e","log":"#07101c","accent":"#62aaff","accent2":"#467fdc"},
         "Light":{"bg":"#edf5ff","side":"#dcecff","panel":"#ffffff","panel2":"#cbdfff","log":"#f7fbff","accent":"#347fd4","accent2":"#669de1"}},
 "Purple":{"Dark":{"bg":"#171022","side":"#241735","panel":"#312047","panel2":"#422b5e","log":"#100b18","accent":"#b392f0","accent2":"#8f6ddd"},
           "Light":{"bg":"#f5efff","side":"#e9dcfb","panel":"#ffffff","panel2":"#ddcdf4","log":"#fbf8ff","accent":"#865bc9","accent2":"#aa83dd"}},
 "Green":{"Dark":{"bg":"#0c1b12","side":"#142b1d","panel":"#1b3826","panel2":"#254a32","log":"#08140d","accent":"#6edb91","accent2":"#4ebd73"},
          "Light":{"bg":"#eefaf1","side":"#daf2e1","panel":"#ffffff","panel2":"#cae9d3","log":"#f8fff9","accent":"#3a9f5d","accent2":"#6abb83"}},
 "Orange":{"Dark":{"bg":"#21150a","side":"#33210e","panel":"#432c13","panel2":"#593a18","log":"#171006","accent":"#ffb15d","accent2":"#df8536"},
           "Light":{"bg":"#fff5e9","side":"#fbe6cb","panel":"#ffffff","panel2":"#f3d6b3","log":"#fffbf6","accent":"#d67c25","accent2":"#e6a05d"}},
 "Rose":{"Dark":{"bg":"#211019","side":"#341724","panel":"#452032","panel2":"#5b2a42","log":"#170a11","accent":"#ff8eb4","accent2":"#dc668e"},
         "Light":{"bg":"#fff0f5","side":"#f9dce7","panel":"#ffffff","panel2":"#f1cbd9","log":"#fff8fb","accent":"#d85b86","accent2":"#e68cac"}},
 "Monochrome":{"Dark":{"bg":"#111416","side":"#1c2125","panel":"#282e33","panel2":"#353d43","log":"#0b0d0f","accent":"#d4dde4","accent2":"#9aa7b0"},
               "Light":{"bg":"#f1f3f4","side":"#e0e4e7","panel":"#ffffff","panel2":"#d3d9dd","log":"#fafbfb","accent":"#59666f","accent2":"#87939b"}}
}
TEXT={"Dark":{"text":"#f5f8fa","muted":"#a9b7c0"},"Light":{"text":"#173044","muted":"#667b89"}}
DEFAULT={"palette":"Teal","mode":"Dark","font":"Segoe UI","font_size":11,"last_tab":"home","window":"1120x720"}

try:
 if sys.platform == "win32":
  import ctypes
  ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("HomeworkHelper.App.v20")
except Exception:
 pass

def resource_path(*parts):
 base=Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
 return base.joinpath(*parts)

def engine_command(*extra):
 """Use bundled sibling engine when installed; Python script in source mode."""
 if getattr(sys,"frozen",False):
  appdir=Path(sys.executable).resolve().parent
  helper=appdir/"Homework Helper Engine.exe"
  if not helper.exists():
   raise FileNotFoundError(f"Required engine is missing: {helper}")
  return [str(helper),*extra]
 return [sys.executable,str(resource_path("sparx_engine.py")),*extra]

def acquire_single_instance():
    """Prevent accidental shortcut/launcher recursion from opening many GUI copies."""
    global _HH_MUTEX
    if sys.platform!="win32":
        return True
    try:
        import ctypes
        ERROR_ALREADY_EXISTS=183
        _HH_MUTEX=ctypes.windll.kernel32.CreateMutexW(None,False,"Local\\HomeworkHelper_GUI_v20")
        return ctypes.windll.kernel32.GetLastError()!=ERROR_ALREADY_EXISTS
    except Exception:
        return True

def update_windows_shortcut_icon(theme):
 """Persist selected theme icon and apply it to the installed desktop shortcut."""
 if sys.platform!="win32": return
 try:
  import subprocess,shutil
  src=resource_path("assets",f"homework_helper_{theme.lower()}.ico")
  if not src.exists(): return
  appdata=Path(os.environ.get("LOCALAPPDATA",str(Path.home()))) / "HomeworkHelper"
  icon_dir=appdata/"icons";icon_dir.mkdir(parents=True,exist_ok=True)
  icon=icon_dir/f"homework_helper_{theme.lower()}.ico"
  shutil.copy2(src,icon)
  desks=[Path.home()/"Desktop"]
  if os.environ.get("OneDrive"):desks.append(Path(os.environ["OneDrive"])/"Desktop")
  # Windows Desktop can be redirected to OneDrive or another known folder.
  try:
   import ctypes
   from ctypes import wintypes
   buf=ctypes.create_unicode_buffer(32768)
   if ctypes.windll.shell32.SHGetFolderPathW(None,0x10,None,0,buf)==0:
    desks.append(Path(buf.value))
  except Exception:pass
  for desk in dict.fromkeys(desks):
   lnk=desk/"Homework Helper.lnk"
   if not lnk.exists():continue
   ps="$w=New-Object -ComObject WScript.Shell;$s=$w.CreateShortcut('"+str(lnk).replace("'","''")+"');$s.IconLocation='"+str(icon).replace("'","''")+",0';$s.Save()"
   subprocess.run(["powershell","-NoProfile","-ExecutionPolicy","Bypass","-Command",ps],
                  creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0),check=False)
  subprocess.run(["ie4uinit.exe","-show"],creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0),check=False)
 except Exception as e:
  print("Shortcut icon update warning:",e)


class RoundedCard(tk.Canvas):
 """Theme-aware rounded card with a real Tk content frame."""
 def __init__(self,parent,**kw):
  super().__init__(parent,highlightthickness=0,bd=0,**kw)
  self.content=tk.Frame(self,bd=0)
  self.window=self.create_window(0,0,window=self.content,anchor="nw")
  self.bind("<Configure>",self._resize)
  self._bg="#21182f";self._edge="#49305e"
 def _resize(self,event=None):
  w=max(10,self.winfo_width());h=max(10,self.winfo_height())
  self.itemconfigure(self.window,width=max(1,w-2),height=max(1,h-2))
  self.coords(self.window,1,1)
  self.delete("panel")
  r=20
  self.create_polygon([r,1,w-r,1,w-1,1,w-1,r,w-1,h-r,w-1,h-1,w-r,h-1,r,h-1,1,h-1,1,h-r,1,r,1,1],smooth=True,splinesteps=12,fill=self._bg,outline=self._edge,width=1,tags="panel")
  self.tag_lower("panel")
 def theme(self,colors):
  self._bg=colors["panel"];self._edge=colors["panel2"]
  self.configure(bg=colors["bg"]);self.content.configure(bg=self._bg)
  self._resize()

class ModernSelect(tk.Frame):
 """Dark themed menu selector without the default Windows combobox."""
 def __init__(self,parent,variable,values):
  super().__init__(parent,bd=0)
  self.variable=variable;self.values=values
  self.button=tk.Label(self,text="",anchor="w",padx=15,pady=11,cursor="hand2")
  self.button.pack(fill="x")
  self.menu=tk.Menu(self,tearoff=False)
  for value in values:self.menu.add_command(label=value,command=lambda v=value:self.variable.set(v))
  self.button.bind("<Button-1>",self.open)
  self.variable.trace_add("write",lambda *_:self.refresh())
  self.refresh()
 def refresh(self):self.button.configure(text=f"{self.variable.get()}     ▾")
 def open(self,event=None):
  try:self.menu.tk_popup(self.button.winfo_rootx(),self.button.winfo_rooty()+self.button.winfo_height())
  finally:self.menu.grab_release()
 def theme(self,c,font,size):
  self.configure(bg=c["panel"])
  self.button.configure(bg=c["panel2"],fg=c["text"],font=(font,size,"bold"),activebackground=c["accent2"])
  self.menu.configure(bg=c["panel"],fg=c["text"],activebackground=c["accent2"],activeforeground="#ffffff",bd=0,relief="flat",font=(font,size))

class GlowButton(tk.Canvas):
 """Rounded canvas button with lightweight hover transitions."""
 def __init__(self,parent,text,command,width=210,height=48):
  super().__init__(parent,width=width,height=height,highlightthickness=0,bd=0,cursor="hand2")
  self.label=text;self.command=command;self.hover=False;self.c=None
  self.bind("<Button-1>",lambda e:self.command())
  self.bind("<Enter>",lambda e:self.set_hover(True))
  self.bind("<Leave>",lambda e:self.set_hover(False))
  self.bind("<Configure>",lambda e:self.draw())
 def set_hover(self,on):self.hover=on;self.draw()
 def theme(self,c,font,size,primary=False):
  self.c=c;self.font=font;self.size=size;self.primary=primary;self.configure(bg=c["panel"]);self.draw()
 def draw(self):
  if not self.c:return
  self.delete("all");w=max(10,self.winfo_width());h=max(10,self.winfo_height());c=self.c
  color=c["accent"] if self.primary else c["accent2"]
  if self.hover:color=c["accent"] if not self.primary else c["accent2"]
  r=16
  self.create_polygon([r,2,w-r,2,w-2,2,w-2,r,w-2,h-r,w-2,h-2,w-r,h-2,r,h-2,2,h-2,2,h-r,2,r,2,2],smooth=True,splinesteps=12,fill=color,outline="")
  self.create_text(w/2,h/2,text=self.label,fill="#101625" if self.primary else "#ffffff",font=(self.font,self.size,"bold"))

class App(tk.Tk):
 def __init__(self):
  super().__init__(); self.cfg=self.load_settings()
  # Homework Helper window/taskbar icon
  try:
   self._app_icon=tk.PhotoImage(file=str(resource_path("assets","homework_helper.png")))
   self.iconphoto(True,self._app_icon)
  except Exception as _icon_err:
   print('Icon load warning:',_icon_err)
  self.title("Homework Helper")

  self.geometry(self.cfg.get("window","1120x720")); self.minsize(950,620)
  self.proc=None; self.q=queue.Queue(); self.worker_ready=False; self.pending_commands=[]; self.page="home"; self.nav={}; self.frames={}; self.closing=False; self.want_running=False; self.restart_scheduled=False; self.restart_count=0
  self.palette=tk.StringVar(value=self.cfg.get("palette","Teal"))
  self.palette.trace_add("write",lambda *_: self.after(50,self.apply_theme_icon))
  self.mode=tk.StringVar(value=self.cfg.get("mode","Dark"))
  self.font=tk.StringVar(value=self.cfg.get("font","Segoe UI")); self.sz=tk.IntVar(value=self.cfg.get("font_size",11))
  self.reduce_motion=tk.BooleanVar(value=self.cfg.get("reduce_motion",False)); self._hover_nav=None; self._pulse_phase=0; self._pulse_job=None
  self.build(); self.paint(); self.apply_theme_icon(); self.show(self.cfg.get("last_tab","home"),False)
  for v in (self.palette,self.mode,self.font,self.sz): v.trace_add("write",lambda *_:self.save_and_paint())
  self.after(1800,lambda:self.check_online_updates(silent=True)); self.after(150,self.start_worker); self.after(100,self.pump); self.after(350,self.animate_status); self.protocol("WM_DELETE_WINDOW",self.close)

 def apply_theme_icon(self):
  """Set actual Windows titlebar/taskbar icon and refresh existing shortcuts."""
  theme=self.palette.get().lower()
  ico=resource_path("assets",f"homework_helper_{theme}.ico")
  try:
   if ico.exists(): self.iconbitmap(str(ico))
   png=resource_path("assets",f"homework_helper_{theme}.png")
   if png.exists():
    self._app_icon=tk.PhotoImage(file=str(png))
    self.iconphoto(True,self._app_icon)
  except Exception as exc: print("Window icon warning:",exc)
  threading.Thread(target=update_windows_shortcut_icon,args=(self.palette.get(),),daemon=True).start()

 def install_update_package(self,archive=None):
  """Install a verified update package without touching user data."""
  if not getattr(sys,"frozen",False):
   messagebox.showinfo("Updates","Install the Windows app first. Source mode cannot apply EXE updates.")
   return
  if not archive:
   archive=filedialog.askopenfilename(title="Choose Homework Helper update ZIP",filetypes=[("ZIP update", "*.zip")])
  if not archive:return
  updater=Path(sys.executable).resolve().parent/"APPLY_UPDATE.ps1"
  if not updater.exists():
   messagebox.showerror("Updater missing","APPLY_UPDATE.ps1 is missing. Reinstall the Windows app once.")
   return
  if not messagebox.askyesno("Install update","Homework Helper will close, update the existing app, then reopen. Your saved login and settings will remain."):
   return
  try:
   subprocess.Popen(["powershell.exe","-NoProfile","-ExecutionPolicy","Bypass","-File",str(updater),"-Archive",str(archive),"-ParentPid",str(os.getpid())],creationflags=getattr(subprocess,"CREATE_NEW_CONSOLE",0))
   self.closing=True
   self.close()
  except Exception as exc:messagebox.showerror("Update failed",str(exc))

 def check_online_updates(self,silent=False):
  """Fetch GitHub Releases off the UI thread. Never install without consent."""
  if getattr(self,"_update_busy",False):return
  self._update_busy=True
  def work():
   try:
    req=urllib.request.Request(RELEASE_API,headers={"User-Agent":"HomeworkHelper-Updater/"+APP_VERSION,"Accept":"application/vnd.github+json"})
    with urllib.request.urlopen(req,timeout=12) as response:release=json.load(response)
    tag=str(release.get("tag_name","")).lstrip("vV")
    if not re.fullmatch(r"\d+\.\d+",tag):raise ValueError("Latest release has an invalid version tag")
    asset=next((a for a in release.get("assets",[]) if a.get("name","").lower()=="update.zip"),None)
    newer=tuple(map(int,tag.split(".")))>tuple(map(int,APP_VERSION.split(".")))
    self.after(0,lambda:self._online_update_result(tag,asset,newer,silent))
   except Exception as exc:
    error=str(exc)
    self.after(0,lambda:self._online_update_error(error,silent))
  threading.Thread(target=work,daemon=True).start()

 def _online_update_error(self,error,silent):
  self._update_busy=False
  if not silent:messagebox.showwarning("Update check failed",f"Couldn't check GitHub Releases.\n\n{error}")

 def _online_update_result(self,tag,asset,newer,silent):
  self._update_busy=False
  if not newer:
   if not silent:messagebox.showinfo("Updates",f"Installed version: v{APP_VERSION}\nLatest published release: v{tag}\n\nNo newer update has been published on GitHub yet.")
   return
  if not asset or not asset.get("browser_download_url"):
   if not silent:messagebox.showwarning("Update unavailable",f"v{tag} is published, but it needs an attached Update.zip file.\n\nA source/build-kit ZIP cannot be installed directly through this updater.")
   return
  if messagebox.askyesno("Homework Helper update",f"Version {tag} is available!\n\nDownload and install it now?\nYour login and settings will be kept."):
   self.download_online_update(tag,asset)

 def download_online_update(self,tag,asset):
  if not getattr(sys,"frozen",False):
   messagebox.showinfo("Updates","Online installation works in the installed Windows app, not source mode.")
   return
  self._update_busy=True
  def work():
   try:
    folder=DATA/"updates";folder.mkdir(parents=True,exist_ok=True)
    target=folder/("Update_v"+tag+".zip")
    url=asset["browser_download_url"]
    if not url.startswith("https://github.com/solaryte/HomeworkHelper-Updates/releases/download/"):
     raise ValueError("Unexpected update download address")
    req=urllib.request.Request(url,headers={"User-Agent":"HomeworkHelper-Updater/"+APP_VERSION})
    with urllib.request.urlopen(req,timeout=40) as response,open(target,"wb") as output:
     total=0
     while True:
      chunk=response.read(256*1024)
      if not chunk:break
      total+=len(chunk)
      if total>350*1024*1024:raise ValueError("Update exceeds maximum allowed size")
      output.write(chunk)
    import zipfile
    with zipfile.ZipFile(target) as z:
     if z.testzip() is not None:raise ValueError("Corrupt update archive")
     manifest=json.loads(z.read("update_manifest.json").decode("utf-8-sig"))
     if manifest.get("product")!="HomeworkHelper" or manifest.get("version")!=tag:raise ValueError("Update version does not match GitHub release")
     if not {"Homework Helper.exe","Homework Helper Engine.exe"}.issubset(set(z.namelist())):raise ValueError("Update missing executable files")
    self.after(0,lambda:self._download_complete(str(target)))
   except Exception as exc:
    error=str(exc)
    self.after(0,lambda:self._online_update_error(error,False))
  threading.Thread(target=work,daemon=True).start()

 def _download_complete(self,path):
  self._update_busy=False
  self.install_update_package(path)

 def load_settings(self):
  try:d=DEFAULT.copy();d.update(json.loads(SETTINGS.read_text(encoding="utf-8")));return d
  except:return DEFAULT.copy()
 def save_settings(self):
  self.cfg.update({"palette":self.palette.get(),"mode":self.mode.get(),"font":self.font.get(),"font_size":int(self.sz.get()),"last_tab":self.page,"window":self.geometry(),"reduce_motion":bool(self.reduce_motion.get())})
  try:SETTINGS.write_text(json.dumps(self.cfg,indent=2),encoding="utf-8")
  except:pass
 def save_and_paint(self):self.save_settings();self.paint()
 def colors(self):
  c=THEMES[self.palette.get()][self.mode.get()].copy(); c.update(TEXT[self.mode.get()]); return c

 def build(self):
  self.shell=tk.Frame(self);self.shell.pack(fill="both",expand=True)
  self.side=tk.Frame(self.shell,width=232);self.side.pack(side="left",fill="y");self.side.pack_propagate(False)
  self.logo_tile=tk.Canvas(self.side,width=78,height=78,highlightthickness=0,bd=0)
  self.logo_tile.pack(pady=(28,8))
  self.logo=tk.Label(self.side,text="Homework\nHelper",justify="center");self.logo.pack(pady=(0,34))
  for key,icon,label in [("home","⌂","Home"),("activity","▣","Activity"),("updates","↻","Recent updates"),("custom","✦","Customise")]:
   b=tk.Label(self.side,text=f"  {icon}   {label}",anchor="w",cursor="hand2",padx=14,pady=11)
   b.pack(fill="x",padx=12,pady=3);b.bind("<Button-1>",lambda e,k=key:self.show(k));b.bind("<Enter>",lambda e,k=key:self.nav_hover(k));b.bind("<Leave>",lambda e:self.nav_hover(None));self.nav[key]=b
  self.ver=tk.Label(self.side,text=f"HOMEWORK HELPER\nv{APP_VERSION}",justify="left");self.ver.pack(side="bottom",anchor="w",padx=24,pady=22)

  self.main=tk.Frame(self.shell);self.main.pack(side="left",fill="both",expand=True)
  self.top=tk.Frame(self.main,height=70);self.top.pack(fill="x");self.top.pack_propagate(False)
  self.heading=tk.Label(self.top,text="Dashboard");self.heading.pack(side="left",padx=36)
  self.status=tk.Label(self.top,text="●  CONNECTING",padx=14,pady=8);self.status.pack(side="right",padx=36)
  self.body=tk.Frame(self.main);self.body.pack(fill="both",expand=True)
  for n in ("home","activity","updates","custom"):self.frames[n]=tk.Frame(self.body)

  h=self.frames["home"];self.hero_card=RoundedCard(h,height=228);self.hero_card.pack(fill="x",padx=36,pady=(30,16));self.hero=self.hero_card.content
  self.welcome=tk.Label(self.hero,text="Homework Helper");self.welcome.pack(anchor="w",padx=30,pady=(28,6))
  self.sub=tk.Label(self.hero,text="One connected browser. One continuous solving session.");self.sub.pack(anchor="w",padx=30)
  self.actionrow=tk.Frame(self.hero);self.actionrow.pack(fill="x",padx=30,pady=26)
  self.login=tk.Label(self.actionrow,text="↗   OPEN SPARX BROWSER",cursor="hand2",padx=18,pady=12);self.login.pack(side="left",padx=(0,10));self.login.bind("<Button-1>",lambda e:self.command("LOGIN"))
  self.start=tk.Label(self.actionrow,text="▶   START HELPER",cursor="hand2",padx=18,pady=12);self.start.pack(side="left");self.start.bind("<Button-1>",lambda e:self.toggle())
  self.decor=tk.Canvas(h,height=94,highlightthickness=0,bd=0)
  self.decor.pack(fill="x",padx=36,pady=(0,6))
  self.decor.bind("<Configure>",lambda e:self.draw_decor())
  self.note_card=RoundedCard(h,height=94);self.note_card.pack(fill="x",padx=36,pady=12);self.note=self.note_card.content
  self.notet=tk.Label(self.note,text="●   LIVE CONNECTION");self.notet.pack(anchor="w",padx=20,pady=(16,4))
  self.noteb=tk.Label(self.note,text="Your browser session and settings stay saved between app updates.");self.noteb.pack(anchor="w",padx=20,pady=(0,16))

  a=self.frames["activity"];self.ah=tk.Frame(a);self.ah.pack(fill="x",padx=30,pady=(28,10))
  self.at=tk.Label(self.ah,text="Activity");self.at.pack(side="left")
  self.clear=tk.Label(self.ah,text="Clear",cursor="hand2",padx=14,pady=7);self.clear.pack(side="right");self.clear.bind("<Button-1>",lambda e:self.log.delete("1.0","end"))
  self.log=tk.Text(a,relief="flat",bd=0,wrap="word",font=("Consolas",10),padx=16,pady=14);self.log.pack(fill="both",expand=True,padx=30,pady=(0,30));self.log.insert("end","Starting integrated browser...\n")

  # Scrollable Recent Updates
  u=self.frames["updates"]; self.uphead=tk.Frame(u);self.uphead.pack(fill="x",padx=30,pady=(26,8))
  self.uptitle=tk.Label(self.uphead,text="Recent updates");self.uptitle.pack(anchor="w")
  self.upsub=tk.Label(self.uphead,text="What's new in Homework Helper.");self.upsub.pack(anchor="w",pady=(3,0))
  self.update_button=tk.Button(self.uphead,text="Install update ZIP",command=self.install_update_package);self.update_button.pack(anchor="e",pady=5)
  self.online_update_button=tk.Button(self.uphead,text="Check for updates",command=self.check_online_updates);self.online_update_button.pack(anchor="e",pady=5)
  wrap=tk.Frame(u);wrap.pack(fill="both",expand=True,padx=(30,18),pady=(4,25));self.upwrap=wrap
  self.canvas=tk.Canvas(wrap,highlightthickness=0,bd=0);self.canvas.pack(side="left",fill="both",expand=True)
  self.scroll=tk.Scrollbar(wrap,orient="vertical",command=self.canvas.yview);self.scroll.pack(side="right",fill="y")
  self.canvas.configure(yscrollcommand=self.scroll.set);self.upinner=tk.Frame(self.canvas)
  self.canvaswin=self.canvas.create_window((0,0),window=self.upinner,anchor="nw")
  self.upinner.bind("<Configure>",lambda e:self.canvas.configure(scrollregion=self.canvas.bbox("all")))
  self.canvas.bind("<Configure>",lambda e:self.canvas.itemconfigure(self.canvaswin,width=e.width))
  def wheel(e): self.canvas.yview_scroll(int(-1*(e.delta/120)),"units")
  self.canvas.bind("<Enter>",lambda e:self.bind_all("<MouseWheel>",wheel));self.canvas.bind("<Leave>",lambda e:self.unbind_all("<MouseWheel>"))
  self.update_cards=[]
  changes=[
   ("v25.33","Plain-text answer repair","8 October 2026","Removes HTML superscript tags and extracts plain text from structured AI answers before typing."),
   ("v25.32","Modern interface overhaul","8 October 2026","Rebuilt settings with theme-matched custom selectors, rounded cards, integrated logo assets and modern spacing while preserving the working Chromium engine."),
   ("v25.37","Consistent installation icons and updater diagnostics","8 October 2026","Uses the Windows Desktop location for theme icons and keeps the installed shortcut consistent with the selected theme."),
   ("v25.36","Consistent theme icons and clearer updates","8 October 2026","Uses the selected theme icon consistently in the window and sidebar, shows installed and published versions separately, and clarifies when no GitHub update package is available."),
   ("v25.35","Choice mapping and series-circuit repair","8 October 2026","Rejects stale teaching-card options, validates current answer choices and correctly handles multi-part series-circuit questions."),
   ("v25.34","GitHub automatic update checking","8 October 2026","Checks the official GitHub Releases page at startup, downloads verified Update.zip packages and offers an in-place update with consent."),
   ("v25.33","Redesigned dashboard and browser repair","8 October 2026","Updated spacing, sidebar logo, dashboard cards and interactive controls. Uses a persistent Playwright browser path shared by the installer and engine."),
   ("v25.33","Refined UI and smooth animations","8 October 2026","Rounded H branding without the heart, responsive hover highlights, gentle status animation and a Reduce animations option."),
   ("v25.33","Permanent Windows app and theme icons","8 October 2026","Adds in-app update package installation for the existing Windows app, a fixed install location and theme-aware window/taskbar/desktop shortcut icons."),
   ("v25.26","Multi-select and written input repairs","8 October 2026","Adds electron-count selection for neon ion questions and converts unsupported Unicode in written answers into plain keyboard characters."),
   ("v25.25","Automatic next unfinished task","7 October 2026 - 10:36 PM BST","Adds a dedicated TASK_LIST state. After a task finishes, Homework Helper scans whole task cards, skips 100% completed tasks, ignores flashcard icons as completion evidence, opens the first unfinished task such as Task 8 at 92%, waits for its /tasks/ page, then resumes solving."),
   ("v25.24","Correct-result Next priority","7 October 2026 - 10:20 PM BST","Fully graded correct results now outrank every solver state. When Sparx shows a full score/Correct result, Homework Helper pauses MATCH_PAIRS and normal solving, clicks Next exactly once, waits for the question to change, then resumes. This fixes completed matching questions getting analysed again instead of advancing."),
   ("v25.23","Single-click answer latch","6 October 2026 - time not recorded","Stops repeated answer clicks when Sparx does not expose selected-state metadata. Every normal choice is physically clicked at most once per question/answer, then latched while the app observes the page and submits; explicit wrong feedback can still move to a different answer. Preserves v25.22 matching, feedback, flashcard learning, grid correction and navigation fixes."),
   ("v25.22","Matching sign + execution repair","6 October 2026 - time not recorded","Fixes connector matching at the root: preserves + and - charge signs so -2/-1 can no longer collide with +2/+1, re-grounds connector coordinates before every pair, waits for each Sparx redraw, and adjudicates complete diagram mappings instead of deadlocking when solver and verifier disagree."),
   ("v25.21","Stacked reliability rebuild","6 October 2026 - time not recorded","Preserves the existing persistent login, UI/themes, task lock, correction memory, tutorial/flashcard navigation and safety guards while repairing the newest layouts: deterministic GCSE checkbox grids for plant transport and biological organisation, matching pairs with unused distractors, Periodic Table ion-charge and phloem-adaptation matching guards, duplicate multi-select group collapse, stricter flashcard state isolation, and no blind Zoom/Report Problem/I don’t know interactions. Matching and table states remain latched instead of being repeatedly clicked while Submit is unavailable."),
   ("v25.12","Matching safety + Submit repair","6 October 2026 - time not recorded","Matching questions can no longer fall through to blind visual-coordinate clicking, so diagram Zoom cannot be selected as an answer. AI pair plans must contain real visible labels and safe on-page connector coordinates; blank/0,0 plans are rejected. Matching pages now count as positive answer evidence for Submit/Check discovery, so a completed mapping is submitted instead of waiting forever."),
   ("v25.9","Stay-in-task interaction guard","6 October 2026 - 6:44 AM BST","Fixed the source of random exits after questions: visual fallback can no longer click placeholder or header/back coordinates. Unsafe coordinate plans are rejected before any interaction, and an answer-entry fallback aborts immediately if it ever causes navigation away from the locked active task. The exact active-task URL recovery remains as a safety net."),
   ("v25.8","Navigation lock + semantic correction","5 October 2026 - 11:59 PM BST","Active tasks now keep an exact task-URL lock: unexpected exits to package/homework menus are restored quickly before solver or menu actions can run. Written second-chance questions that reject an interpretation now perform a whole-sentence semantic reset instead of repeatedly paraphrasing the same wrong concept; GCSE tissue/organ relationships are included in the knowledge guard."),
   ("v25.7","Locked connector matching","5 October 2026 - 11:50 PM BST","Matching questions are now solved as one complete plan. Homework Helper clears stale links once, plans every pair before clicking, connects each pair once, locks the mapping while waiting for Submit, and only unlocks/reconsiders it after explicit Sparx feedback. This prevents repeated rescans and changing already-selected pairs."),
   ("v25.5","Inline second-chance rewrite + navigation lock","5 October 2026 - 11:44 PM BST","Fixes Sparx second-chance screens that mark editable text boxes with red crosses but provide no Try again button. Rejected field values are recorded per input, hard-blacklisted, cleared, and re-solved with genuinely different answers. Keeps the active-task navigation lock: Homework Helper cannot voluntarily leave an unfinished task, and task-list question scanning remains disabled."),
   ("v25.0","Strong AI reasoning mode","5 October 2026 - 10:12 PM BST","Adds an optional stronger multimodal cloud reasoning route with web search, while keeping Qwen/Ollama as automatic fallback. The solver now explicitly identifies the scientific answer category before answering, uses UK GCSE/AQA vocabulary, and treats Sparx-rejected answers as proven false rather than allowing a verifier to defend them again. Existing login, themes, correction screens, flashcards, Submit/Finish navigation and rejection memory are preserved."),
   ("v24.9","Learning-card continuation","5 October 2026 - 10:05 PM BST","Recognises Sparx Let’s learn it support cards with an Okay, I’ve got it acknowledgement, clicks that control as navigation rather than treating the page as an unanswered question, then immediately re-reads the changed question. Keeps hard rejection memory so a previously rejected answer cannot be silently reused."),
   ("v24.8","Global rejection memory","5 October 2026 - 10:36 PM BST","Makes Sparx-confirmed wrong answers a hard constraint across the full solve pipeline. A later verifier/preflight can no longer overwrite a good candidate with a blacklisted answer. Retries receive per-control forbidden values and must produce a genuinely different answer, while confirmed-correct parts remain protected."),
  ("v24.7","Reliable Finish handling","5 October 2026 - 10:23 PM BST","Recognises verified Task Complete screens even if Flashcards branding changes, treats Finish strictly as a completion action, retries locating Finish safely, and re-reads the changed page after clicking it. Preserves v24.5 Submit fixes. Previous: Prioritises Let's learn it and Try again over stale Submit/recovery states, never selects Skip in correction flow, recognises Sparx Flashcards landing pages and clicks Let's go, recognises verified Task Complete flashcard pages and clicks Finish, then re-reads the changed page as a fresh state."),
   ("v24.3","Reliability + smart grid retry","5 October 2026 - time not recorded","Adds checked-state grid diffs so second-chance tables can uncheck and recheck individual mini-boxes, supports wording-driven multi-box rows, clicks Try again before correction, adds a stale Submit watchdog, makes task-menu recovery last-resort to stop bouncing, and automatically restarts the browser engine after an unexpected disconnect."),
   ("v24.0","Visual-first solver","5 October 2026 - 7:40 PM BST","Major solver upgrade: every standard question is understood from a full visual capture first, including diagrams, graphs, tables, labels, units, superscripts and tutorial/correction states. The visual result is mapped back onto exact DOM controls for safe interaction. Existing verification, hard wrong-answer memory, partial-mark retry, table mode, multi-select mode, Submit protection, completion gating, persistent login/settings and customisation are preserved."),
   ("v23.5","Multi-select question support","5 October 2026 - time not recorded","Detects instructions such as Select all correct answers / select all that apply and switches to a dedicated multi-select solver. Every option is judged independently, multiple cards can stay selected at once, and the single-choice indexed MCQ path is bypassed so it cannot collapse a multi-answer question to one option. Preserves v23.3 table handling, retry/completion gates, learning, scrolling, Submit handling and persistent settings."),
   ("v23.3","Checkbox-table row solver","5 October 2026 - time not recorded","Added dedicated checkbox/radio table handling. Each table row is solved independently and exactly one valid column is selected per row, rather than blindly filling a whole column. Partial row results remain a failed attempt and trigger correction instead of advancement."),
   ("v23.2","Strict correct-before-advance gate","5 October 2026 - time not recorded","Fixes questions being retried and then skipped while still wrong. Red/Incorrect/Second chance/partial-mark evidence now hard-locks the helper onto the current question, records the rejected attempt, and forces another solve instead of pressing Next/Continue. Next/Continue is allowed only after positive Sparx acceptance evidence. Returning to Homework can only select another task after a verified task-complete signal; unexpected menu returns recover the active task instead. All v23.1 partial locks, table layouts, learning, scrolling, Submit handling, persistent login/settings and earlier fixes are preserved."),
   ("v23.1","Partial-mark retry locks","5 October 2026 - time not recorded","Fixes multi-part questions where Homework Helper could initially choose the correct option, change it to a wrong one, and then fail to retry. After Sparx marks an attempt, green choices are locked and preserved, while only red choices are blacklisted. The solver immediately re-solves the rejected part and cannot select that same red option again. Existing task-completion gating, navigation recovery, learning, scrolling, inputs and Submit protections are preserved."),
   ("v23.0","Completion-gated task navigation","5 October 2026 - time not recorded","Fixes wrapped multiple-choice rows such as A-E with F on the next line. Homework Helper now treats leaving a task as an error unless Sparx positively shows that the task is complete. Only a verified completion can clear the active task and allow next-task navigation; wrong answers, second chances, retries and accidental returns to My Homework stay attached to the same task. All earlier learning, retry, safe navigation, scrolling, input and Submit protections are preserved."),
   ("v22.9","Safe task recovery state machine","5 October 2026 • time not recorded","Stops the main-menu loop at its source. Visual coordinate fallback and Submit are now blocked unless the browser is definitely on a real /tasks/ question. Unexpected exits recover through browser history first, then the saved task URL once, with a strict retry limit so a stale Sparx URL cannot bounce between the task and My Homework forever. Also fixes the engine version log to report the real build. All previous learning, wrong-answer memory, retry, scrolling, input and submission systems are preserved."),
   ("v22.8","Wrong-answer task recovery","5 October 2026 • time not recorded","Remembers the exact active Sparx task. If a wrong-answer/correction flow unexpectedly returns to the homework/packages menu, Homework Helper reopens that same task instead of advancing or getting stranded. Automatic next-task navigation from v22.7 is disabled on unexpected exits so a mistake cannot send the solver into another task. Earlier memory, retry, Submit, scrolling and solver fixes are preserved."),
   ("v22.7","Second-chance memory + next-task navigation","5 October 2026 • time not recorded","Skip, Zoom, Submit and other page controls are now globally excluded from answer choices. A visible Incorrect/Second chance result is recorded in hard wrong-answer memory before any retry, so the rejected answer cannot be treated as fresh. When Sparx returns to the Homework task list after a section, Homework Helper now looks for the next unfinished Task and opens it automatically. All earlier v22.x solving, scrolling, submission, tutorial, keypad and learning fixes are preserved."),
   ("v22.6","Visible Submit + smart scrolling fix","5 October 2026 • time not recorded","Fixed the navigation regex that made Homework Helper miss a clearly visible Submit button. Navigation now checks visible buttons/links/text first and only uses free scrolling as a fallback when the required control is genuinely not found. Selected answers are preserved while waiting, and all earlier learning, scrolling, keypad, tutorial, knowledge, retry and MCQ fixes remain intact."),
   ("v22.5","Submit-state + anti-spam fix","5 October 2026 • time not recorded","Fixed the selected-answer loop: document coordinates are now converted correctly after scrolling, a successful choice click is no longer repeated just because Sparx exposes no aria selection marker, Submit/Check is actively found and clicked once, and the same question is never blindly re-solved while a selected answer is waiting to submit. All earlier v22.x learning, scrolling, keypad, tutorial, knowledge and changelog features are preserved."),
   ("v22.4","Index-based MCQ + real interaction learning","5 October 2026 • time not recorded","Single-choice questions now use option indexes end-to-end, bypassing fragile Ω/text matching entirely. Choice clicks are physically verified, Retry/Continue/Check navigation uses aliases and full-page recovery, and UI successes/failures are now genuinely persisted in interaction_experience.json."),
   ("v22.3","Recent Updates + answer pipeline fix","5 October 2026 • time not recorded","Restored the missing modern changelog entries, fixed repeated Ω/mojibake option matching, stopped the fast MCQ result being overwritten by a redundant verifier, and added a deterministic parallel-resistance sanity check."),
   ("v22.2","Self-learning interaction engine","5 October 2026 • time not recorded","Added persistent learning for UI mistakes as well as answer mistakes, including Retry/Restart/Continue/Check discovery and learned option/input/navigation recovery."),
   ("v22.1","MCQ + Unicode reliability","5 October 2026 • time not recorded","Added horizontal/vertical visual sweeps, a faster single-MCQ path, science-symbol handling and AI timeout/fallback behaviour."),
   ("v22.0","Reliability rebuild","5 October 2026 • time not recorded","Rebuilt question detection around live Sparx task URLs, visible question text and visible controls, with automatic live-page recovery."),
   ("v21.9.2","Native Sparx keypad input","5 October 2026 • time not recorded","Numeric answers use Sparx's own keypad first and verify that the value actually persists before continuing."),
   ("v21.9.1","Scroll-memory hotfix","5 October 2026 • time not recorded","Fixed the scroll-memory NameError that could stop solving before an answer was entered."),
   ("v21.9","Free scroll + active retry","5 October 2026 • time not recorded","Added autonomous page scanning, off-screen action discovery and a dedicated retry solver for rejected numeric/written answers."),
   ("v21.8","Continuous tutorial progression","5 October 2026 • time not recorded","Tracks the active tutorial step, controls and input values so Step 2 → Step 3 changes are detected."),
   ("v21.7","Physical look-around navigation","5 October 2026 • time not recorded","The browser physically looks above the active step for prerequisite information, then returns to the answer area."),
   ("v21.6","Layout-aware navigation","5 October 2026 • time not recorded","Added active Sparx layout detection and tutorial-step scoping while ignoring numeric keypad controls as choices."),
   ("v21.5","Knowledge + full-page preflight","5 October 2026 • time not recorded","Added local knowledge retrieval, full-page visual context and a deeper preflight before spending an attempt."),
   ("v21.4","Known-wrong enforcement","5 October 2026 • time not recorded","Added hard enforcement preventing confirmed rejected answers from simply being clicked again."),
   ("v21.3","Strict feedback gate","5 October 2026 • 1:04 AM BST","Added a final second-chance feedback compliance stage before interaction."),
   ("v21.2","Feedback-first correction","5 October 2026 • 12:56 AM BST","Reads visible second-chance feedback before solving."),
   ("v21.1","Second-chance self-correction","5 October 2026 • 12:48 AM BST","Added partial-mark and second-chance feedback handling."),
   ("v21.0","Windows install rebuild","5 October 2026 • 12:41 AM BST","Reworked Windows installation layout."),
   ("v20.9","Login without AI + persistent icons","5 October 2026 • 12:31 AM BST","Separated login from Ollama and persisted theme icons."),
   ("v20.8","Theme-matched desktop icon","5 October 2026 • 12:22 AM BST","Added theme-coloured shortcut icons."),
   ("v20.7","Browser startup diagnostics","5 October 2026 • 12:14 AM BST","Added Playwright startup diagnostics."),
   ("v20.6","EXE Login/Start queue","5 October 2026 • 12:06 AM BST","Queued commands until browser readiness."),
   ("v20.5","Multipart detector + single instance","4 October 2026 • 11:58 PM BST","Added multipart grouping and single-instance protection."),
   ("v20.4","EXE launch-loop fix","4 October 2026 • 11:51 PM BST","Fixed recursive worker launch."),
   ("v20.3","Standalone process fix","4 October 2026 • 11:45 PM BST","Separated packaged GUI and worker."),
   ("v20.2","Wide choices + icon","4 October 2026 • 11:39 PM BST","Improved wide choices and icon handling."),
   ("v20.1","Multipart stability","4 October 2026 • 11:35 PM BST","Stopped repeated toggling of choices."),
   ("v20","Solve → Verify → Act","4 October 2026 • exact time not recorded","Introduced smarter verification and known-wrong handling."),
   ("v19.1","Direct browser controls","Date/time not recorded","Added exact choice-card clicking and Sparx on-screen number-pad support."),
   ("v19","Browser interaction","Date/time not recorded","Fixed Unicode option handling and improved direct Playwright choice interaction."),
   ("v18.5","App icon system","Date/time not recorded","Added Homework Helper icon assets and dynamic in-app branding."),
   ("v18","Solver foundation","Date/time not recorded","Added stronger full-page context, themes and persistent app-data groundwork."),
   ("v17","Integrated browser","Date/time not recorded","Changed Homework Helper to own one continuous browser session."),
   ("v16","GUI/browser refinement","Date/time not recorded","Improved dashboard and browser integration."),
   ("v15","Saved profile","Date/time not recorded","Improved saved login/profile behaviour."),
   ("v14","Dashboard UI","Date/time not recorded","Expanded dashboard and Activity workflow."),
   ("v13","First GUI","Date/time not recorded","Introduced the desktop GUI."),
   ("v11","Mixed controls","Date/time not recorded","Improved numeric, written and mixed controls."),
   ("v10","Input reliability","Date/time not recorded","Improved input and option matching."),
   ("v9","Broader controls","Date/time not recorded","Expanded support beyond dropdown questions."),
   ("v8.1","Dropdown reliability","Date/time not recorded","Stabilised dropdown selection."),
   ("v8","Dropdown handling","Date/time not recorded","Improved dropdown support."),
   ("v4–v7","Early interaction builds","Date/time not recorded","Iterated browser control and answer selection."),
   ("v1–v3","Early prototypes","Date/time not recorded","Initial question-reading and answering prototypes.")
  ]
  for ver,title,date,body in changes:
   card=tk.Frame(self.upinner);card.pack(fill="x",pady=6)
   row=tk.Frame(card);row.pack(fill="x",padx=18,pady=(13,2))
   vl=tk.Label(row,text=ver,padx=8,pady=3);vl.pack(side="left");tl=tk.Label(row,text=title);tl.pack(side="left",padx=12)
   dl=tk.Label(card,text=date,anchor="w");dl.pack(fill="x",padx=18,pady=(2,4))
   bl=tk.Label(card,text=body,justify="left",anchor="w",wraplength=690);bl.pack(fill="x",padx=18,pady=(0,13))
   self.update_cards.append((card,row,vl,tl,dl,bl))

  c=self.frames["custom"];self.cc_card=RoundedCard(c,height=485);self.cc_card.pack(fill="x",padx=30,pady=30);self.cc=self.cc_card.content
  self.ct=tk.Label(self.cc,text="Customise");self.ct.pack(anchor="w",padx=24,pady=(22,4))
  self.cs=tk.Label(self.cc,text="Appearance changes save automatically.");self.cs.pack(anchor="w",padx=24,pady=(0,18));self.rows=[];self.selectors=[]
  for label,var,vals in [("Colour theme",self.palette,list(THEMES)),("Mode",self.mode,["Dark","Light"]),("Font",self.font,["Segoe UI","Arial","Calibri","Verdana"])]:
   r=tk.Frame(self.cc);r.pack(fill="x",padx=24,pady=8);l=tk.Label(r,text=label,width=15,anchor="w");l.pack(side="left")
   selector=ModernSelect(r,var,vals);selector.pack(side="left",fill="x",expand=True);self.selectors.append(selector);self.rows.append((r,l))
  r=tk.Frame(self.cc);r.pack(fill="x",padx=24,pady=8);l=tk.Label(r,text="Font size",width=15,anchor="w");l.pack(side="left")
  self.size_down=tk.Label(r,text="  −  ",cursor="hand2",padx=12,pady=10);self.size_down.pack(side="left");self.size_down.bind("<Button-1>",lambda e:self.sz.set(max(9,self.sz.get()-1)));self.size_value=tk.Label(r,textvariable=self.sz,padx=22,pady=10);self.size_value.pack(side="left");self.size_up=tk.Label(r,text="  +  ",cursor="hand2",padx=12,pady=10);self.size_up.pack(side="left");self.size_up.bind("<Button-1>",lambda e:self.sz.set(min(16,self.sz.get()+1)));self.rows.append((r,l))
  self.motion_check=tk.Checkbutton(self.cc,text="Reduce animations",variable=self.reduce_motion,command=self.save_and_paint,anchor="w",bd=0,highlightthickness=0);self.motion_check.pack(anchor="w",padx=24,pady=(14,0))
  self.saved=tk.Label(self.cc,text="✓  Every change is saved automatically");self.saved.pack(anchor="w",padx=24,pady=(18,24))

 def start_worker(self):
  if self.proc and self.proc.poll() is None:return
  self.worker_ready=False
  flags=subprocess.CREATE_NO_WINDOW if os.name=="nt" else 0
  try:
   cmd=engine_command()
   engine_cwd=str(Path(cmd[0]).parent) if getattr(sys,"frozen",False) else str(ROOT)
   browser_dir=DATA/"Browsers"
   browser_dir.mkdir(parents=True,exist_ok=True)
   env=os.environ.copy()
   env["PLAYWRIGHT_BROWSERS_PATH"]=str(browser_dir)
   self.proc=subprocess.Popen(cmd,env=env,cwd=engine_cwd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding="utf-8",errors="replace",bufsize=1,creationflags=flags)
   threading.Thread(target=self.reader,daemon=True).start()
  except Exception as e:self.log.insert("end",f"Browser worker error: {e}\n");self.show("activity")

 def command(self,cmd):
  if not self.proc or self.proc.poll() is not None:
   self.start_worker()
  if not self.proc or self.proc.poll() is not None:
   self.log.insert("end","Engine failed to start; command was not sent.\n");self.show("activity");return
  if not self.worker_ready:
   if cmd not in self.pending_commands:self.pending_commands.append(cmd)
   self.log.insert("end",f"Waiting for browser engine before sending {cmd}...\n")
   self.show("activity")
   return
  try:
   self.proc.stdin.write(cmd+"\n");self.proc.stdin.flush()
   self.log.insert("end",f"Sent command: {cmd}\n")
  except Exception as e:
   self.log.insert("end",f"Command error: {e}\n");self.show("activity")

 def toggle(self):
  if self.start.cget("text").startswith("■"):
   self.want_running=False; self.command("STOP");self.start.config(text="▶  START HELPER");self.status.config(text="●  PAUSED")
  else:
   self.want_running=True; self.command("START");self.start.config(text="■  STOP HELPER");self.status.config(text="●  STARTING")

 def reader(self):
  try:
   for line in self.proc.stdout:self.q.put(line)
  finally:
   try: code=self.proc.wait(timeout=1)
   except Exception: code="unknown"
   self.q.put(f"Engine exited (code {code}).\n")
   self.q.put("STATUS|WORKER_STOPPED\n")

 def pump(self):
  try:
   while True:
    x=self.q.get_nowait()
    if x.startswith("STATUS|"):
     st=x.strip().split("|",1)[1]
     if st=="BROWSER_CONNECTED":
      self.worker_ready=True; self.restart_count=0
      pending=self.pending_commands[:];self.pending_commands.clear()
      for _cmd in pending:
       try:
        self.proc.stdin.write(_cmd+"\n");self.proc.stdin.flush()
        self.log.insert("end",f"Sent queued command: {_cmd}\n")
       except Exception as _e:self.log.insert("end",f"Queued command error: {_e}\n")
     labels={"AI_READY":"AI READY","AI_OFFLINE":"AI OFFLINE","BROWSER_CONNECTED":"BROWSER CONNECTED","LOGIN_READY":"LOGIN READY",
      "QUESTION_READY":"QUESTION DETECTED","WAITING_QUESTION":"LOOKING FOR QUESTION","ANALYSING":"ANALYSING","ANSWERED":"ANSWER ENTERED",
      "CHECKING":"CHECKING","CORRECT":"CORRECT","RETRYING":"RETRYING","NEXT_PART":"NEXT PART","NEEDS_ATTENTION":"NEEDS ATTENTION","WORKER_STOPPED":"DISCONNECTED"}
     self.status.config(text="●  "+labels.get(st,st.replace("_"," ")))
     if st=="WORKER_STOPPED" and not self.closing and not self.restart_scheduled:
      self.worker_ready=False; self.restart_count+=1
      if self.restart_count>=3:
       self.log.insert("end","Browser failed repeatedly. Automatic restarts paused. Run FIX_BROWSER_WINDOWS.bat from the downloaded kit, then restart Homework Helper.\n")
       self.status.config(text="●  BROWSER START FAILED")
       continue
      self.restart_scheduled=True
      self.log.insert("end",f"Connection lost. Restart attempt {self.restart_count}/2...\n")
      def _reconnect():
       self.restart_scheduled=False; self.start_worker()
       if self.want_running and "START" not in self.pending_commands:self.pending_commands.append("START")
      self.after(1200,_reconnect)
    else:self.log.insert("end",x);self.log.see("end")
  except queue.Empty:pass
  self.after(100,self.pump)

 def nav_hover(self,key):
  self._hover_nav=key
  self.paint()

 def animate_status(self):
  if self.closing:return
  try:
   if not self.reduce_motion.get():
    self._pulse_phase=(self._pulse_phase+1)%8
    state=self.status.cget("text")
    if any(x in state for x in ("CONNECTING","STARTING","ANALYSING","LOOKING","CHECKING")):
     c=self.colors();self.status.configure(fg=c["accent"] if self._pulse_phase<4 else c["muted"])
  except tk.TclError:return
  self.after(320,self.animate_status)

 def show(self,name,animate=True):
  if name not in self.frames:name="home"
  for f in self.frames.values():f.pack_forget()
  self.frames[name].pack(fill="both",expand=True);self.page=name
  self.heading.config(text={"home":"Dashboard","activity":"Activity","updates":"Recent updates","custom":"Customise"}[name]);self.save_settings();self.paint()

 def draw_decor(self):
  if not hasattr(self,"decor"):return
  c=self.colors();w=max(self.decor.winfo_width(),400)
  self.decor.delete("all")
  for i,(title,detail) in enumerate((("01  CONNECT","Open your browser"),("02  LEARN","Review each question"),("03  PROGRESS","Keep your session"))):
   x=round(i*w/3)+3;end=round((i+1)*w/3)-9
   self.decor.create_rectangle(x,4,end,87,fill=c["panel"],outline=c["panel2"],width=2)
   self.decor.create_rectangle(x+14,20,x+19,43,fill=c["accent"],outline="")
   self.decor.create_text(x+30,27,anchor="w",text=title,fill=c["text"],font=(self.font.get(),11,"bold"))
   self.decor.create_text(x+30,59,anchor="w",text=detail,fill=c["muted"],font=(self.font.get(),9))

 def paint(self):
  c=self.colors();f=self.font.get();s=int(self.sz.get())
  for w in (self,self.shell,self.main,self.body,self.top):w.configure(bg=c["bg"])
  self.side.configure(bg=c["side"])
  self.draw_decor()
  for card in (self.hero_card,self.note_card,self.cc_card):card.theme(c)
  for selector in self.selectors:selector.theme(c,f,s)
  for widget in (self.size_down,self.size_up,self.size_value):widget.configure(bg=c["panel2"],fg=c["text"],font=(f,s,"bold"))
  self.logo_tile.configure(bg=c["side"])
  self.logo_tile.delete("all")
  # Soft rounded-square H mark: no heart, matches the Windows theme icons.
  x0,y0,x1,y1,r=7,7,71,71,19
  points=[x0+r,y0,x1-r,y0,x1,y0,x1,y0+r,x1,y1-r,x1,y1,x1-r,y1,x0+r,y1,x0,y1,x0,y1-r,x0,y0+r,x0,y0]
  self.logo_tile.create_polygon(points,smooth=True,splinesteps=12,fill=c["panel"],outline="",width=0)
  try:
   from PIL import Image,ImageTk
   icon=Image.open(str(resource_path("assets",f"homework_helper_{self.palette.get().lower()}.png")))
   icon=icon.convert("RGBA").resize((72,72),Image.Resampling.LANCZOS)
   self._logo_img=ImageTk.PhotoImage(icon)
   self.logo_tile.create_image(39,39,image=self._logo_img)
  except Exception:
   self.logo_tile.create_text(39,42,text="H",fill=c["accent"],font=(f,34,"bold"))
  self.logo.configure(bg=c["side"],fg=c["text"],font=(f,17,"bold"));self.ver.configure(bg=c["side"],fg=c["muted"],font=(f,9))
  for k,b in self.nav.items():b.configure(bg=c["accent"] if k==self.page else c["panel2"] if k==self._hover_nav else c["side"],fg="#10242b" if k==self.page else c["text"],font=(f,s,"bold"))
  self.heading.configure(bg=c["bg"],fg=c["text"],font=(f,s+7,"bold"));self.status.configure(bg=c["panel"],fg=c["accent"],font=(f,s,"bold"))
  for fr in self.frames.values():fr.configure(bg=c["bg"])
  for card in (self.hero,self.note,self.cc):card.configure(bg=c["panel"])
  self.actionrow.configure(bg=c["panel"]);self.welcome.configure(bg=c["panel"],fg=c["text"],font=(f,s+17,"bold"));self.sub.configure(bg=c["panel"],fg=c["muted"],font=(f,s))
  self.login.configure(bg=c["accent2"],fg="white",font=(f,s,"bold"));self.start.configure(bg=c["accent"],fg="#10242b",font=(f,s,"bold"))
  self.notet.configure(bg=c["panel"],fg=c["accent"],font=(f,s+1,"bold"));self.noteb.configure(bg=c["panel"],fg=c["muted"],font=(f,s))
  self.ah.configure(bg=c["bg"]);self.at.configure(bg=c["bg"],fg=c["text"],font=(f,s+8,"bold"));self.clear.configure(bg=c["panel2"],fg=c["text"],font=(f,s));self.log.configure(bg=c["log"],fg=c["text"],insertbackground=c["text"],highlightthickness=1,highlightbackground=c["panel2"])
  self.update_button.configure(bg=c["accent2"],fg="white",activebackground=c["accent"],relief="flat",font=(f,s,"bold"))
  self.online_update_button.configure(bg=c["accent2"],fg="white",activebackground=c["accent"],relief="flat",font=(f,s,"bold"))
  self.uphead.configure(bg=c["bg"]);self.uptitle.configure(bg=c["bg"],fg=c["text"],font=(f,s+8,"bold"));self.upsub.configure(bg=c["bg"],fg=c["muted"],font=(f,s))
  self.upwrap.configure(bg=c["bg"]);self.canvas.configure(bg=c["bg"]);self.upinner.configure(bg=c["bg"])
  for card,row,vl,tl,dl,bl in self.update_cards:
   card.configure(bg=c["panel"]);row.configure(bg=c["panel"]);vl.configure(bg=c["accent2"],fg="white",font=(f,s,"bold"))
   tl.configure(bg=c["panel"],fg=c["text"],font=(f,s+1,"bold"));dl.configure(bg=c["panel"],fg=c["accent"],font=(f,max(9,s-1),"bold"));bl.configure(bg=c["panel"],fg=c["muted"],font=(f,s))
  self.motion_check.configure(bg=c["panel"],fg=c["text"],activebackground=c["panel"],activeforeground=c["accent"],selectcolor=c["panel2"],font=(f,s))
  self.ct.configure(bg=c["panel"],fg=c["text"],font=(f,s+8,"bold"));self.cs.configure(bg=c["panel"],fg=c["muted"],font=(f,s));self.saved.configure(bg=c["panel"],fg=c["accent"],font=(f,s,"bold"))
  for r,l in self.rows:r.configure(bg=c["panel"]);l.configure(bg=c["panel"],fg=c["text"],font=(f,s))
  for button in (self.login,self.start,self.clear):
   button.bind("<Enter>",lambda e,b=button:b.configure(bg=c["accent2"],relief="flat",bd=0))
   button.bind("<Leave>",lambda e,b=button:self.paint())
  st=ttk.Style(self)
  try:st.theme_use("clam")
  except:pass
  pass

 def close(self):
  self.closing=True
  self.save_settings()
  try:self.command("SHUTDOWN")
  except:pass
  if self.proc and self.proc.poll() is None:
   try:self.proc.wait(timeout=2)
   except:
    try:self.proc.terminate()
    except:pass
  self.destroy()

if __name__=="__main__":
 if not acquire_single_instance():
  raise SystemExit(0)
 App().mainloop()
